$(document).ready(function() {
  $('.pro1').show();
  $('.pro2').hide();
  $('#pro1_bn').addClass('clickon');

  $('a').hover(
    function(){
      $(this).parent().addClass('clickon');
    }, 
    function(){
      $(this).parent().removeClass('clickon');
    }
  );

  $('#pro1_bn').click(function(){
    $('.pro1').show('slow');
    $('.pro2').hide();
    $(this).addClass('clickon');

    $('#pro2_bn').removeClass('clickon2');
  });

  $('#pro2_bn').click(function(){
    $('.pro2').show('slow');
    $('.pro1').hide();
    $(this).addClass('clickon2');

    $('#pro1_bn').removeClass('clickon');
  });
});
