$(document).ready(function () {
	// innerfade �÷������� �����մϴ�.
	var  wrap = $('.line img').width();
	var fheight = (wrap/640)*130
	$('.inner_fade').innerfade({
		animationtype: 'fade',
		speed: 'slow',
		timeout: 2500,
		type: 'sequence',
		containerheight: fheight+'px'
	});
});

var slope = 0;
var supportsOrientationChange = "onorientationchange" in window,     
orientationEvent = supportsOrientationChange ? "orientationchange" : "resize";  

window.addEventListener(orientationEvent, function() {     
if (slope!=window.orientation){
	slope = window.orientation;
	if(slope == 90 || slope == -90) {
		// ���λ���
		var  wrap = $('.line img').width();
		var fheight = (wrap/640)*130
		$('.inner_fade').innerfade({
			animationtype: 'fade',
			speed: 'slow',
			timeout: 2500,
			type: 'sequence',
			containerheight: fheight+'px'
		});
	}
	else {
		// ���λ���
		var  wrap = $('.line img').width();
		var fheight = (wrap/640)*130
		$('.inner_fade').innerfade({
			animationtype: 'fade',
			speed: 'slow',
			timeout: 2500,
			type: 'sequence',
			containerheight: fheight+'px'
		});
	}
}
}, false);
