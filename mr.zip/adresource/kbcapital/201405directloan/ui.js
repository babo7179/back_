$(window).load(function(e){
	$(document).ready(function(e){
		if( $(".productMenu.tabMenu").length > 0 ){
			$( ".productMenu.tabMenu a" ).bind("click", function(e){
				$( ".pageCnt .tabCnt img" ).css({"display":"none"}).eq( $( this ).index( ".productMenu.tabMenu a" ) ).css({"display":"block"});
				e.preventDefault();
			});

			//$( ".pageCnt .tabCnt img" ).eq( 1 ).css({"display":"none"})
		}
	})
})