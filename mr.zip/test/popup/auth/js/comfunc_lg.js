var xmlHttp;
var sendflag="firstSend";

var authCountCk = 0;

function windowResize(){
	window.moveTo(screen.width/2-200,20);
	window.resizeTo("435", "665");
	visPro("no");
	//document.form1.telco[0].disabled =true;
	//alert(screen.width)
}

function isNum(str)
{
	var reg = /[^0-9]/;

	if(reg.test(str))
		return false;
	else
		return true;
}


function createXMLHttpRequest() {
	   if (window.ActiveXObject) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	    } 
		else if (window.XMLHttpRequest) {
			xmlHttp = new XMLHttpRequest();
		}
}

function alert(error_str) {
	visPro("no");
	var errMess = document.getElementById("textName");
	document.getElementById('al').style.position   = "absolute";
	document.getElementById('al').style.visibility = "visible";
	document.getElementById('al').style.display    = "block";
	errMess.innerHTML = error_str;
	return true;
}

function visPro(yeno){
	if(yeno == "yes"){
		document.getElementById('pro').style.visibility = "visible";
		document.getElementById('pro').style.display    = "block";
	}
	else{
		document.getElementById('pro').style.visibility = "hidden";
		document.getElementById('pro').style.display    = "none";
	}
	return;
}

function KeyEventHandle(e){
	var frm = document.form1;
	var keycode = (window.event) ? event.keyCode : e.which; //IE : FF - Chrome both
	var focusname = $("*:focus").attr("id");
	if(keycode == 13||keycode == 27){
		if(document.getElementById('al').style.display=='none'){
		}
		else
			document.getElementById('al').style.display='none';
	}

	if(focusname =="textfield"||focusname =="cellnum2"||focusname =="cellnum3"){
		if(!(keycode > 47 && keycode <58)&&!(keycode > 95 && keycode <106)&&!(keycode==8)
			&&!(keycode==46)&&!(keycode==37)&&!(keycode==39)&&!(keycode==9)){
			nAllow(e);
		}
		if(keycode==13&&focusname=="textfield"){
			confirmCert();
		}else if(keycode==13&&focusname=="cellnum3"){
			checkSubmit();
		}			
	}
	if(keycode > 111 && keycode <124){
		nAllow(e);
	}
	if(window.event){
		if(event.ctrlKey == true&&(keycode==82||keycode==78||keycode==83))
		{nAllow(e);}
	}
	else
	{
		if(e.ctrlKey == true){
			nAllow(e);
		}
	}
	if(focusname==null){
		if(keycode==8){
			if(frm.textfield!=undefined){
				frm.textfield.focus();
				frm.textfield.value=frm.textfield.value;
				nAllow(e);
			}
			else{
				nAllow(e);
			}
		}
	}
	if(window.event){
		if(event.ctrlKey)
			nAllow(e);
	}
}

function nAllow(e){
        if(navigator.appName!="Netscape"){ //for not returning keycode value
			//event.keyCode = 0;
			event.cancelBubble        = true;
            event.returnValue = false;  //IE ,  - Chrome both
        }else{
            e.preventDefault(); //FF ,  - Chrome both
        }
		return false;
 }
 
 
 function Pop_close()
    {
        $("#layer_pop").hide();    
    }

function changeBox(cbox){     
        box = eval(cbox); 
        box.checked = !box.checked; 
    } 


function nextFocus(element) {  
    //현재 element가 포함된 form element를 가지고 온다  
    var form = element.form;  
      
    //form의 element list에서 다음 element 찾기   
    for(var i = 0; i < form.length; i++){  
          
        //현재 element의 다음 element  
        //(type이 text, password, select-one)의 index를 찾는다
		if(form.elements[i+1]==null)
			break;
        if(form.elements[i] == element) {  
            i++;  
            while(form.elements[i].type != "text"  
                && form.elements[i].type != "password"  
                && form.elements[i].type != "select-one")   
            {i++;}  
              
            //찾아 focus를 이동 시킨다  
            var next = form.elements[i];  
            next.focus();  
            break;  
        }  
    }  
}  



function cechkLength(thisObj) {
	if(thisObj.value.length == thisObj.maxLength) {  
        nextFocus(thisObj);  
    }
}
function mvFocus(thisObj){
	var frm = document.form1;
	var keycode = (window.event) ? event.keyCode : e.which; //IE : FF - Chrome both
	if(keycode==8&&thisObj.value.length==0){
		frm.cellnum2.focus();
		frm.cellnum2.value = frm.cellnum2.value;
	}
}


function allcheck(){
	var frm = document.form1;
	if(frm.chkboxa.checked == true){
			frm.chkbox1.checked = true;
			frm.chkbox2.checked = true;
			frm.chkbox3.checked = true;
			frm.chkbox4.checked = true;
		}
		else if(frm.chkboxa.checked == false){
			frm.chkbox1.checked = false;
			frm.chkbox2.checked = false;
			frm.chkbox3.checked = false;
			frm.chkbox4.checked = false;
		}
	return;
}
function checkA(){
		var frm = document.form1;
		if(frm.chkbox1.checked ==true && frm.chkbox2.checked == true && frm.chkbox3.checked ==true && frm.chkbox4.checked ==true)
			frm.chkboxa.checked = true;
		else
			frm.chkboxa.checked = false;
		return;
}
function checkSubmit(){
	var frm = document.form1;


	if(frm.chkbox1.checked != true){
		alert("개인정보 이용약관에 동의해주세요.");
		return;
	}
	if(frm.chkbox2.checked != true){
		alert("&nbsp;&nbsp;고유식별정보 처리 약관에<br> &nbsp;&nbsp;동의해주세요.");
		return;
	}
	if(frm.chkbox3.checked != true){
		alert("개인정보 수집/이용/취급위탁 약관에 동의해주세요.");
		return;
	}
	if(frm.chkbox4.checked != true){
		alert("통신사 본인확인 서비스 이용약관에 동의해주세요.");
		return;
	}

		if(frm.name.value == "") {
			if(frm.name1.value==""){
					alert("이름을 입력하여주세요.");
					frm.name1.focus();
					return;
			}
		frm.name.value = frm.name1.value;
	}
	
	
	
	if(frm.birth.value == ""){
		if(frm.year.value == "" || frm.month.value == "" || frm.day.value == ""){
	    	alert("생년월일을 입력해주세요.");
				frm.year.focus();
				return;
		}
		frm.birth.value = frm.year.value+frm.month.value+frm.day.value;
	}
	
	if(frm.nation.value == ""){
		frm.nation.value = frm.national.value;
	}

	if(frm.mdn.value == ""){
		if(frm.cellnum2.value == "" || frm.cellnum3.value == ""){
			alert("휴대폰 번호를 입력해주세요.");
			return false;
		}
		frm.mdn.value = frm.cellnum1.value+frm.cellnum2.value+frm.cellnum3.value;
	}
	
	if(frm.gender.value == ""){
		var genderYn = false;
		for(var i = 0; i < frm.gender1.length; i++) {
        if(frm.gender1[i].checked) {
        	// alert("gender: " + frm.gender1[i].value);
        	
        	frm.gender.value = frm.gender1[i].value;
        	genderYn = true;
            break;
        }
        if(!frm.gender1[0].checked && !frm.gender1[1].checked){
				alert("성별을 선택해주세요."); 
				return;
			}
     }
   }
     

	//if(frm.name1.value==""){
	//	alert("이름을 입력하여주세요.");
	//	frm.name1.focus();
	//	return;
	//}
	
	//if(!frm.gender1[0].checked && !frm.gender1[1].checked){
	//	alert("성별을 선택해주세요."); 
	//	return;
	//}

	//if(frm.year.value == "" || frm.month.value == "" || frm.day.value == ""){
	//	alert("생년월일을 입력해주세요.");
	//	frm.year.focus();
	//	return;
	//}
	
	//if(frm.cellnum2.value == "" || frm.cellnum3.value == ""){
	//	alert("휴대폰 번호를 입력해주세요.");
	//	return false;
	//}
	
	//if(isNaN(frm.cellnum2.value) == true || isNaN(frm.cellnum3.value) == true) 
	//{
	//	alert("휴대폰 번호는 숫자로 입력해주세요.");
	//	return false;
	//}
		
		//frm.mdn.value = frm.cellnum1.value + frm.cellnum2.value + frm.cellnum3.value;
		//frm.birth.value = frm.year.value + frm.month.value + frm.day.value;
		frm.telcoReqNum.value = createReqNum(frm.telecom.value);
		//frm.name.value = frm.name1.value;
		//frm.nation.value = frm.national.value;
		//for(var i = 0; i < frm.gender1.length; i++) {
		//	if(frm.gender1[i].checked) {
     // 		frm.gender.value = frm.gender1[i].value;
	 	//break;
	 	//}
    //    }
  visPro("yes");
	PostRequest();
}

function closeWin() 
{ 
	var frm = document.form1;
	frm.result.value = "인증취소";
	frm.resultCd.value = "0033";


	
	if(frm.retUrl.value.indexOf("?") > 0) {				
		location.href = frm.retUrl.value + "&clntReqNum=" + encodeURIComponent(frm.clntReqNum.value) + "&date=" + encodeURIComponent(frm.date.value)+ "&resultCd=" + encodeURIComponent(frm.resultCd.value)+"&result=인증취소" ;
	}else{
		location.href = frm.retUrl.value + "?clntReqNum=" + encodeURIComponent(frm.clntReqNum.value) + "&date=" + encodeURIComponent(frm.date.value)+ "&resultCd=" + encodeURIComponent(frm.resultCd.value)+"&result=인증취소" ;
	}	
}




 function createReqNum(telcom) {
	var d = new Date();
	
	if(telcom != "02")	// kt가 아니면 17자리 생성
	{
		reqNum = leadingZeros(d.getFullYear(), 4)
				+ leadingZeros(d.getMonth() + 1, 2)
				+ leadingZeros(d.getDate(), 2) + 
	
				leadingZeros(d.getHours(), 2)
				+ leadingZeros(d.getMinutes(), 2)
				+ leadingZeros(d.getSeconds(), 2)
				+ leadingZeros(d.getMilliseconds(), 3);
	} 
	else 				// kt면 9자리 생성
	{
		reqNum = leadingZeros(d.getHours(), 2)
				+ leadingZeros(d.getMinutes(), 2)
				+ leadingZeros(d.getSeconds(), 2)
				+ leadingZeros(d.getMilliseconds(), 3);
	}
	
	return reqNum;
} 

function leadingZeros(n, digits) {
	var zero = '';
	n = n.toString();

	if (n.length < digits) {
		for (i = 0; i < digits - n.length; i++)
			zero += '0';
	}
	
	return zero + n;
}

function PostRequest() {
	var frm = document.form1;
	authCountCk++;
	createXMLHttpRequest();
	xmlHttp.onreadystatechange = handleStateChange;
	xmlHttp.open("POST", "checkAuth.jsp", true); // true:비동기
	xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"); 
	
	frm.telcoReqNum.value = createReqNum(frm.telecom.value);
	xmlHttp.send("sendFlag="+sendflag+"&nation="+frm.nation.value+"&name="+encodeURIComponent(frm.name.value)+"&birth="+frm.birth.value+
	"&mdn="+frm.mdn.value+"&telecom="+frm.telecom.value+"&gender="+frm.gender.value+"&telcoReqNum="+frm.telcoReqNum.value);
}
function trim(str){
	   //정규 표현식을 사용하여 화이트스페이스를 빈문자로 전환
	   str = str.replace(/^\s*/,'').replace(/\s*$/, ''); 
	   return str; //변환한 스트링을 리턴.
}
function errSend(){
	var frm = document.form1;
	location.href = "./saveNsend.jsp?resultCd="+frm.resultCd.value+"&result="+encodeURIComponent(frm.result.value)+"&reCount=0&telcoReqNum="+frm.telcoReqNum.value+
		"&telecom="+frm.telecom.value+"&mdn="+frm.mdn.value;
}
function handleStateChange() {
	if(xmlHttp.readyState == 4) {
		if(xmlHttp.status == 200) {
			var frm = document.form1;
			var test = trim(xmlHttp.responseText);
			var data = test.split("\$");
			sendflag = "reSend";
			if(data[0] == "SUCCESS"){ 
				frm.resultCd.value = data[2];
				frm.result.value = "success";
				if(data[3]=="SKT"){
					 frm.telcoReqNum.value = createReqNum(frm.telecom.value);
					 //alert("frm.telcoReqNum.value"+frm.telcoReqNum.value);
					 frm.action = "./auth_pop_ok_sk.jsp";
					}else if(data[3]=="noSKT"){
					 frm.telcoReqNum.value = createReqNum(frm.telecom.value);
						frm.action = "./auth_pop_ok.jsp";
					}
				frm.submit()
			}else if(authCountCk == 5){
				frm.resultCd.value = "0016";
				frm.result.value = "5번 입력 실패";
				alert("본인인증에 5번 실패하였습니다.");
				setTimeout("errSend()",2000);
			} else if(data[0] == "FAIL"){
				if(data[2] =="noperson"){
					alert("전화번호 및 통신사를<br>확인하고 다시 시도해주세요.");
				}else if(data[2] == "corp"){
					alert("법인사용자 입니다.<br>확인하고 다시 시도해주세요.");
				}else if(data[2] == "prepay"){
					alert("선불과금 사용자 입니다.<br>확인하고 다시 시도해주세요.");
				}else if(data[2] =="pause"){
					alert("일시정지된 사용자 입니다.<br>확인하고 다시 시도해주세요.");
				}else if(data[2] =="nameErr"){
					alert("이름을 확인하고 다시 시도해주세요.");
				}else if(data[2] =="idErr"){
					alert("성별, 생년월일 등을<br>확인하고 다시 시도해주세요.");
				}else {
					alert("본인확인에 실패하였습니다.<br>확인하고 다시 시도해주세요.");
				}
				frm.resultCd.value = data[3];
				frm.result.value = "FAIL";
				setTimeout("errSend()",2000);
			}else if(data[0] == "REFAIL"){
				alert("SMS발송실패<br>잠시 후 다시 시도해 주시기 바랍니다.");
				frm.result.value = "smsFail";
				frm.resultCd.value = "0024";
				setTimeout("errSend()",2000);
			}else if(data[0] == "NETERR"){
				alert("일시적으로 통신사와 연결할 수 없습니다. <br>잠시 후 다시 시도해 주시기 바랍니다.");
				frm.result.value = "일시적통신사연결오류";
				frm.resultCd.value = "0018";
				setTimeout("errSend()",2000);
			} else if(data[0] == "DUP"){
				alert("중복인증 요청 입니다. <br>다시 시도해 주시기 바랍니다.");
				frm.result.value = "중복인증요청";
				frm.resultCd.value = "0032";
				setTimeout("errSend()",2000);
			}else if(data[0] == "REFAIL"){
				alert("SMS발송실패");
				frm.result.value = "smsFail";
				frm.resultCd.value = "0024";
				setTimeout("errSend()",2000);
			}else if(data[0] == "SYSFAIL"){
				alert("시스템 에러입니다. 관리자에게 문의하세요");
				frm.result.value = "system Error";
				frm.resultCd.value = "0025";
				setTimeout("errSend()",2000);
			}
		}
	}
}