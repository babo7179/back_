/*!
 파일명		: jquery.slideTab_ad.js
 기능설명	: AllCredit SlideTab Navigation
 작성자		: PULIP communications Interactive Part
 
 jquery.slideTab.js custom smartMedia grup
		
 최종수정일 : 2013-08-06 10:36
*/

var $slideTab = $('.slideTab'),
	$itemContainer = $slideTab.find('>div >ul'),
	$items = $itemContainer.find('li'),
	$prevBtn = $slideTab.find('.prev'),
	$nextBtn = $slideTab.find('.next');

/*
	itemText		: 각 메뉴 택스트 모음
	itemW			: 각 메뉴 너비 모음
	itemLen			: 메뉴 갯수
	currentPage		: 현재 페이지
	itemPerPage		: 한 페이지당 메뉴 갯수 ( 이동시 묶음 )
	maxPageNum		: 전체 페이지수  
	ellipsisIdx			: 글자 줄임이 적용된 메뉴 인덱스
	btnW			: 이전페이지 버튼의 너비
	isShowPrevBtn	: 이전페이지 버튼 화면출력 여부 
*/
var itemText = [],
	itemW = [],
	itemLen = 0,
	currentItem = 0,
	currentPage = 0,
	itemPerPage = 1,
	maxPageNum = 0,
	ellipsisIdx = -1,
	lastMoveIdx = -1,
	btnW = 0,
	containerW = 0,
	isShowPrevBtn = true,
	isFirst = true,
	enabledBtnClick = true,
	enabledMove = true;

var moveSpeed = 300;
/* 2013-07-18
$(document).ready(function(){
	init();
});
*/
/*-----------------------------------------------------------------------------*\
  Init
\*-----------------------------------------------------------------------------*/
function init_ad(){
		/*-- init ------------------------------------------*/

	// tab width
	containerW = $slideTab.width();
	
	// Tab item 각각의 너비 및 텍스트 저장
	$items.find('>a:eq(0)').each(function(){
		itemText.push( $(this).text() );
		itemW.push( $(this).outerWidth() + 1 );
		itemLen++;
	});
	if( itemLen < 1 ){ return; }

	// page 
	currentPage = getCurrentPage();
	maxPageNum = Math.ceil( itemLen / itemPerPage ) - 1;

	$('.tabCntASlideSub > ul').hide();
	$('.tabCntASlideSub > ul:eq(' + getCurrentPage() + ')').fadeIn();
	move();
	// btn 
	// get width
	if( $prevBtn.length > 0 ){ btnW = $prevBtn.width(); }
	if( currentPage == 0 ){ 
	//	hidePrevBtn(); 
	}
	//if( maxPageNum < 1 ){ hideNextBtn(); }

	
	/*-- tabEvent ------------------------------------------*/
	function itemsEvent( el ){
		el.parent().siblings('li').removeClass("open");
		el.parent().addClass("open");

		var contents = el.parent().parent().parent().parent().parent().find('> .tabCntASlideSub > ul');
		contents.hide();
		contents.eq( el.parent().index()).fadeIn();
	}
	
	// prev btn
	$prevBtn.click(function(e){
		e.preventDefault();
		if( enabledBtnClick ){
			if( enabledMove || currentItem == (currentPage) ){
				if( currentPage > 0 ){
					currentPage--;
				}
				move();
				enabledBtnClick = false;
			}
			if( currentItem > 0 ){
				currentItem--;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});

	// next btn
	$nextBtn.click(function(e){
		e.preventDefault();
		
		if( enabledBtnClick ){
			
			if( currentPage < maxPageNum && enabledMove ){ 
				currentPage++;
				move();
				enabledBtnClick = false;
			}

			if( currentItem < itemLen - 1 ){
				currentItem++;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});
	
	

	// resize
	$(window).resize(function(e){
		resizeHandler();
	});
	
	/*--------------------------------------------*/
	$(window).trigger( "resize" );
}

function init(){
	/*-- init ------------------------------------------*/

	// tab width
	containerW = $slideTab.width();
	
	// Tab item 각각의 너비 및 텍스트 저장
	$items.find('>a:eq(0)').each(function(){
		itemText.push( $(this).text() );
		itemW.push( $(this).outerWidth() + 1 );
		itemLen++;
	});
	if( itemLen < 1 ){ return; }

	// page 
	currentPage = getCurrentPage();
	maxPageNum = Math.ceil( itemLen / itemPerPage ) - 1;

	$('.tabCntASlideSub > ul').hide();
	$('.tabCntASlideSub > ul:eq(' + getCurrentPage() + ')').fadeIn();
	move();
	// btn 
	// get width
	if( $prevBtn.length > 0 ){ btnW = $prevBtn.width(); }
	if( currentPage == 0 ){ 
	//	hidePrevBtn(); 
	}
	//if( maxPageNum < 1 ){ hideNextBtn(); }

	
	/*-- tabEvent ------------------------------------------*/
	function itemsEvent( el ){
		el.parent().siblings('li').removeClass("open");
		el.parent().addClass("open");

		var contents = el.parent().parent().parent().parent().parent().find('> .tabCntASlideSub > ul');
		contents.hide();
		contents.eq( el.parent().index()).fadeIn();
	}
	
	// prev btn
	$prevBtn.click(function(e){
		e.preventDefault();
		if( enabledBtnClick ){
			if( enabledMove || currentItem == (currentPage) ){
				if( currentPage > 0 ){
					currentPage--;
				}
				move();
				enabledBtnClick = false;
			}
			if( currentItem > 0 ){
				currentItem--;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});

	// next btn
	$nextBtn.click(function(e){
		e.preventDefault();
		
		if( enabledBtnClick ){
			
			if( currentPage < maxPageNum && enabledMove ){ 
				currentPage++;
				move();
				enabledBtnClick = false;
			}

			if( currentItem < itemLen - 1 ){
				currentItem++;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});
	
	

	// resize
	$(window).resize(function(e){
		resizeHandler();
	});
	
	/*--------------------------------------------*/
	$(window).trigger( "resize" );
}

/*-----------------------------------------------------------------------------*\
  Func
\*-----------------------------------------------------------------------------*/
/**
 * Tab 아이템 이동
 */
function move(speed){
	var pos = 0;

	// prevBtn visible
	//currentPage == 0 ? hidePrevBtn() : showPrevBtn();
	// nextBtn visible
	//currentPage == maxPageNum ? hideNextBtn() : showNextBtn();
	
	if( isFirst ){
		getPageIdx();
	}

	for( var i=0, len=itemPerPage*currentPage; i<len; i++ ){
		pos -= itemW[i];		
	}

	setOrginItemText();

	if( isFirst ){
		isFirst = false;
		$itemContainer.stop().animate( {"left":pos+"px"}, 0, function(){ setEllipsisItemText(); enabledBtnClick = true; } ); 
	} else {
		$itemContainer.stop().animate( {"left":pos+"px"}, moveSpeed, function(){ setEllipsisItemText(); enabledBtnClick = true; } ); 
	}
}


/**
 * 다음버튼과 겹쳐지는 아이템 텍스트 생략 
 */
function setEllipsisItemText(){
	// 겹쳐지는 아이템 인덱스
	containerW = $slideTab.width() + 7;
	//var w = ( !isShowPrevBtn ) ? -(btnW) : 0;
	var w = 0;
	ellipsisIdx = -1;
	for( var i=itemPerPage*currentPage, len=itemW.length; i < len; i++ ){
		w += itemW[i];
		if( w >= containerW ){
			w -= itemW[i];
			ellipsisIdx = i;
			break;	
		}
	}

	// 겹쳐질 경우 텍스트 줄임
	if( ellipsisIdx != -1 ){
		var tmpItemText = "", item = $items.eq(ellipsisIdx).find('>a:eq(0)');
		for( var i=0, len=itemText[ellipsisIdx].length; i < len; i++ ){
			tmpItemText = getEllipsisText( itemText[ellipsisIdx], i );
			item.text( tmpItemText );
			if( w + item.outerWidth() > containerW ){ break; }
		}
		enabledMove = true;
		showNextBtn();
	} else {
		enabledMove = false;
		// nextBtn visible
		//hideNextBtn();
	}
}

var isShowAll = false;
function getPageIdx(){
	var w = ( !isShowPrevBtn ) ? -(btnW) : 0,
		idx = -1;
	for( var i=itemPerPage*currentPage, len=itemW.length; i < len; i++ ){
		w += itemW[i];
		if( w > containerW ){
			idx = i;
			break;
		}
	}
	if( idx == -1 && currentPage != 0 )
	{
		isShowAll = true;
		currentPage--;
		getPageIdx();
	} else {
		if( isShowAll ){
			currentPage++;
			isPos = false;
		}
	}
}

function setMoveLastIdx(){
	var w = 0;
	lastMoveIdx = -1;
	for( var i=itemW.length - 1; i > 0; i-- ){
		w += itemW[i];
		if( w >= containerW ){
			w -= itemW[i];
			lastMoveIdx = i;
			break;	
		}
	}
}

/**
 * 생략했던 텍스트 복구
 */
function setOrginItemText(){
	if( ellipsisIdx != -1 ){ 
		$items.eq(ellipsisIdx).find('>a:eq(0)').text( itemText[ellipsisIdx] );
	}
}

/**
 * 이전 버튼 화면에 출력
 */
function showPrevBtn(){
	if( !isShowPrevBtn ){
		isShowPrevBtn = true;
		$prevBtn.css( "display", "block" );
		if( $slideTab.hasClass("left") ){
			$slideTab.removeClass("left");
		}
	}
}

/**
 * 이전 버튼 화면에서 숨김
 */
function hidePrevBtn(){
	isShowPrevBtn = false;
	$prevBtn.css( "display", "none" );
	$slideTab.addClass("left");
}

/**
 * 다음 버튼 화면에 출력
 */
function showNextBtn(){
	$nextBtn.css( "display", "block" );
	if( $slideTab.hasClass("right") ){
		$slideTab.removeClass("right");
	}
}

/**
 * 다음 버튼 화면에서 숨김
 */
function hideNextBtn(){
	$nextBtn.css( "display", "none" );
	$slideTab.addClass("right");
}

/*-----------------------------------------------------------------------------*\
  Event Handlers
\*-----------------------------------------------------------------------------*/
/**
 * window resize 이벤트 발생시
 */
function resizeHandler(){
	containerW = $slideTab.width();
	setMoveLastIdx();
	setOrginItemText();
	//setEllipsisItemText();
	move();
}

/*-----------------------------------------------------------------------------*\
  Utils
\*-----------------------------------------------------------------------------*/
/**
 * 글자 길이에 따라 생략하고 대체문자 추가
 *
 * @param str 			: 변환할 글자
 * @param maxLen		: 표시될 최대 글자 수
 * @param symbol		: 최대 글자수 이후 표시될 기호 ( 기본값 : ... )
 */
function getEllipsisText( str, maxLen, symbol ){
	if( !symbol ){ symbol = "..."; }
	if( str.length <= maxLen ){
		return str;
	}
	return str.substr(0, maxLen)+ symbol;
} 

/**
 * 현재 보이는 페이지 반환
 */
function getCurrentPage(){
	var idx = 0;
	for( var i=0, len=itemW.length; i < len; i++ ){
		if( $items.eq(i).hasClass("open") ){
			idx = i;
			currentItem = i;
			break;
		}
	}
	

	/*- open 위치가 첫번째 자리가 아닐 경우를 위한 코드-------------------------------------------*/
	/*
	var num = Math.floor( idx / itemPerPage );
	return num - ( num - getViewFirst(num) );
	*/
	/*--------------------------------------------*/
	
	return Math.floor( idx / itemPerPage );
}

/**
 * 페이지 로드시 실제 보이는 순서상 1번째 메뉴의 인덱스
 *
 * @param openIdx		: 활성화된 인덱스
 */
function getViewFirst(openIdx)
{
	if( !openIdx ){ return 0 ; }
	var pos = ( !isShowPrevBtn ) ? btnW : 0; 
	for( var i = 0; i < openIdx; i++){
		pos -= itemW[i];
	}
	
	if( pos < $itemContainer.position().left ){
		return getViewFirst( openIdx - 1 );
	}
	return openIdx + 1;
}