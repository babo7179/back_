/*!
 파일명		: jquery.touchSwipe.js
 기능설명	: 올크래딧 스크롤 리스트 swipe효과
 작성자		: PULIP communications Interactive Part
 최종수정일 : 2013-06-10

http://labs.rampinteractive.co.uk/touchSwipe/demos/
$(function() {      
  //Enable swiping...
  $("#test").swipe( {
	//Generic swipe handler for all directions
	swipe:function(event, direction, distance, duration, fingerCount) {
	  $(this).text("You swiped " + direction );  
	},
	//Default is 75px, set to 0 for demo so any distance triggers swipe
	 threshold:0
  });
});

*/

(function(e){var o="left",n="right",d="up",v="down",c="in",w="out",l="none",r="auto",k="swipe",s="pinch",x="tap",i="doubletap",b="longtap",A="horizontal",t="vertical",h="all",q=10,f="start",j="move",g="end",p="cancel",a="ontouchstart" in window,y="TouchSwipe";var m={fingers:1,threshold:75,cancelThreshold:25,pinchThreshold:20,maxTimeThreshold:null,fingerReleaseThreshold:250,longTapThreshold:500,doubleTapThreshold:200,swipe:null,swipeLeft:null,swipeRight:null,swipeUp:null,swipeDown:null,swipeStatus:null,pinchIn:null,pinchOut:null,pinchStatus:null,click:null,tap:null,doubleTap:null,longTap:null,triggerOnTouchEnd:true,triggerOnTouchLeave:false,allowPageScroll:"auto",fallbackToMouseEvents:true,excludedElements:"button, input, select, textarea, a, .noSwipe"};e.fn.swipe=function(D){var C=e(this),B=C.data(y);if(B&&typeof D==="string"){if(B[D]){return B[D].apply(this,Array.prototype.slice.call(arguments,1))}else{e.error("Method "+D+" does not exist on jQuery.swipe")}}else{if(!B&&(typeof D==="object"||!D)){return u.apply(this,arguments)}}return C};e.fn.swipe.defaults=m;e.fn.swipe.phases={PHASE_START:f,PHASE_MOVE:j,PHASE_END:g,PHASE_CANCEL:p};e.fn.swipe.directions={LEFT:o,RIGHT:n,UP:d,DOWN:v,IN:c,OUT:w};e.fn.swipe.pageScroll={NONE:l,HORIZONTAL:A,VERTICAL:t,AUTO:r};e.fn.swipe.fingers={ONE:1,TWO:2,THREE:3,ALL:h};function u(B){if(B&&(B.allowPageScroll===undefined&&(B.swipe!==undefined||B.swipeStatus!==undefined))){B.allowPageScroll=l}if(B.click!==undefined&&B.tap===undefined){B.tap=B.click}if(!B){B={}}B=e.extend({},e.fn.swipe.defaults,B);return this.each(function(){var D=e(this);var C=D.data(y);if(!C){C=new z(this,B);D.data(y,C)}})}function z(a0,aq){var av=(a||!aq.fallbackToMouseEvents),G=av?"touchstart":"mousedown",au=av?"touchmove":"mousemove",R=av?"touchend":"mouseup",P=av?null:"mouseleave",az="touchcancel";var ac=0,aL=null,Y=0,aX=0,aV=0,D=1,am=0,aF=0,J=null;var aN=e(a0);var W="start";var T=0;var aM=null;var Q=0,aY=0,a1=0,aa=0,K=0;var aS=null;try{aN.bind(G,aJ);aN.bind(az,a5)}catch(ag){e.error("events not supported "+G+","+az+" on jQuery.swipe")}this.enable=function(){aN.bind(G,aJ);aN.bind(az,a5);return aN};this.disable=function(){aG();return aN};this.destroy=function(){aG();aN.data(y,null);return aN};this.option=function(a7,a6){if(aq[a7]!==undefined){if(a6===undefined){return aq[a7]}else{aq[a7]=a6}}else{e.error("Option "+a7+" does not exist on jQuery.swipe.options")}};function aJ(a8){if(ax()){return}if(e(a8.target).closest(aq.excludedElements,aN).length>0){return}var a9=a8.originalEvent?a8.originalEvent:a8;var a7,a6=a?a9.touches[0]:a9;W=f;if(a){T=a9.touches.length}else{a8.preventDefault()}ac=0;aL=null;aF=null;Y=0;aX=0;aV=0;D=1;am=0;aM=af();J=X();O();if(!a||(T===aq.fingers||aq.fingers===h)||aT()){ae(0,a6);Q=ao();if(T==2){ae(1,a9.touches[1]);aX=aV=ap(aM[0].start,aM[1].start)}if(aq.swipeStatus||aq.pinchStatus){a7=L(a9,W)}}else{a7=false}if(a7===false){W=p;L(a9,W);return a7}else{ak(true)}}function aZ(a9){var bc=a9.originalEvent?a9.originalEvent:a9;if(W===g||W===p||ai()){return}var a8,a7=a?bc.touches[0]:bc;var ba=aD(a7);aY=ao();if(a){T=bc.touches.length}W=j;if(T==2){if(aX==0){ae(1,bc.touches[1]);aX=aV=ap(aM[0].start,aM[1].start)}else{aD(bc.touches[1]);aV=ap(aM[0].end,aM[1].end);aF=an(aM[0].end,aM[1].end)}D=a3(aX,aV);am=Math.abs(aX-aV)}if((T===aq.fingers||aq.fingers===h)||!a||aT()){aL=aH(ba.start,ba.end);ah(a9,aL);ac=aO(ba.start,ba.end);Y=aI();aE(aL,ac);if(aq.swipeStatus||aq.pinchStatus){a8=L(bc,W)}if(!aq.triggerOnTouchEnd||aq.triggerOnTouchLeave){var a6=true;if(aq.triggerOnTouchLeave){var bb=aU(this);a6=B(ba.end,bb)}if(!aq.triggerOnTouchEnd&&a6){W=ay(j)}else{if(aq.triggerOnTouchLeave&&!a6){W=ay(g)}}if(W==p||W==g){L(bc,W)}}}else{W=p;L(bc,W)}if(a8===false){W=p;L(bc,W)}}function I(a6){var a7=a6.originalEvent;if(a){if(a7.touches.length>0){C();return true}}if(ai()){T=aa}a6.preventDefault();aY=ao();Y=aI();if(aq.triggerOnTouchEnd||(aq.triggerOnTouchEnd==false&&W===j)){W=g;L(a7,W)}else{if(!aq.triggerOnTouchEnd&&a2()){W=g;aB(a7,W,x)}else{if(W===j){W=p;L(a7,W)}}}ak(false)}function a5(){T=0;aY=0;Q=0;aX=0;aV=0;D=1;O();ak(false)}function H(a6){var a7=a6.originalEvent;if(aq.triggerOnTouchLeave){W=ay(g);L(a7,W)}}function aG(){aN.unbind(G,aJ);aN.unbind(az,a5);aN.unbind(au,aZ);aN.unbind(R,I);if(P){aN.unbind(P,H)}ak(false)}function ay(a9){var a8=a9;var a7=aw();var a6=aj();if(!a7){a8=p}else{if(a6&&a9==j&&(!aq.triggerOnTouchEnd||aq.triggerOnTouchLeave)){a8=g}else{if(!a6&&a9==g&&aq.triggerOnTouchLeave){a8=p}}}return a8}function L(a8,a6){var a7=undefined;if(F()){a7=aB(a8,a6,k)}else{if(M()&&a7!==false){a7=aB(a8,a6,s)}}if(aC()&&a7!==false){a7=aB(a8,a6,i)}else{if(al()&&a7!==false){a7=aB(a8,a6,b)}else{if(ad()&&a7!==false){a7=aB(a8,a6,x)}}}if(a6===p){a5(a8)}if(a6===g){if(a){if(a8.touches.length==0){a5(a8)}}else{a5(a8)}}return a7}function aB(a9,a6,a8){var a7=undefined;if(a8==k){aN.trigger("swipeStatus",[a6,aL||null,ac||0,Y||0,T]);if(aq.swipeStatus){a7=aq.swipeStatus.call(aN,a9,a6,aL||null,ac||0,Y||0,T);if(a7===false){return false}}if(a6==g&&aR()){aN.trigger("swipe",[aL,ac,Y,T]);if(aq.swipe){a7=aq.swipe.call(aN,a9,aL,ac,Y,T);if(a7===false){return false}}switch(aL){case o:aN.trigger("swipeLeft",[aL,ac,Y,T]);if(aq.swipeLeft){a7=aq.swipeLeft.call(aN,a9,aL,ac,Y,T)}break;case n:aN.trigger("swipeRight",[aL,ac,Y,T]);if(aq.swipeRight){a7=aq.swipeRight.call(aN,a9,aL,ac,Y,T)}break;case d:aN.trigger("swipeUp",[aL,ac,Y,T]);if(aq.swipeUp){a7=aq.swipeUp.call(aN,a9,aL,ac,Y,T)}break;case v:aN.trigger("swipeDown",[aL,ac,Y,T]);if(aq.swipeDown){a7=aq.swipeDown.call(aN,a9,aL,ac,Y,T)}break}}}if(a8==s){aN.trigger("pinchStatus",[a6,aF||null,am||0,Y||0,T,D]);if(aq.pinchStatus){a7=aq.pinchStatus.call(aN,a9,a6,aF||null,am||0,Y||0,T,D);if(a7===false){return false}}if(a6==g&&a4()){switch(aF){case c:aN.trigger("pinchIn",[aF||null,am||0,Y||0,T,D]);if(aq.pinchIn){a7=aq.pinchIn.call(aN,a9,aF||null,am||0,Y||0,T,D)}break;case w:aN.trigger("pinchOut",[aF||null,am||0,Y||0,T,D]);if(aq.pinchOut){a7=aq.pinchOut.call(aN,a9,aF||null,am||0,Y||0,T,D)}break}}}if(a8==x){if(a6===p||a6===g){clearTimeout(aS);if(V()&&!E()){K=ao();aS=setTimeout(e.proxy(function(){K=null;aN.trigger("tap",[a9.target]);if(aq.tap){a7=aq.tap.call(aN,a9,a9.target)}},this),aq.doubleTapThreshold)}else{K=null;aN.trigger("tap",[a9.target]);if(aq.tap){a7=aq.tap.call(aN,a9,a9.target)}}}}else{if(a8==i){if(a6===p||a6===g){clearTimeout(aS);K=null;aN.trigger("doubletap",[a9.target]);if(aq.doubleTap){a7=aq.doubleTap.call(aN,a9,a9.target)}}}else{if(a8==b){if(a6===p||a6===g){clearTimeout(aS);K=null;aN.trigger("longtap",[a9.target]);if(aq.longTap){a7=aq.longTap.call(aN,a9,a9.target)}}}}}return a7}function aj(){var a6=true;if(aq.threshold!==null){a6=ac>=aq.threshold}if(a6&&aq.cancelThreshold!==null){a6=(aP(aL)-ac)<aq.cancelThreshold}return a6}function ab(){if(aq.pinchThreshold!==null){return am>=aq.pinchThreshold}return true}function aw(){var a6;if(aq.maxTimeThreshold){if(Y>=aq.maxTimeThreshold){a6=false}else{a6=true}}else{a6=true}return a6}function ah(a6,a7){if(aq.allowPageScroll===l||aT()){a6.preventDefault()}else{var a8=aq.allowPageScroll===r;switch(a7){case o:if((aq.swipeLeft&&a8)||(!a8&&aq.allowPageScroll!=A)){a6.preventDefault()}break;case n:if((aq.swipeRight&&a8)||(!a8&&aq.allowPageScroll!=A)){a6.preventDefault()}break;case d:if((aq.swipeUp&&a8)||(!a8&&aq.allowPageScroll!=t)){a6.preventDefault()}break;case v:if((aq.swipeDown&&a8)||(!a8&&aq.allowPageScroll!=t)){a6.preventDefault()}break}}}function a4(){var a7=aK();var a6=U();var a8=ab();return a7&&a6&&a8}function aT(){return !!(aq.pinchStatus||aq.pinchIn||aq.pinchOut)}function M(){return !!(a4()&&aT())}function aR(){var a8=aw();var ba=aj();var a7=aK();var a6=U();var a9=a6&&a7&&ba&&a8;return a9}function S(){return !!(aq.swipe||aq.swipeStatus||aq.swipeLeft||aq.swipeRight||aq.swipeUp||aq.swipeDown)}function F(){return !!(aR()&&S())}function aK(){return((T===aq.fingers||aq.fingers===h)||!a)}function U(){return aM[0].end.x!==0}function a2(){return !!(aq.tap)}function V(){return !!(aq.doubleTap)}function aQ(){return !!(aq.longTap)}function N(){if(K==null){return false}var a6=ao();return(V()&&((a6-K)<=aq.doubleTapThreshold))}function E(){return N()}function at(){return((T===1||!a)&&(isNaN(ac)||ac===0))}function aW(){return((Y>aq.longTapThreshold)&&(ac<q))}function ad(){return !!(at()&&a2())}function aC(){return !!(N()&&V())}function al(){return !!(aW()&&aQ())}function C(){a1=ao();aa=event.touches.length+1}function O(){a1=0;aa=0}function ai(){var a6=false;if(a1){var a7=ao()-a1;if(a7<=aq.fingerReleaseThreshold){a6=true}}return a6}function ax(){return !!(aN.data(y+"_intouch")===true)}function ak(a6){if(a6===true){aN.bind(au,aZ);aN.bind(R,I);if(P){aN.bind(P,H)}}else{aN.unbind(au,aZ,false);aN.unbind(R,I,false);if(P){aN.unbind(P,H,false)}}aN.data(y+"_intouch",a6===true)}function ae(a7,a6){var a8=a6.identifier!==undefined?a6.identifier:0;aM[a7].identifier=a8;aM[a7].start.x=aM[a7].end.x=a6.pageX||a6.clientX;aM[a7].start.y=aM[a7].end.y=a6.pageY||a6.clientY;return aM[a7]}function aD(a6){var a8=a6.identifier!==undefined?a6.identifier:0;var a7=Z(a8);a7.end.x=a6.pageX||a6.clientX;a7.end.y=a6.pageY||a6.clientY;return a7}function Z(a7){for(var a6=0;a6<aM.length;a6++){if(aM[a6].identifier==a7){return aM[a6]}}}function af(){var a6=[];for(var a7=0;a7<=5;a7++){a6.push({start:{x:0,y:0},end:{x:0,y:0},identifier:0})}return a6}function aE(a6,a7){a7=Math.max(a7,aP(a6));J[a6].distance=a7}function aP(a6){return J[a6].distance}function X(){var a6={};a6[o]=ar(o);a6[n]=ar(n);a6[d]=ar(d);a6[v]=ar(v);return a6}function ar(a6){return{direction:a6,distance:0}}function aI(){return aY-Q}function ap(a9,a8){var a7=Math.abs(a9.x-a8.x);var a6=Math.abs(a9.y-a8.y);return Math.round(Math.sqrt(a7*a7+a6*a6))}function a3(a6,a7){var a8=(a7/a6)*1;return a8.toFixed(2)}function an(){if(D<1){return w}else{return c}}function aO(a7,a6){return Math.round(Math.sqrt(Math.pow(a6.x-a7.x,2)+Math.pow(a6.y-a7.y,2)))}function aA(a9,a7){var a6=a9.x-a7.x;var bb=a7.y-a9.y;var a8=Math.atan2(bb,a6);var ba=Math.round(a8*180/Math.PI);if(ba<0){ba=360-Math.abs(ba)}return ba}function aH(a7,a6){var a8=aA(a7,a6);if((a8<=45)&&(a8>=0)){return o}else{if((a8<=360)&&(a8>=315)){return o}else{if((a8>=135)&&(a8<=225)){return n}else{if((a8>45)&&(a8<135)){return v}else{return d}}}}}function ao(){var a6=new Date();return a6.getTime()}function aU(a6){a6=e(a6);var a8=a6.offset();var a7={left:a8.left,right:a8.left+a6.outerWidth(),top:a8.top,bottom:a8.top+a6.outerHeight()};return a7}function B(a6,a7){return(a6.x>a7.left&&a6.x<a7.right&&a6.y>a7.top&&a6.y<a7.bottom)}}})(jQuery);
// allcredit 스크롤 부분 동작
;$(function(){
	$(window).load(function(){
		var ua = navigator.userAgent,
			chkUpDown = false;
		//console.log( ua );
		if( ua.indexOf("Android") >= 0 )
		{
			var androidversion = parseFloat(ua.slice(ua.indexOf("Android")+8)); 
			if (androidversion < 3.0){ chkUpDown = true }
		}
		
		var current = 0,
			max = 0,
			itemContainer = $('.productSample').find('>div >ul'),
			itemW = 0,
			transitionTime = 500;
		 
		if( itemContainer.length < 1 ){ return; }
		itemContainer.css("position","absolute");
		max = itemContainer.find('>li').length;
		if( max < 2 ){ return; }
		itemW = itemContainer.find('>li:eq(0)').outerWidth();
		$('.productSample').swipe( {
			swipeLeft:function(event, direction, distance, duration, fingerCount) {
				if( current < ( max - 1 ) ){
					current++;
					moveItem();
				}
			},
			swipeRight:function(event, direction, distance, duration, fingerCount) {
				if( current > 0 ){
					current--;
					moveItem();
				}
			},
			allowPageScroll:"auto"
		});
		function moveItem(){
		itemContainer.css({
			"left":( -(itemW) * current ) + "px" ,
			"-moz-transition":transitionTime + "ms",
			"-moz-transform":"",
			"-webkit-transition":transitionTime + "ms",
			"-webkit-transform":"",
			"-o-transition":transitionTime + "ms",
			"-o-transform":"",
			"-ms-transition":transitionTime + "ms",
			"-ms-transform":"",
			"transition":transitionTime + "ms",
			"transform":"",
		});
		//itemContainer.animate({left: ( -(itemW) * current ) + "px"}, transitionTime, function(){} );	
	}
	});
});