/*!
 ���ϸ�		: lending_interest_rate_linear.js
 ��ɼ���	: AllCredit Polygon Graph
 �ۼ���		: PULIP communications Interactive Part
		
 ���������� : 2013-06-12	15:00  >  �޾ƿ��� Data json -> obj ���·� ����
*/
$( document ).ready( function() { 

	_linkMakeLinearGraph = makeLinearGraph;

	var _jsonData;
	var graphDataUrl = '';
	var graphCon = null;
	var graphConName = '';
	
	//function makeLinearGraph( jsonUrl, classOrIdName ) {
	function makeLinearGraph( data, classOrIdName ) {
		/*
		graphDataUrl = jsonUrl;
		graphCon = $( classOrIdName );
		
		$.ajax ({
			url : graphDataUrl,
			dataType : 'json',
			success: function( data ) {
				_jsonData = data;
				init ();
			},
			error: function( data ) {
				alert( 'ERROR: ' + data );
			}
		});
		*/
		graphCon = $( classOrIdName );
		_jsonData = data;
		init ();
	}

	function init () {
		$( window ).resize( function () { 
			resizeHn ();
		});
		
		makeLinearGraphDOM ();

		resizeHn ();
		// animate 
		var ts = 1500;
		var graphEasing = 'easeInOutQuad';
		
		var len = _jsonData[1].list.length;
		for ( var i = 0; i < len; i ++ ) {
				
			/*
				var mask = $( '.bar_mask' ).eq( i );
			*/
			var mask = graphCon.find( '.bar_mask' ).eq( i );
			mask.css({ 
				'width':'0%',
				'overflow':'hidden'
			});
			mask.animate ({ width: _jsonData[1].list[i][0] + '%' }, { duration: ts, easing: graphEasing });
		}
	}

	function makeLinearGraphDOM () {
		var linearDOM = '';
		var lineDOM = '';
		var liDOM = '';
		var len = _jsonData[1].list.length;
		var listAry = _jsonData[1].list;

		for ( var i = 0; i < len; i ++ ) {
			linearDOM += '<h4>' + listAry[i][1] + ' <mark>' + listAry[i][2] + '</mark></h4>'
			linearDOM += '<div class="graph">'
			linearDOM += '	<div class="bar_mask"">';
			linearDOM += '		<div class="bar" style="width:100%;"></div>';
			linearDOM += '	</div>'
			linearDOM += '</div>'
			linearDOM += '<ul class="legend"></ul>'
			
			if ( i != len-1 ) linearDOM += '<hr class="hrGraph">';
			
			var addLen = _jsonData[1].list[i][3].length;

			graphCon.append ( linearDOM );

			linearDOM = '';

			setAdditionalList( addLen, i );
		}

		function setAdditionalList ( length, n ) {
			for ( var i = 0; i < length; i ++ ) {
				/*
				var con = $( '.legend' ).eq( i );
				*/
				var con = graphCon.find( '.legend' ).eq( i );
				var per = 100 / length + '%';
				lineDOM += '<span class="line" style="left:' + 100/length * i + '%' +'"></span>';
				liDOM += '<li style=";width:' + per + ';">' + listAry[n][3][i] + '</li>';
			}
			//$( '.legend' ).eq( n ).append ( liDOM );
			//$( '.graph' ).eq( n ).append ( lineDOM );
			graphCon.find( '.legend' ).eq( n ).append ( liDOM );
			graphCon.find( '.graph' ).eq( n ).append ( lineDOM );
			lineDOM = '';
			liDOM = '';
		}
	}

	function resizeHn () {
		
		//var sw = $( window ).width ();
		var sw = 0;
		for( var k=0; k < $(".graphBar").length; k++ ){
			if( $(".graphBar").eq(k).width() != 0 ){
				sw = $(".graphBar").eq(k).width(); //$( window ).width ();
			}
		}
		for( var j=0; j < $(".graphBar").length; j++ ){
			var len = $(".graphBar").eq(j).find( '.graph' ).length; //_jsonData[1].list.length;
			
			for ( var i = 0; i < len; i ++ ) {
				/*
				var graph = $( '.graph' ).eq( i );
				*/
				
				var graph =  $(".graphBar").eq(j).find( '.graph' ).eq( i );
				graph.css( 'width', sw - 21 + 'px' );
				graph.find( '.bar' ).css( 'width', sw - 22 );
			}
		}
	}
});

var _linkMakeLinearGraph;
function makeLinearGraph ( jsonUrl, classOrIdName ) {
	
	if ( _linkMakeLinearGraph != null && typeof _linkMakeLinearGraph == 'function' ) {
		_linkMakeLinearGraph.apply ( null, [ jsonUrl, classOrIdName ] );	
	}
}