/*���������� :2013-08-02 3:43 */

//loading ani
var load_is = true;
var loadFrame = 0, loadTotalFrame = 6;

//�ε�ȭ�� ����
function loadAdd(){
	var loadingPage = '<div class="loading" style="position:fixed;left:0px;top:0px;bottom:0px;width:100%;height:200%;z-index:1000;">';
	loadingPage += '<div class="lodingIcon" style="display:block;position:absolute;left:50%;top:25%;width:60px;height:68px;margin-left:-30px;margin-top:-34px;background:url(/mr/img/common/loading.png) no-repeat 0px 0px;background-size:480px 68px;z-index:1001;"></div>';
	loadingPage += '</div>';

	$( loadingPage ).insertBefore("head");
}

$(function(){
	loadAdd();
	setTimeout( loadAni, 300 );
}());

function loadAni(){
	( loadFrame == loadTotalFrame )? loadFrame = 0 : loadFrame++;
	$(".lodingIcon").css({"background-position" : "-" + ( loadFrame * 60 ) + "px 0px"})
	if( load_is ) setTimeout( loadAni, 300 );
}

//IOS ����Ʈ���� �ڵ鷯 2013-07-26
$.fn.quickChange = function(handler) {
    return this.each(function() {
        var self = this;
        self.qcindex = self.selectedIndex;
        var interval;
        function handleChange() {
            if (self.selectedIndex != self.qcindex) {
                self.qcindex = self.selectedIndex;
                handler.apply(self);
            }
        }
        $(self).focus(function() {
            interval = setInterval(handleChange, 100);
        }).blur(function() { window.clearInterval(interval); })
        .change(handleChange);
    });
};
//����ȭ function : e

// �ּ�â������, loading animation 
window.addEventListener('load', function() {
	//loading animation
	setTimeout( function(){
		load_is = false;
		$(".loading").animate({opacity: 0}, 300, function(){ $(".loading").remove() });
	}, 500 );
	$( "body" ).css("visibility", "visible");

	//hash ���̿��� 
	if ( window.location.hash ) {
		//if ( typeof($(window.location.hash) ) != "undefined" && $(window.location.hash).offsetTop != "undefined") {	}
	} else {
		//#�����ð�� üũ Ÿ�Ծ���
		setTimeout(scrollTo, 0, 0, 1);
	}
}, false);


$(document).ready(function() {	
});

function layerPush(open){
	if($("#" + open).css("display") == "none"){
		$("#" + open).animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeOutBack"});
	}else{
		$("#" + open).animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
	}
}
function layerPushOpen(open){
	$("#" + open).slideDown();
}
function layerPushClose(open){
	$("#" + open).slideUp();
}
function layerHideShow(hide, show){
	$("#" + hide).hide();
	$("#" + show).fadeIn();
}
function resize(){
}
//////////////////// load�� ���� ////////////////////
window.onload = function(){
	//$("input").off('keyup');
	
	// iOS
	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
		$(".container").addClass("iOS");
	}
	//Android
	if((navigator.userAgent.match(/Android/i))){
		$(".container").addClass("android");
		
		// GalexyS2
		if( (navigator.userAgent.indexOf("SHW-M250")) != -1 ){
			$(".container").addClass("galexyS2");
		}
	}

	//2013-07-16 main ��� ���� �ݱ�
	$(".appAD > .btnClose").bind("click", function(e){
		e.preventDefault();
		$(".appAD").addClass("none");
	})
	
	// skip nav
	$('.skipNavi').focus(function(){
		$(this).css("marginTop",0);
	}).blur(function(){
		$(this).css("marginTop","-30px");
	});

	//nav
	/* s : �޴� 2Depth / 3Depth ���� : 20130605 */
	$("nav > .nav > h2 > a").click(function(){
		var idx = $(this).parent().parent().find("> h2").index($(this).parent());
		
		if (!$(this).parent().hasClass("on")){

			$(this).parent().parent().find("h2").removeClass("on");
			$(this).parent().addClass("on");
			
			
			if (idx == 0 && $(this).parent().hasClass("on")){
				$(this).parent().parent().parent().find(".depthSelect").animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
				/*
				current2DepIdx = 1;
				$(this).parent().parent().parent().find(".depthSelect > li:eq(0)").text( $(this).parent().parent().parent().find(".depth2 li:eq(0)" ).text() ); 
				$(this).parent().parent().parent().find(".depthSelect > li:eq(1)").text( $(this).parent().parent().parent().find(".depth3 .depth3-1 li:eq(0)" ).text() ); 
				*/
			}else{
				$(this).parent().parent().parent().find(".depthSelect").fadeOut();
				$(this).parent().parent().parent().find(".depthSelect li").removeClass("open");
				$(this).parent().parent().parent().find(".depth2").fadeOut();
				$(this).parent().parent().parent().find(".depth3").fadeOut();
			}
		}
	});

	// dep2 init
	var current2DepIdx;// = getDep2Index($("nav .depth2 li:eq(0)" ).attr("class"));

	if( $("nav .depth2 li").length > 0 ){
		if( typeof defaultDep2Idx != "undefined" ){
			$("nav .depthSelect > li:eq(0)").text( $("nav .depth2 .depth2-"+(defaultDep2Idx)).text() );
			current2DepIdx = defaultDep2Idx;
		} else {
			$("nav .depthSelect > li:eq(0)").text( $("nav .depth2 li:eq(0)" ).text() ); 
			current2DepIdx = getDep2Index($("nav .depth2 li:eq(0)" ).attr("class"));
		}
		
		if( typeof defaultDep3Idx != "undefined" ){
			$("nav .depthSelect > li:eq(1)").text( $("nav .depth3 .depth3-" + current2DepIdx + " li:eq("+ ( (defaultDep3Idx == 0 ) ? 0 : defaultDep3Idx -1 ) +")" ).text() ); 
		} else {
			$("nav .depthSelect > li:eq(1)").text( $("nav .depth3 .depth3-" + current2DepIdx + " li:eq(0)" ).text() );
		}
	}
	$("nav > .nav").parent().find(".depthSelect > li").click(function(){
		if( $(this).parent().parent().parent().find(".depth2 li").length < 1 ){ return; }
		var idx = $(this).index();
		if( idx == 0 ){
			// 2Dep
			if( !$(this).hasClass("open") ){
				$(this).siblings('li').removeClass("open");
				$(this).addClass("open");
				$(this).parent().parent().parent().find(".depth3").hide();
				$(this).parent().parent().parent().find(".depth2").fadeIn();
			} else {
				$(this).removeClass("open");
				$(this).parent().parent().parent().find(".depth2").hide();
			}
		} else {
			// 3Dep
			var $dep3 = $(this).parent().parent().parent().find(".depth3");
			
			if( !$(this).hasClass("open") ){
				$(this).siblings('li').removeClass("open");
				$(this).addClass("open");
				$(this).parent().parent().parent().find(".depth2").hide();
				$dep3.find(">ul").each(function(){
					$(this).hide();
				});
				/*
				for( var i=1, dep3Len= $dep3.find("ul").length; i<=dep3Len; ++i ){
					$dep3.find(".depth3-" + i).hide();
				}
				*/
				if( $dep3.find(".depth3-" + current2DepIdx).length > 0 ){
					$dep3.show();
					$dep3.find(".depth3-" + current2DepIdx).fadeIn();
				}
			} else {
				$(this).removeClass("open");
				$dep3.hide();
			}
		}
	});

	// select 2Depth
	//  yjlee 20130617 2depth ���ý� ȭ������ �ٷ� �̵�
	//$("nav > .nav").parent().find(".depth2 li").click( function(e){
	//	e.preventDefault();
	//	var idx = $(this).index();
	//	//current2DepIdx = idx + 1;
	//	current2DepIdx = getDep2Index($(this).attr("class"));
	//
	//	$(this).parent().parent().parent().find(".depthSelect > li:eq(0)").text( $(this).parent().parent().parent().find(".depth2 li:eq("+idx+")" ).text() ); 
	//	$(this).parent().parent().parent().find(".depthSelect > li:eq(1)").text( $(this).parent().parent().parent().find(".depth3 .depth3-" + current2DepIdx + " li:eq(0)" ).text() ); 
	//	$(this).parent().parent().parent().find(".depth2").fadeOut();
	//	$(this).parent().parent().parent().find(".depthSelect > li:eq(0)").removeClass("open");
	//});

	function getDep2Index(str){
		var tmp = [];
		if( str == "" || str == null ){ return 1; }
		if( str.indexOf("depth2-") != -1 ){
			tmp = str.split("-");
			return tmp[1];
		}
		return 1;
	}

	// select 3Depth
	$("nav > .nav").parent().find(".depth3 li").click( function(){
		$(this).parent().fadeOut();
		$(this).parent().parent().parent().find(".depthSelect > li:eq(1)").text( $(this).text() ); 
		$(this).parent().parent().parent().find(".depthSelect > li:eq(1)").removeClass("open");	
	});
	/* e : �޴� 2Depth / 3Depth ���� : 20130605 */

	//sitemap
	$(".allMenu").click(function(){
		if($(".sitemap").css("display") == "none"){
			$(".sitemap").animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeOutBack"});
		}else{
			$(".sitemap").animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
		}
	});
	//tab
	$(".tabCntE .Title, .tabCntD1 .Title, .tabCntD2 .Title").click(function(){
		if($(this).next().css("display") == "none"){
			$(".tabCnt > .Title").removeClass("open");
			$(".tabCnt > .Cnt").hide();
			$(this).addClass("open");
			$(this).next().show();
		}
	});

	/* s : Swipe ����� �ִ� ��ư ���� ���� : 20130531 */
	//tabCntSlide
	/*
	$(".tabCntSwipe .Title li").click(function(){
		var idx = $(this).parent().parent().find(".Title li").index($(this));

		$(this).parent().parent().find(".Title li").removeClass("open");
		$(this).parent().parent().find("> .CntSwipe > .Cnt").hide();

		$(this).addClass("open");
		$(this).parent().parent().find("> .CntSwipe > .Cnt").eq(idx).fadeIn();
	});
	*/
	/* e : Swipe ����� �ִ� ��ư ���� ���� : 20130531 */


	//tabCntSlide
	$(".tabCntSlide .Title li").click(function(){
		var idx = $(this).parent().parent().find(".Title li").index($(this));   

		$(this).parent().parent().find(".Title li").removeClass("open");
		$(this).parent().parent().parent().find("> .Cnt").hide();

		$(this).addClass("open");
		$(this).parent().parent().parent().find("> .Cnt").eq(idx).fadeIn();
	});

	//accordion
	$(".accordionCnt > h4").click(function(){
		if (!$(this).hasClass("open")){
			$(".accordionCnt > h4").removeClass("open");
			$(".accordionCnt > h4").next().hide(); 
			$(this).addClass("open");
			$(this).next().fadeIn(); 
		}else{
			$(this).removeClass("open");
			$(this).next().hide(); 
		}
	});
	//tableOpen
	$(".tableOpen .CntOpen").click(function(){
		if (!$(this).hasClass("open")){
			$(".tableOpen .CntOpen").removeClass("open");
			$(".tableOpen .Cnt").hide(); 
			$(this).addClass("open");
			$(this).parent().next().fadeIn();
		}else{
			$(this).removeClass("open");
			$(this).parent().next().fadeOut(); 
		}
	});

	//checkbox
	$(".chkChange input:checkbox:checked").each(function(){
		$(this).parent().addClass("checked");
	});
	//checkbox - font color ������ ���
	//$(".chkChange input:checkbox").click(function(){
	//	if($(this).is(":checked")) {
	//		$(this).parent().addClass("checked");
	//	} else {
	//		$(this).parent().removeClass("checked");
	//	}
	//});
	//checkbox - font color ������ ���
	$(".chkChange input:checkbox").click(function(){
		if($(this).is(":checked")) {
			$(this).addClass("on");
			$(this).parent().addClass("checked");
		} else {
			$(this).removeClass("on");
			$(this).parent().removeClass("checked");
		}
	});
	//radio
	$(".radioChange input:radio:checked").each(function(){
		$(this).parent().addClass("checked");
	});
	//radio - font color ������ ���
	$(".radioChange input:radio").click(function(){
		if($(this).is(":checked")) {
			$(this).parent().addClass("checked");
		} else {
			$(this).parent().removeClass("checked");
		}
	});

	//noticeList
	$(".noticeList > dl > dt").click(function(){
		if (!$(this).hasClass("open")){
			$(this).addClass("open");
			$(this).next().animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
		}else{
			$(this).next().animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
			$(this).removeClass("open");
		}
	});

	//coachingAnalysis
	$(".coachingAnalysis > h3, .summaryInfo > h3").click(function(){
		if (!$(this).hasClass("open")){
			$(this).addClass("open");
			$(this).parent().find(".stepCnt").animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
		}else{
			$(this).removeClass("open");
			$(this).parent().find(".stepCnt").animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeOutBack"});
		}
	});

	//productSample
	$(".productSample").each(function(){
		var liLength = $(this).find("li").length;
		var ulWidth = $(this).find("li").outerWidth() * liLength;
		$(this).find("ul").width(ulWidth);
	});
	

	//���� fixedBannerAD
	if( $(".fixedBannerAD").length > 0 ){

		var _height = $(document).height();

		$(".container").addClass("fixedBanner");
		var ad = $(".fixedBannerAD"),
			adH = ad.outerHeight(),
			footerTop = getFooterTop(),
			footerH = $("footer").outerHeight(),
			chkGbUa = navigator.userAgent;

		if( $(document).height() < $(window).height() ){
		
		} else {
			if( chkGbUa.indexOf("533") == -1 ){
				$(ad).find("img").css({"position":"relative"});
				setPositionAD()
			} else {
				ad.css("position","absolute");
				setPositionADforGB();
			}
			$(window).bind( "scroll resize", function(e){
				footerTop = getFooterTop();
				chkGbUa.indexOf("533") == -1 ? setPositionAD() : setPositionADforGB();
			});
		}

		//��ʰ� ��ġ�� y����
		function getFooterTop(){
			return $("footer").offset().top - adH - $(".fixedBanner").offset().top;
		}

		MutationObserver = window.MutationObserver || window.WebKitMutationObserver;

		var observer = new MutationObserver(function(mutations, observer) {
			if( _height != $(document).height() ){
				_height = $(document).height();
				footerTop = getFooterTop();
				chkGbUa.indexOf("533") == -1 ? setPositionAD() : setPositionADforGB();
			}
		});

		observer.observe(document, {subtree:true,attributes:true});
	}


	function setPositionAD(){
		if( $(window).scrollTop() >= $(document).height() - $(window).height() - footerH - adH ){
			ad.css({
				"position":"absolute",
				"top": footerTop + "px",
				"bottom":"auto"
			});
		} else {
			ad.css({
				"position":"fixed",
				"top":"auto",
				"bottom":"-1px"
			});
		}
	}

	function setPositionADforGB(){
		if( $(window).scrollTop() >= $(document).height() - $(window).height() - footerH  ){
			ad.animate({top:footerTop+"px"}, 0 );
			/*
			ad.css({
				"top":footerTop + "px"
			});
			*/
		} else {
			ad.animate({top:( $(window).scrollTop() + $(window).height() - $(".fixedBanner").offset().top - adH )+"px"}, 0 );
			/*
			ad.css({
				"top": ( $(window).scrollTop() + $(window).height() - $(".fixedBanner").offset().top - adH ) + "px"
			});
			*/
		}
	}
}

//////////////////// resize�� ���� ////////////////////
jQuery(window).resize(function() {
});
//////////////////// onorientationchange�� ���� ////////////////////
window.onorientationchange = function() {
}