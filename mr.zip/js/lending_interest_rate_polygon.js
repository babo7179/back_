/*!
 ���ϸ�		: lending_interest_rate_polygon.js
 ��ɼ���	: AllCredit Polygon Graph
 �ۼ���		: PULIP communications Interactive Part
		
 ���������� : 2013-06-12	15:00  >  SVG ������ CANVAS�� ����
                                   >  �޾ƿ��� Data json -> obj ���·� ����
*/

$( document ).ready( function () {
		
	_linkMakePolygonGraph = makePolygonGraph;
	var _jsonData = null;
	var _graphBg = null ;
	var grahSVGcard = null ;
	var bgHeight = 155;
	var minDeviceWidth = 0;

	var listAry = [];
	var polygonGraphHeightPer = [];
	var leftMarginAry = [];
	var graphColorAry = [];
	var activePolygonLength = 0;
	var isListResize = "";

	var _graphAry =  [];
	var _circleAry = [];
	var _lineAry = [];
	var _perTextAry = [];
	var _textFieldAry = [];
	
	var graphDataUrl = '';
	var graphCon = '';

	var canvasCtx = null;
	var enabledSVG = true;



	//function makePolygonGraph( jsonUrl, classOrIdName ) {
	function makePolygonGraph( data, classOrIdName, grahSVGcard) {
		// Android ���� ���ϴ� ĵ������...
		var ua = navigator.userAgent;
		if( ua.indexOf("Android") >= 0 )
		{
			var androidversion = parseFloat(ua.slice(ua.indexOf("Android")+8)); 
			if (androidversion < 3.0){ enabledSVG = false; }
		}
		
		/*
		graphDataUrl = jsonUrl;
		graphCon = $ ( classOrIdName );
	
		$.ajax ({
			url : graphDataUrl,
			dataType : 'json',
			success: function( data ) {
				_jsonData = data;
				console.log( _jsonData );
				init ();
			},
			error: function( data ) {
				alert( 'ERROR: ' + data );
			}
		});
		*/
		graphCon = $ ( classOrIdName );
		_jsonData = data;
		grahSVGcard = grahSVGcard;
		
		init(grahSVGcard);
	}

	function init (grahSVGcard) {
		setVariable ();
		if( enabledSVG ) { makeSvg (grahSVGcard); }
		setContentList ();
		$( window ).resize( function () {
			if( enabledSVG ){
				resizeHn (grahSVGcard);
			} else {
				if( canvasCtx ){
					if( canvasCtx.clear ){
						canvasCtx.clear();
					} else {
						canvasCtx.clearRect ( 0 , 0 , $(document).width() , $(document).height() );
					}
				}
				makeCanvas();
			}
		});
		if( enabledSVG ){
			resizeHn (grahSVGcard);
		} else {
			makeCanvas();
		}
	}

	function setVariable () {
		polygonGraphHeightPer = _jsonData[0].polygonGraphHeightPer;
		activePolygonLength   = polygonGraphHeightPer.length;
		minDeviceWidth = _jsonData[0].minDeviceWidth;
		isListResize   = _jsonData[0].isListResize;
		listAry		   = _jsonData[0].listAry;
		leftMarginAry  = _jsonData[0].leftMarginAry;
		graphColorAry  = _jsonData[0].graphColorAry;
		_textFieldAry  = _jsonData[0].percentTextAry;

		_graphBg = graphCon;
	}

	function makeSvg (grahSVGcard) {
		
		var svgDOM = '';
		svgDOM += '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="100%">';
		svgDOM +=	'<line x1="0" y1="20%"  x2="100%" y2="20%"  class="line" stroke="rgb(230, 230, 230)" stroke-width="1" />';
		svgDOM +=	'<line x1="0" y1="40%"  x2="100%" y2="40%"  class="line" stroke="rgb(230, 230, 230)" stroke-width="1" />';
		svgDOM +=	'<line x1="0" y1="60%"  x2="100%" y2="60%"  class="line" stroke="rgb(230, 230, 230)" stroke-width="1" />';
		svgDOM +=	'<line x1="0" y1="80%"  x2="100%" y2="80%"  class="line" stroke="rgb(230, 230, 230)" stroke-width="1" />';
		svgDOM +=	'<line x1="0" y1="100%" x2="100%" y2="100%" class="line" stroke="rgb(153, 153, 153)" stroke-width="1" />';

		makeSvgElements ();
		function makeSvgElements () {
			for( var i = 0 ; i < activePolygonLength; i ++ ) {
				svgDOM += '<polygon points="" class="graph' + i + '" fill="" />';
				if ( i != activePolygonLength-1 ) svgDOM += '<line x1="0" y1="0" x2="0" y2="0" class="line connectline" stroke="rgb(153, 153, 153)" stroke-width="1" />';
				svgDOM += '<circle cx="" cy="" r="4" class="circle" stroke="rgb(153, 153, 153)" stroke-width="2" fill="rgba(255, 255, 255, 1.0)" />';
			}
		}

		svgDOM +=	'<text>';

		makeTextElements ();
		function makeTextElements () {
			for ( var i = 0; i < activePolygonLength; i ++ ) {
				svgDOM += '<tspan x="" y="" fill="rgb(102, 102, 102)"></tspan>';
			}
		}

		if (grahSVGcard){
			svgDOM +=	'<tspan x="0%"  y="10%" text-anchor="start" fill="rgb(153, 153, 153)">�ſ����</tspan>';
			svgDOM +=	'<tspan x="0%" y="50%" text-anchor="start" fill="rgb(153, 153, 153)">����</tspan>';
			svgDOM +=	'<tspan x="0%" y="95%" text-anchor="start" fill="rgb(153, 153, 153)">����</tspan>';
			svgDOM +=	'<tspan x="100%" text-anchor="end" y="10%" fill="rgb(153, 153, 153)">�ſ����</tspan>';
			svgDOM +=	'<tspan x="100%" text-anchor="end" y="50%" fill="rgb(153, 153, 153)">����</tspan>';
			svgDOM +=	'<tspan x="100%" text-anchor="end" y="95%" fill="rgb(153, 153, 153)">����</tspan>';
		}

		svgDOM +=	'</text>';
		svgDOM += '</svg>';
		graphCon.append( svgDOM );
	}

	function makeCanvas(){
		var canvasDom = '';
		var sw = $('.graphArea').width(); //$( document ).width() - 22;
		var basicHeight = 155;
		if( canvasCtx ){
			$("canvas")[0].width = sw;
		} else {
			canvasDom += '<canvas width="'+sw+'px" height="'+ basicHeight +'px"></canvas>';
			graphCon.append( canvasDom );
			canvasCtx = $("canvas")[0].getContext("2d");
		}
		drawCanvas ( canvasCtx );	
	}

	function drawCanvas( ctx ){
		var sw = $('.graphArea').width(); //$( window ).width();
		var basicHeight = 155;
		bgHeight = basicHeight;
		_graphBg.css ( 'height', bgHeight );

		var liWidth =  $( '.legend' ).find( ' > li' ).eq ( 0 ).width();
		var widthRate = parseInt ( liWidth / 2 - 2 );
		if ( sw <= minDeviceWidth ) widthRate = parseInt ( liWidth / 2 ) ;

		var gridMargin = parseInt( bgHeight / 5 );//graphCon.height() / 5;
		
		ctx.save();
		ctx.strokeStyle = 'rgba(0,0,0,0)';
		ctx.lineCap = 'butt';
		ctx.lineJoin = 'miter';
		ctx.miterLimit = 4;

		// draw grid line
		for( var i=0; i <6; i++ ){
			ctx.save();
			if( i < 5 ){
				ctx.strokeStyle = "#e6e6e6";
			} else {
				ctx.strokeStyle = "#999999";
			}
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(0, ( gridMargin * i ) );
			ctx.lineTo(sw, ( gridMargin * i ) );
			ctx.fill();
			ctx.stroke();
			ctx.restore();
		}

		// draw graph
		var graphXAry = [];
		var leftMargin1 = 0;
		var leftMargin2 = 0;
		for( var i = 0 ; i < activePolygonLength; i ++ ) {
			// data
			graphXAry[i] = parseInt ( ( liWidth / 2 ) * ( i + 1 ) + ( i * liWidth / 2 ) );
			leftMargin1 = parseInt ( leftMarginAry[ i ] );
			leftMargin2 = parseInt ( leftMarginAry[ i-1 ] );
			
			var height = polygonGraphHeightPer[i];
			var height1 = polygonGraphHeightPer[i-1];

			var dotY    = parseInt( bgHeight * ( 155 - height  * 1.55 ) / 154 );
			var dotY1   = parseInt( bgHeight * ( 155 - height1 * 1.55 ) / 154 );
			
			// polygon
			ctx.save();
			ctx.strokeStyle = graphColorAry[i];
			ctx.fillStyle = graphColorAry[i];//"rgba(69, 163, 229, 0.8)";
			//ctx.lineWidth = 0;
			ctx.beginPath();
			ctx.moveTo(( graphXAry[i] + leftMargin1 ),dotY); // circle point 
			ctx.lineTo(( graphXAry[i] + ( widthRate + leftMargin1 ) ),bgHeight); // right point
			ctx.lineTo(( graphXAry[i] - ( widthRate - leftMargin1 ) ),bgHeight); // left point
			ctx.lineTo(( graphXAry[i] + leftMargin1 ),dotY);
			ctx.closePath();
			ctx.fill();
			ctx.stroke();
			ctx.restore();

			// graph line
			if( i > 0 ){
				ctx.save();
				ctx.strokeStyle = "#999999";
				ctx.lineWidth = 1;
				ctx.beginPath();
				ctx.moveTo(( graphXAry[i] + leftMargin1 ),dotY);
				ctx.lineTo(( graphXAry[(i - 1)] + leftMargin1 ),dotY1);
				ctx.fill();
				ctx.stroke();
				ctx.restore();
			}
		
			// text
			ctx.save();
			ctx.fillStyle = "#666666";
			ctx.fillText(_textFieldAry[i],( graphXAry[i] - 12 + leftMargin1 ), dotY - 10);
			ctx.restore();
		}

		for( var i = 0 ; i < activePolygonLength; i ++ ) {
			graphXAry[i] = parseInt ( ( liWidth / 2 ) * ( i + 1 ) + ( i * liWidth / 2 ) );
			leftMargin1 = parseInt ( leftMarginAry[ i ] );
			leftMargin2 = parseInt ( leftMarginAry[ i-1 ] );
			
			var height = polygonGraphHeightPer[i];
			var dotY    = parseInt( bgHeight * ( 155 - height  * 1.55 ) / 154 );
			
			// circle : ������ ���ϼ��� �־ �켱�� ������ ����..
			ctx.save();
			ctx.fillStyle = "#ffffff";
			ctx.strokeStyle = "#999999";
			ctx.lineWidth = 2;
			ctx.beginPath();
			ctx.arc(( graphXAry[i] + leftMargin1 ),dotY,4,0*Math.PI,2*Math.PI, true)
			ctx.closePath();
			ctx.fill();
			ctx.stroke();
			ctx.restore();
		}

		ctx.restore();
	}

	function setContentList () {
		var len = activePolygonLength;
		var con = $( '.legend' );
		var tsap = graphCon.find( '> svg > text > tspan' ); 
		var per = 100 / len + '%';
		
		setLabels ();
		function setLabels () {
			var liDOM = '';
			var len = listAry.length;
			for ( var i = 0; i < len; i ++ ) {
				var per = 100 / len + '%';
				liDOM += '<li style="width:' + per + ';">' + listAry[i] + '</li>';
			}
			con.append( liDOM );
		}

		if ( isListResize == "Y" ) con.find( '> li' ).remove ();

		setting ();		
		function setting () {
			var len = activePolygonLength;
			var liDOM = '';
			for ( var i = 0; i < len; i ++ ) {
				var per = 100 / len + '%';
				_graphAry[i] = _graphBg.find( 'polygon' ).eq( i );
				_graphAry[i].attr( 'fill', graphColorAry[i] );
				_circleAry[i] = $( '.circle' ).eq ( i );
				_perTextAry[i] =_graphBg.find( 'text' ).find( 'tspan' ).eq( i );
				_perTextAry[i].text ( _textFieldAry[i] );
				if ( i != len-1 ) _lineAry[i] = _graphBg.find( '.connectline' ).eq( i );
				if ( isListResize == "Y" ) liDOM += '<li style="width:' + per + ';">' + listAry[i] + '</li>';
			}
			con.append ( liDOM );
		}
	}
	
	function resizeHn (grahSVGcard) {
		var sw = $( window ).width();
		var basicHeight = 155;
		if ( sw <= minDeviceWidth ) bgHeight = basicHeight;
		else bgHeight = parseInt ( sw *( basicHeight / minDeviceWidth ) ); // equation :: ������������ * ( �׷����� �⺻���� / ����ּһ����� ) );
		_graphBg.css ( 'height', bgHeight );
		var liWidth =  $( '.legend' ).find( ' > li' ).eq ( 0 ).width();
		var widthRate = parseInt ( liWidth / 2 - 2 );
		if ( sw <= minDeviceWidth ) widthRate = parseInt ( liWidth / 2 ) ;
		
		var graphXAry = [];
		var leftMargin1 = 0;
		var leftMargin2 = 0;


		for( var i = 0 ; i < activePolygonLength; i ++ ) {
				graphXAry[i] = parseInt ( ( liWidth / 2 ) * ( i + 1 ) + ( i * liWidth / 2 ) );
				leftMargin1 = parseInt ( leftMarginAry[ i ] );
				leftMargin2 = parseInt ( leftMarginAry[ i-1 ] );
				
				var height = polygonGraphHeightPer[i];
				var height1 = polygonGraphHeightPer[i-1];

				var dotY    = parseInt( bgHeight * ( 155 - height  * 1.55 ) / 154 );
				var dotY1   = parseInt( bgHeight * ( 155 - height1 * 1.55 ) / 154 );


				if (grahSVGcard){
					var widthRate = parseInt ( liWidth / 4 );
					_graphAry[i].attr( 'points', ( graphXAry[i] - ( widthRate - leftMargin1 )) + ', ' + dotY + ' ' + ( graphXAry[i] + ( widthRate + leftMargin1 ) ) + ', ' + dotY + ' ' + ( graphXAry[i] + ( widthRate + leftMargin1 ) ) + ',' + bgHeight + ' ' + ( graphXAry[i] - ( widthRate - leftMargin1 ) ) + ',' + bgHeight );
					_circleAry[i].attr({ 'cx': graphXAry[i] + leftMargin1, 'cy': dotY });
					_perTextAry[i].attr({ 'x': graphXAry[i] - 12 + leftMargin1 , 'y': dotY - 10 , 'fill' :'rgb(69, 163, 229)'});
					if (i > 0){
						_perTextAry[i].attr('fill' , 'rgb(15, 96, 153)')
					}
					_perTextAry[i].css('font-weight', 'bold');

					
					if ( i >= 1 ) {
						_lineAry[i-1].attr({ 'x1': graphXAry[i-1] + leftMargin2 , 'x2': graphXAry[i] + leftMargin1, 'y1' : dotY1, 'y2' : dotY });
					}
				}else{
					_graphAry[i].attr( 'points', ( graphXAry[i] + leftMargin1 ) + ', ' + dotY + ' ' + ( graphXAry[i] + ( widthRate + leftMargin1 ) ) + ',' + bgHeight + ' ' + ( graphXAry[i] - ( widthRate - leftMargin1 ) ) + ',' + bgHeight );
					_circleAry[i].attr({ 'cx': graphXAry[i] + leftMargin1, 'cy': dotY });
					_perTextAry[i].attr({ 'x': graphXAry[i] - 12 + leftMargin1 , 'y': dotY - 10 });
					if ( i >= 1 ) {
						_lineAry[i-1].attr({ 'x1': graphXAry[i-1] + leftMargin2 , 'x2': graphXAry[i] + leftMargin1, 'y1' : dotY1, 'y2' : dotY });
					}
				}

			}

	}
});

var _linkMakePolygonGraph;
function makePolygonGraph ( jsonUrl, classOrIdName, grahSVGcard ) {
	if ( _linkMakePolygonGraph != null && typeof _linkMakePolygonGraph == 'function' ) {
		_linkMakePolygonGraph.apply ( null, [ jsonUrl, classOrIdName , grahSVGcard ]);	
	}
}