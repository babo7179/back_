
//����ȭ function : e

$(document).ready(function() {
	
	 $('input').iCheck({
		checkboxClass: 'icheckbox',
		radioClass: 'iradio',
		increaseArea: '20%' // optional
	 });
	 // iCheck guide
	 //$('#input-1, #input-3').iCheck('check'); checked
	 //$('#input-1, #input-3').iCheck('uncheck'); remove checked
	 //$('#input-2, #input-4').iCheck('disable'); disabled
	 //$('#input-2, #input-4').iCheck('enable'); remove disabled

});

//////////////////// load�� ���� ////////////////////

window.onload = function() {
	setTimeout(function() { if(window.pageYOffset == 0){ window.scrollTo(0, 1);} }, 100);

	// iOS
	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
		$("body").addClass("ios");
	}

	//Android
	if((navigator.userAgent.match(/Android/i))){
		$("body").addClass("android");
		
		// GalexyS2
		if( (navigator.userAgent.indexOf("SHW-M250")) != -1 ){
			$("body").addClass("galexyS2");
		}
	}
}

