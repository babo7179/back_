/**********************************************************************************
 * Author :		Kim. Bo Young (smitedin@fishingtree.com)
 * Beginning :	2010-08-02
 * Final :		2010-08-02
 ----------------------------------------------------------------------------------
 테스트 브라우저 : 인터넷 익스플로러 6/7/8, 파이어폭스/사파리/크롬/오페라 최신버전
 ----------------------------------------------------------------------------------
 첫번째 인자 :		셀렉터 (레이어 띄우기)
 두번째 인자 :		셀렉터 (레이어)
 세번째 인자 :		셀렉터 (레이어 닫기)
 네번째 인자 :		셀렉터 (배경 딤처리)
***********************************************************************************/

/*********************************** 중앙 정렬 레이어 팝업 배경 딤처리 ***********************************/

$(function() {
	openLayerDim('.openDim', '.layerDim', '.closeDim', '#back');
});

function openLayerDim(target, obj, close, dim) {
	var $obj = $(obj);

	$obj.addClass('hidden');
	$(target).click(function() {
		layerPopupDim($obj, close, dim);

		return false;
	});
}

function layerPopupDim(obj, close, dim) {
	var $obj = $(obj);

	middleCenterLayer($obj);
	$obj.removeClass('hidden')
		.css({
			'z-index' : '99999'
		});
	dimLayerOn($(dim));

	$(close).click(function() {
		$obj.addClass('hidden');
		dimLayerOff($(dim));

		return false;
	});

	$(window).resize(function() {
		middleCenterLayer($obj);
	});
}

function dimLayerOn(dim) {
	var client_h = $(document).height();
	dim.css({
		'width' : '100%',
		'height' : client_h,
		'opacity' : 0.7,
		'background-color' : '#000',
		'display' : 'block',
		'z-index' : '9999',
		'position' : 'absolute',
		'top' : '0',
		'left' : '0'
	});
}

function dimLayerOff(dim) {
	dim.css({
		'display' : 'none',
		'z-index' : '0'
	});

}

function middleCenterLayer(obj) {
	var obj_w = obj.outerWidth();
	var obj_h = obj.outerHeight();
	var screen_w = $(window).width();
	var screen_h = $(window).height();
	var scroll_t = $(document).scrollTop();

	var xpos = screen_w/2 - obj_w/2;
	var ypos = (screen_h/2 - obj_h/2) + scroll_t;

	obj.css({'left' : xpos+'px', 'top' : ypos+'px'});
}