/*!
 ���ϸ�		: jquery.slideTab_ad.js
 ��ɼ���	: AllCredit SlideTab Navigation
 �ۼ���		: PULIP communications Interactive Part
 
 jquery.slideTab.js custom smartMedia grup
		
 ���������� : 2013-08-06 10:36
*/

var $slideTab = $('.slideTab'),
	$itemContainer = $slideTab.find('>div >ul'),
	$items = $itemContainer.find('li'),
	$prevBtn = $slideTab.find('.prev'),
	$nextBtn = $slideTab.find('.next');

/*
	itemText		: �� �޴� �ý�Ʈ ����
	itemW			: �� �޴� �ʺ� ����
	itemLen			: �޴� ����
	currentPage		: ���� ������
	itemPerPage		: �� �������� �޴� ���� ( �̵��� ���� )
	maxPageNum		: ��ü ��������  
	ellipsisIdx			: ���� ������ ����� �޴� �ε���
	btnW			: ���������� ��ư�� �ʺ�
	isShowPrevBtn	: ���������� ��ư ȭ����� ���� 
*/
var itemText = [],
	itemW = [],
	itemLen = 0,
	currentItem = 0,
	currentPage = 0,
	itemPerPage = 1,
	maxPageNum = 0,
	ellipsisIdx = -1,
	lastMoveIdx = -1,
	btnW = 0,
	containerW = 0,
	isShowPrevBtn = true,
	isFirst = true,
	enabledBtnClick = true,
	enabledMove = true;

var moveSpeed = 300;
/* 2013-07-18
$(document).ready(function(){
	init();
});
*/
/*-----------------------------------------------------------------------------*\
  Init
\*-----------------------------------------------------------------------------*/
function init_ad(){
		/*-- init ------------------------------------------*/

	// tab width
	containerW = $slideTab.width();
	
	// Tab item ������ �ʺ� �� �ؽ�Ʈ ����
	$items.find('>a:eq(0)').each(function(){
		itemText.push( $(this).text() );
		itemW.push( $(this).outerWidth() + 1 );
		itemLen++;
	});
	if( itemLen < 1 ){ return; }

	// page 
	currentPage = getCurrentPage();
	maxPageNum = Math.ceil( itemLen / itemPerPage ) - 1;

	$('.tabCntASlideSub > ul').hide();
	$('.tabCntASlideSub > ul:eq(' + getCurrentPage() + ')').fadeIn();
	move();
	// btn 
	// get width
	if( $prevBtn.length > 0 ){ btnW = $prevBtn.width(); }
	if( currentPage == 0 ){ 
	//	hidePrevBtn(); 
	}
	//if( maxPageNum < 1 ){ hideNextBtn(); }

	
	/*-- tabEvent ------------------------------------------*/
	function itemsEvent( el ){
		el.parent().siblings('li').removeClass("open");
		el.parent().addClass("open");

		var contents = el.parent().parent().parent().parent().parent().find('> .tabCntASlideSub > ul');
		contents.hide();
		contents.eq( el.parent().index()).fadeIn();
	}
	
	// prev btn
	$prevBtn.click(function(e){
		e.preventDefault();
		if( enabledBtnClick ){
			if( enabledMove || currentItem == (currentPage) ){
				if( currentPage > 0 ){
					currentPage--;
				}
				move();
				enabledBtnClick = false;
			}
			if( currentItem > 0 ){
				currentItem--;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});

	// next btn
	$nextBtn.click(function(e){
		e.preventDefault();
		
		if( enabledBtnClick ){
			
			if( currentPage < maxPageNum && enabledMove ){ 
				currentPage++;
				move();
				enabledBtnClick = false;
			}

			if( currentItem < itemLen - 1 ){
				currentItem++;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});
	
	

	// resize
	$(window).resize(function(e){
		resizeHandler();
	});
	
	/*--------------------------------------------*/
	$(window).trigger( "resize" );
}

function init(){
	/*-- init ------------------------------------------*/

	// tab width
	containerW = $slideTab.width();
	
	// Tab item ������ �ʺ� �� �ؽ�Ʈ ����
	$items.find('>a:eq(0)').each(function(){
		itemText.push( $(this).text() );
		itemW.push( $(this).outerWidth() + 1 );
		itemLen++;
	});
	if( itemLen < 1 ){ return; }

	// page 
	currentPage = getCurrentPage();
	maxPageNum = Math.ceil( itemLen / itemPerPage ) - 1;

	$('.tabCntASlideSub > ul').hide();
	$('.tabCntASlideSub > ul:eq(' + getCurrentPage() + ')').fadeIn();
	move();
	// btn 
	// get width
	if( $prevBtn.length > 0 ){ btnW = $prevBtn.width(); }
	if( currentPage == 0 ){ 
	//	hidePrevBtn(); 
	}
	//if( maxPageNum < 1 ){ hideNextBtn(); }

	
	/*-- tabEvent ------------------------------------------*/
	function itemsEvent( el ){
		el.parent().siblings('li').removeClass("open");
		el.parent().addClass("open");

		var contents = el.parent().parent().parent().parent().parent().find('> .tabCntASlideSub > ul');
		contents.hide();
		contents.eq( el.parent().index()).fadeIn();
	}
	
	// prev btn
	$prevBtn.click(function(e){
		e.preventDefault();
		if( enabledBtnClick ){
			if( enabledMove || currentItem == (currentPage) ){
				if( currentPage > 0 ){
					currentPage--;
				}
				move();
				enabledBtnClick = false;
			}
			if( currentItem > 0 ){
				currentItem--;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});

	// next btn
	$nextBtn.click(function(e){
		e.preventDefault();
		
		if( enabledBtnClick ){
			
			if( currentPage < maxPageNum && enabledMove ){ 
				currentPage++;
				move();
				enabledBtnClick = false;
			}

			if( currentItem < itemLen - 1 ){
				currentItem++;
				$items.eq(currentItem).find('>a:eq(0)').trigger("click");
				itemsEvent( $items.eq(currentItem).find('>a:eq(0)') )
			}
		}
	});
	
	

	// resize
	$(window).resize(function(e){
		resizeHandler();
	});
	
	/*--------------------------------------------*/
	$(window).trigger( "resize" );
}

/*-----------------------------------------------------------------------------*\
  Func
\*-----------------------------------------------------------------------------*/
/**
 * Tab ������ �̵�
 */
function move(speed){
	var pos = 0;

	// prevBtn visible
	//currentPage == 0 ? hidePrevBtn() : showPrevBtn();
	// nextBtn visible
	//currentPage == maxPageNum ? hideNextBtn() : showNextBtn();
	
	if( isFirst ){
		getPageIdx();
	}

	for( var i=0, len=itemPerPage*currentPage; i<len; i++ ){
		pos -= itemW[i];		
	}

	setOrginItemText();

	if( isFirst ){
		isFirst = false;
		$itemContainer.stop().animate( {"left":pos+"px"}, 0, function(){ setEllipsisItemText(); enabledBtnClick = true; } ); 
	} else {
		$itemContainer.stop().animate( {"left":pos+"px"}, moveSpeed, function(){ setEllipsisItemText(); enabledBtnClick = true; } ); 
	}
}


/**
 * ������ư�� �������� ������ �ؽ�Ʈ ���� 
 */
function setEllipsisItemText(){
	// �������� ������ �ε���
	containerW = $slideTab.width() + 7;
	//var w = ( !isShowPrevBtn ) ? -(btnW) : 0;
	var w = 0;
	ellipsisIdx = -1;
	for( var i=itemPerPage*currentPage, len=itemW.length; i < len; i++ ){
		w += itemW[i];
		if( w >= containerW ){
			w -= itemW[i];
			ellipsisIdx = i;
			break;	
		}
	}

	// ������ ��� �ؽ�Ʈ ����
	if( ellipsisIdx != -1 ){
		var tmpItemText = "", item = $items.eq(ellipsisIdx).find('>a:eq(0)');
		for( var i=0, len=itemText[ellipsisIdx].length; i < len; i++ ){
			tmpItemText = getEllipsisText( itemText[ellipsisIdx], i );
			item.text( tmpItemText );
			if( w + item.outerWidth() > containerW ){ break; }
		}
		enabledMove = true;
		showNextBtn();
	} else {
		enabledMove = false;
		// nextBtn visible
		//hideNextBtn();
	}
}

var isShowAll = false;
function getPageIdx(){
	var w = ( !isShowPrevBtn ) ? -(btnW) : 0,
		idx = -1;
	for( var i=itemPerPage*currentPage, len=itemW.length; i < len; i++ ){
		w += itemW[i];
		if( w > containerW ){
			idx = i;
			break;
		}
	}
	if( idx == -1 && currentPage != 0 )
	{
		isShowAll = true;
		currentPage--;
		getPageIdx();
	} else {
		if( isShowAll ){
			currentPage++;
			isPos = false;
		}
	}
}

function setMoveLastIdx(){
	var w = 0;
	lastMoveIdx = -1;
	for( var i=itemW.length - 1; i > 0; i-- ){
		w += itemW[i];
		if( w >= containerW ){
			w -= itemW[i];
			lastMoveIdx = i;
			break;	
		}
	}
}

/**
 * �����ߴ� �ؽ�Ʈ ����
 */
function setOrginItemText(){
	if( ellipsisIdx != -1 ){ 
		$items.eq(ellipsisIdx).find('>a:eq(0)').text( itemText[ellipsisIdx] );
	}
}

/**
 * ���� ��ư ȭ�鿡 ���
 */
function showPrevBtn(){
	if( !isShowPrevBtn ){
		isShowPrevBtn = true;
		$prevBtn.css( "display", "block" );
		if( $slideTab.hasClass("left") ){
			$slideTab.removeClass("left");
		}
	}
}

/**
 * ���� ��ư ȭ�鿡�� ����
 */
function hidePrevBtn(){
	isShowPrevBtn = false;
	$prevBtn.css( "display", "none" );
	$slideTab.addClass("left");
}

/**
 * ���� ��ư ȭ�鿡 ���
 */
function showNextBtn(){
	$nextBtn.css( "display", "block" );
	if( $slideTab.hasClass("right") ){
		$slideTab.removeClass("right");
	}
}

/**
 * ���� ��ư ȭ�鿡�� ����
 */
function hideNextBtn(){
	$nextBtn.css( "display", "none" );
	$slideTab.addClass("right");
}

/*-----------------------------------------------------------------------------*\
  Event Handlers
\*-----------------------------------------------------------------------------*/
/**
 * window resize �̺�Ʈ �߻���
 */
function resizeHandler(){
	containerW = $slideTab.width();
	setMoveLastIdx();
	setOrginItemText();
	//setEllipsisItemText();
	move();
}

/*-----------------------------------------------------------------------------*\
  Utils
\*-----------------------------------------------------------------------------*/
/**
 * ���� ���̿� ���� �����ϰ� ��ü���� �߰�
 *
 * @param str 			: ��ȯ�� ����
 * @param maxLen		: ǥ�õ� �ִ� ���� ��
 * @param symbol		: �ִ� ���ڼ� ���� ǥ�õ� ��ȣ ( �⺻�� : ... )
 */
function getEllipsisText( str, maxLen, symbol ){
	if( !symbol ){ symbol = "..."; }
	if( str.length <= maxLen ){
		return str;
	}
	return str.substr(0, maxLen)+ symbol;
} 

/**
 * ���� ���̴� ������ ��ȯ
 */
function getCurrentPage(){
	var idx = 0;
	for( var i=0, len=itemW.length; i < len; i++ ){
		if( $items.eq(i).hasClass("open") ){
			idx = i;
			currentItem = i;
			break;
		}
	}
	

	/*- open ��ġ�� ù��° �ڸ��� �ƴ� ��츦 ���� �ڵ�-------------------------------------------*/
	/*
	var num = Math.floor( idx / itemPerPage );
	return num - ( num - getViewFirst(num) );
	*/
	/*--------------------------------------------*/
	
	return Math.floor( idx / itemPerPage );
}

/**
 * ������ �ε�� ���� ���̴� ������ 1��° �޴��� �ε���
 *
 * @param openIdx		: Ȱ��ȭ�� �ε���
 */
function getViewFirst(openIdx)
{
	if( !openIdx ){ return 0 ; }
	var pos = ( !isShowPrevBtn ) ? btnW : 0; 
	for( var i = 0; i < openIdx; i++){
		pos -= itemW[i];
	}
	
	if( pos < $itemContainer.position().left ){
		return getViewFirst( openIdx - 1 );
	}
	return openIdx + 1;
}