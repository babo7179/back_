/* ���������� 2013-08-06 10:42 */

//loading ani
var load_is = true;
var loadFrame = 0, loadTotalFrame = 6;

//�ε�ȭ�� ����
function loadAdd(){
	var loadingPage = '<div class="loading" style="position:fixed;left:0px;top:0px;bottom:0px;width:100%;height:200%;z-index:1000;">';
	loadingPage += '<div class="lodingIcon" style="display:block;position:absolute;left:50%;top:25%;width:60px;height:68px;margin-left:-30px;margin-top:-34px;background:url(/mr/img/common/loading.png) no-repeat 0px 0px;background-size:480px 68px;z-index:1001;"></div>';
	loadingPage += '</div>';

	$( loadingPage ).insertBefore("head");
}

$(function(){
	loadAdd();
	setTimeout( loadAni, 300 );
}());

function loadAni(){
	( loadFrame == loadTotalFrame )? loadFrame = 0 : loadFrame++;
	$(".lodingIcon").css({"background-position" : "-" + ( loadFrame * 60 ) + "px 0px"})
	if( load_is ) setTimeout( loadAni, 300 );
}

//����ȭ function : s
//Ajax Call �� load bar ���� 2013-07-25 ��å�Ӵ�
function loadingBar()
{
	$(".loading").fadeIn(500);
	( loadFrame == loadTotalFrame )? loadFrame = 0 : loadFrame++;
	$(".lodingIcon").css({"background-position" : "-" + ( loadFrame * 60 ) + "px 0px"})
	if(load_is)
	{
		setTimeout( loadScroll, 300 );
	}else{
		$(".loading").animate({opacity: 0}, 300, function(){ $(".loading").remove() });
	};
}

//IOS ����Ʈ���� �ڵ鷯 2013-07-26
$.fn.quickChange = function(handler) {
    return this.each(function() {
        var self = this;
        self.qcindex = self.selectedIndex;
        var interval;
        function handleChange() {
            if (self.selectedIndex != self.qcindex) {
                self.qcindex = self.selectedIndex;
                handler.apply(self);
            }
        }
        $(self).focus(function() {
            interval = setInterval(handleChange, 100);
        }).blur(function() { window.clearInterval(interval); })
        .change(handleChange);
    });
};
//����ȭ function : e

var console = window.console || {log:function(){}}; 

$(document).ready(function(e){

})

// �ּ�â������, loading animation 
window.addEventListener('load', function() {
	//loading animation
	setTimeout( function(){
		load_is = false;
		$(".loading").animate({opacity: 0}, 300, function(){ $(".loading").remove() });
	}, 500 );

	//hash ���̿��� 
	if ( window.location.hash ) {
		//if ( typeof($(window.location.hash) ) != "undefined" && $(window.location.hash).offsetTop != "undefined") {	}
	} else {
		//#�����ð�� üũ Ÿ�Ծ���
		setTimeout(scrollTo, 0, 0, 1);
	}
}, false);

function layerPush(open){
	if($("#" + open).css("display") == "none"){
		$("#" + open).animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeOutBack"});
	}else{
		$("#" + open).animate({height: "toggle", opacity: "toggle"}, {duration: "0", easing: "easeInBack"});
	}
}
function layerPushOpen(open){
	$("#" + open).slideDown();
}
function layerPushClose(open){
	$("#" + open).slideUp();
}
function layerHideShow(hide, show){
	$("#" + hide).hide();
	$("#" + show).fadeIn();
}

//////////////////// load�� ���� : s ////////////////////
$(window).load(function(e){

	// iOS
	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
		$("body").addClass("iOS");
	}
	//Android
	if((navigator.userAgent.match(/Android/i))){
		$("body").addClass("android");

		// GalexyS2
		if( (navigator.userAgent.indexOf("SHW-M250")) != -1 ){
			$("body").addClass("galexyS2");
		}
	}

	//radioChange
	$(".radioBtn input:radio:checked").each(function(){
		$(this).parent().addClass("checked");
	});
	//chkChange
	$(".chkChange input:checkbox, .checkbox input:checkbox").click(function(){
		if($(this).is(":checked")) {
			$(this).addClass("on");
			$(this).parent().addClass("checked");
		} else {
			$(this).removeClass("on");
			$(this).parent().removeClass("checked");
		}
	});

	//tableLink over
	$(".tableLink tbody tr").bind("touchstart mouseover", function(e) {
		$(this).addClass("hover");
	}).bind("touchend mouseout", function(e) {
		$(this).removeClass("hover");
	});

	//.tabStyle �����Ѵٸ� ����
	if( $(".tabStyle").length > 0 ){
		$(".tabStyle > h3").bind("click", function(e){
			if( !e.isTrigger && $(this).hasClass("on") ) return;

			$(this).parent().children("h3").removeClass("on");
			$( this ).addClass("on");

			var _CntNum = $( this ).index(".tabStyle:eq(" + $(this).parent().index(".tabStyle") +") > h3");

			$(this).parent().children(".Cnt").hide();
			$(this).parent().children(".Cnt:eq(" + _CntNum + ")").fadeIn();

		});
		
		//on class ����� �ε����� 0��°�� �ƴҰ�� Ȯ���� �̺�Ʈ����
		$(".tabStyle > h3").each( function( index, el ){
			if( $(el).hasClass("on") && $(el).index() != 0 ) $(el).trigger("click");				
		});
	}

	//.tabStyle �����Ѵٸ� ���� - allCredit js
	if( $(" .tabCnt").length > 0 ){
		$(".tabCnt > h3").bind("click", function(e){
			if( !e.isTrigger && $(this).hasClass("open") ) return;

			$(this).parent().children("h3").removeClass("open");
			$( this ).addClass("open");

			var _CntNum = $( this ).index(".tabCnt:eq(" + $(this).parent().index(".tabCnt") +") > h3");

			$(this).parent().children(".Cnt").hide();
			$(this).parent().children(".Cnt:eq(" + _CntNum + ")").fadeIn();
		});
		
		//on class ����� �ε����� 0��°�� �ƴҰ�� Ȯ���� �̺�Ʈ����
		$(".tabStyle > h3").each( function( index, el ){
			if( $(el).hasClass("on") && $(el).index() != 0 ) $(el).trigger("click");				
		});
	}

	//�ش� �˻��� �ڵ��ϼ� ��Ÿ��
	$( "header .search > input" ).focus(function() {
		$( "header" ).addClass( "headerSearch" )
	});

	$( "header .search > a" ).bind("click", function(e){
		if( $(this).attr("href") == "#" ) e.preventDefault();
	})

	$( "header .btnSearchClose, header > .search > a" ).bind( "click", function(e) {
		if( $(this).attr("href") == "#" ) e.preventDefault();
		if( $(this) == $( "header > .btnSearchClose" ) ) $(".search input").val("");
		$( "header" ).removeClass( "headerSearch" );
		$( ".autoComplete" ).addClass( "none" );
		
	});

	//.subNavStyle �����Ѵٸ� ����
	if( $(".subNavStyle").length > 0 ){
		$(".subNavStyle > li").bind("click", function(e){
			if( $(this).hasClass("on") ) return;

			$(this).parent().children("li").removeClass("on");
			$( this ).addClass("on");

			var _CntNum = $( this ).index( ".subNavStyle:eq(" + $(this).parent().index(".subNavStyle") +") > li" );
			var _subNavStyle = $(".subNavStyle:eq(" + $(this).parent().index(".subNavStyle") +")")

			_subNavStyle.parent().find(".sCnt").hide();
			_subNavStyle.parent().find(".sCnt:eq(" + _CntNum + ")").fadeIn();
		});
	} 

	//footer �ȳ���������	.btnInfoBox �����Ѵٸ� ����
	if( $(".btnInfoBox").length > 0 ){
		(function(){
			var open_is = false;
			$(".btnInfoBox").bind("click", function(e){
				$(".infoBox dl dd").removeClass("open close")
				if( open_is ){
					$(".infoBox dd > ul").hide();
					$(".infoBox dd > p").fadeIn();
					$(this).find("span").html( $(this).find("span").html().substr( 0, $(this).find("span").html().length-2 ) + "����");
					$(".infoBox dl dd").addClass("close")
					open_is = false;
				} else {
					$(".infoBox dd > p").hide();
					$(".infoBox dd > ul").fadeIn();
					$(this).find("span").html( $(this).find("span").html().substr( 0, $(this).find("span").html().length-2 ) + "�ݱ�");
					$(".infoBox dl dd").addClass("open")
					open_is = true;
				}
			});
		})();
	}

	//.todayUpdate �����Ѵٸ� rolling : s
	if( $(".todayUpdate").length > 0 ){
		var todayListNum = $(".todayUpdate > ul > li").length - 1;
		var todayCount = 0; 
		$( ".todayUpdate > ul > li:eq(0)" ).css( { "margin-top" : 0 })

		function todayRolling( _count ){
			$(".todayUpdate > ul > li:eq(" + _count +")")
				.animate({ "margin-top" : 0 }, 2000,
					function(){
						todayCount == todayListNum ? todayCount = 0 : todayCount ++;
						$(".todayUpdate > ul > li:eq(" + todayCount +")").animate({ "margin-top" : 0}, 600)
					})
				.animate({ "margin-top" : -35 }, 600,
					function(){
						$( this ).css("margin-top",  35);
						todayRolling(todayCount );
					});
		}
		todayRolling( todayCount )
	}

	//����üũ starSelect �����Ѵٸ� ���� : s 
	if( $(".starSelect").length > 0 ){
		$(".starSelect").addClass("star0");
		$(".starSelect a").bind("click", function(e){
			var starNum = $(this).index();

			$(this).parent().parent().removeClass("star0 star1 star2 star3 star4 star5");
			$(this).parent().parent().addClass("star" + ( $(this).index() + 1 ) );

			$(this).parent().children("a").each(function(index, el){
				$( el ).removeClass("off on");
				$( el ).html("");
				if( index <= starNum ) $( el ).addClass("on"), $( el ).html("���õ�");
					else $( el ).addClass("off");
			});
		});
	} 

	//layerBtn Open, conding file : ������ �˻� search1-2.html
	function btnLayerView(){
		return {
		show: function(index) {
			$(".btnLayerText:eq(" + index + ")").addClass("on");
			$(".btnLayerOpen:eq(" + index + ")").slideDown();
		},
		hide: function(index) {
			$(".btnLayerText:eq(" + index + ")").removeClass("on");
			$(".btnLayerOpen:eq(" + index + ")").slideUp();
		}}
	}

	if( $(".btnLayerText").length > 0 ){
		$(".btnLayerText").bind("click", function(e){
			e.preventDefault();
			if( $(this).hasClass("on") ) {
				btnLayerView().hide( $(this).index(".btnLayerText") );
			} else {
				btnLayerView().show( $(this).index(".btnLayerText") );
			}
		});
	}

	if( $(".btnClose").length > 0 ){
		$(".btnClose").bind("click", function(e){
			e.preventDefault();			
			if( $(this).parent().hasClass("infoDataView") ) {		
				$(this).parent().addClass("none")
				$( ".btnInfoOpen:eq(" + $(".infoDataView").index( $(this).parent() ) + ")" ).removeClass("close").text("��������")
			} else if( $(this).parent().hasClass("autoComplete") ) {
				$(this).parent().addClass("none")
				$( "header" ).removeClass( "headerSearch" )
				$(".search input").val("")
			} else { 
				btnLayerView().hide( $(this).parent().parent().parent().index(".btnClose") );
			}
		});
	}

	//�������(��� 1-8) 
	if( $(".statsResultBox").length > 0 ){
		$(".statsResultBox > h3").bind("click", function(e){
			if( $(this).parent().hasClass("close") ){
				$(this).parent().removeClass("close")
				$(this).parent().addClass("open")
			}
		})

		$(".statsResultBox .btnCloseS").bind("click", function(e){
			e.preventDefault();
			if( $(this).parent().parent().parent().hasClass("open") ){
				$(this).parent().parent().parent().removeClass("open")
				$(this).parent().parent().parent().addClass("close")
			}
		})
	}

	//�� �������� > �� ���� ���� �̷� > ���(��������1-1A) mr/howmoney/html/manage/manage1-1A.html
	$( ".btnInfoOpen" ).bind("click", function(e){
		e.preventDefault();
		if( $( this ).hasClass("close") ){
			$(".infoDataView:eq(" + $(".btnInfoOpen").index(this) + ")").addClass("none")
			$( this ).removeClass("close").text("��������")
		}else{
			$(".infoDataView:eq(" + $(".btnInfoOpen").index(this) + ")").removeClass("none")
			$( this ).addClass("close").text("�����ݱ�")
		}
	})

	if( $(".searchResultFullText").length > 0 ){
		$(".searchResultFullText > .link:eq(1)").hide();	//�ݱ��ư �����
		$(".searchResultFullText > .link > a").bind("click", function(e){
			e.preventDefault();
			if( $(this).parent().hasClass("Close") ){
				$(".searchResultFullText > .default, .searchResultFullText > .link:eq(0)").fadeIn();
				$(".searchResultFullText > .listStyleSquare, .searchResultFullText > .link:eq(1)").hide();
			} else {
				$(".searchResultFullText > .default, .searchResultFullText > .link:eq(0)").hide();
				$(".searchResultFullText > .listStyleSquare, .searchResultFullText > .link:eq(1)").fadeIn();
			}
		})
	}

	//manage, stats page slideTab setting

	
	if( $("nav .slideTab").length > 0 )	{
		slideTabSet();
	}

	//���� fixedBannerAD
	if( $(".fixedBannerAD").length > 0 ){

		var _height = $(document).height();

		$(".container").addClass("fixedBanner");
		var ad = $(".fixedBannerAD"),
			adH = ad.outerHeight(),
			footerTop = getFooterTop(),
			footerH = $("footer").outerHeight(),
			chkGbUa = navigator.userAgent;

		if( $(document).height() < $(window).height() ){
		
		} else {
			if( chkGbUa.indexOf("533") == -1 ){
				$(ad).find("img").css({"position":"relative"});
				setPositionAD()
			} else {
				ad.css("position","absolute");
				setPositionADforGB();
			}
			$(window).bind( "scroll resize", function(e){
				footerTop = getFooterTop();
				chkGbUa.indexOf("533") == -1 ? setPositionAD() : setPositionADforGB();
			});
		}

		//��ʰ� ��ġ�� y����
		function getFooterTop(){
			return $("footer").offset().top - adH - $(".fixedBanner").offset().top;
		}

		MutationObserver = window.MutationObserver || window.WebKitMutationObserver;

		var observer = new MutationObserver(function(mutations, observer) {
			if( _height != $(document).height() ){
				_height = $(document).height();
				footerTop = getFooterTop();
				chkGbUa.indexOf("533") == -1 ? setPositionAD() : setPositionADforGB();
			}
		});

		observer.observe(document, {subtree:true,attributes:true});
	}


	function setPositionAD(){
		if( $(window).scrollTop() >= $(document).height() - $(window).height() - footerH - adH ){
			ad.css({
				"position":"absolute",
				"top": footerTop + "px",
				"bottom":"auto"
			});
		} else {
			ad.css({
				"position":"fixed",
				"top":"auto",
				"bottom":"-1px"
			});
		}
	}

	function setPositionADforGB(){
		if( $(window).scrollTop() >= $(document).height() - $(window).height() - footerH ){
			ad.animate({top:footerTop+"px"}, 0 );
			/*
			ad.css({
				"top":footerTop + "px"
			});
			*/
		} else {
			ad.animate({top:( $(window).scrollTop() + $(window).height() - $(".fixedBanner").offset().top - adH )+"px"}, 0 );
			/*
			ad.css({
				"top": ( $(window).scrollTop() + $(window).height() - $(".fixedBanner").offset().top - adH ) + "px"
			});
			*/
		}
	}

});
//////////////////// load�� ���� : e ////////////////////

//////////////////// resize�� ���� ////////////////////
var s = 0;
$(window).resize(function() {
});

//////////////////// onorientationchange�� ���� ////////////////////
window.onorientationchange = function() {
}

//////////////////// interactive ���� ////////////////////
//////////////////// slideTab ����, ���� �ڵ����� ���� manage, stats slideTab ////////////////////
var kcbSlideTabVar = function(){};
kcbSlideTabVar.cache_is = false;
function slideTabSet(){
	//script file load : s
	var url = "/mr/howmoney/js/jquery.slideTab.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbSlideTabVar.cache_is,
        success: function(data) {
			$(".slideTab").slideTab()
			kcbSlideTabVar.cache_is = true;
        }
      });
	//script file load : e
}
//////////////////// verticalListSet ����, ���� �ڵ����� ����html/search/search1-1.html ////////////////////
// �������������� �Լ�ȣ��� ���
function verticalListSet(){

	var animate_is = false;
	var totalPage = $(".popTop10 .top10 li").length;
	var nowPage = 1;

	$(".popTop10 .prev, .popTop10 .next").bind("click", function(e){
		pageGo( $( e.currentTarget ).attr( "class" ) );
	})
	
	$(".popTop10 .top10 li a").bind("click", function(e){
		if( !e.isTrigger && animate_is ) return;
		if( parseInt( $(this).parent().css("top") ) == 30 ) return;

		$(".popTop10 .top10 li").removeClass("on");
		$(".popTop10 .top10 li:eq(" + $(this).parent().index() + ")").addClass("on");

		$(".popTop10 .GraphInfo ul").hide();
		$(".popTop10 .GraphInfo ul:eq(" + $(this).parent().index() + ")").fadeIn();
		
		if( !e.isTrigger ) {
			parseInt( $(this).parent().css("top") ) < 30 ? pageGo("prev", true) : pageGo("next", true);
		}
	})

	function pageGo( _arrow, _btn_is ){
		if( animate_is ) return;
		rollingTime = 0;	//�Ѹ��ð��� �ʱ�ȭ�Ѵ�.
		if( _arrow == "prev" ){
			nowPage == 0 ? nowPage = totalPage - 1 : nowPage--;
			sortList( nowPage );
			showList("prev", _btn_is);
		} else if( _arrow == "next" ){
			nowPage == totalPage - 1 ? nowPage = 0 : nowPage ++;
			sortList( nowPage );
			showList("next", _btn_is);
		}
	}

	var _sortList_arr = [0, 1, 2, 3, 4]
	function sortList( _num ){
		var j = 0
		for( var i = 0; i < 5; i++ ){
			var targetNum = i + (_num - 2);
			if( targetNum  >= totalPage){
				targetNum = j;
				j++;
			} else if( targetNum <= -1){
				targetNum = totalPage -  ( targetNum * -1 )
			} 
			_sortList_arr[i] = targetNum;
		}
	}			

	function showList( arrowType, _btn_is ){
		animate_is = true;
		for( var i = 0; i < 5; i++ ){
			var el = $(".popTop10 .top10 li:eq(" + _sortList_arr[i] +")")

			if( arrowType == "prev" ){ 
				el.css( { "top" : ( 30 * i ) - 60 })
			} else if( arrowType == "next" ){ 
				el.css( { "top" : ( 30 * i ) })
			}					
			el.animate( { "top" : ( 30 * i ) - 30  },300,function(){
				animate_is = false
			})
		}

		if( !_btn_is ) 	$(".popTop10 .top10 li:eq(" + nowPage +") a").trigger("click")
	}

	//�ʱ���� Class = on�� �Ǿ��ִ� Ÿ���� �����������Ѵ�.

	$(".popTop10 .top10 li").each(function( index, el ){
		if( $(this).hasClass("on") ) nowPage = index;
		$(this).css( { "position" : "absolute", "top": -30,  "width" : "100%"})
	});

	sortList( nowPage );

	$(".popTop10 .GraphInfo ul").hide();

	for( var i = 0; i < 5; i++ ){
		var el = $(".popTop10 .top10 li:eq(" + _sortList_arr[i] +")")
		el.css( { "top" : ( 30 * i ) - 30 })
		if( i == 2 ){
			el.addClass("on")
			$(".popTop10 .GraphInfo ul:eq(" + _sortList_arr[i] + ")").show();
		};
	}

	var rollingTime = 0;	//�Ѹ��ð�
	function rolling(){
		rollingTime++;
		if( rollingTime >= 5 ) pageGo("next");
		setTimeout( rolling, 1000 );
	}

	setTimeout( rolling, true );
}

//////////////////// flicking ���� ///////////////////////
var flickingVar = function(){};
flickingVar.cache_is = false;

function flickingSet(){
	//2013-07-18
	//.flickingMainWrapper, flickingWrapper �����Ѵٸ� ���� : e
	
	if( $(".flickingMainWrapper, .flickingWrapper").length > 0 ){
		//script file load : s		
		var url = "/mr/howmoney/js/jquery.touchslider.pulip.js";
		$.ajax({
			url: url,
			type:'get',
			dataType: 'script',
			cache: flickingVar.cache_is,
			success: function(data) {
				//flick set : s
				var _flickWidth = $(".flickingMainWrapper, .flickingWrapper").css("width")
				$(".flickingMainWrapper, .flickingWrapper").each( function(index, el){
					var el = $( el );
					el.find( $(".flicking > ul > li") ).css( { width : _flickWidth })
					el.touchSlider({container: this,
						duration: 350,
						delay: 1000,
						margin:0,
						mouseTouch: true,
						namespace: "flickingMainWrapper",
						next: el.find( ".next, .flickPaging .next" ), 
						pagination: el.find( ".flickPaging > span" ),
						currentClass: "on",
						prev: el.find( ".prev, .flickPaging .prev" ), 
						autoplay: false, 
						viewport: el.find( ".flicking" ),
						initComplete:function(e){
							//2013-07-24 ���� > ���ӿ��� �ø�ŷ �¿�ȭ��ǥ�� �������ʴ´�.
							
							if( el.parent().attr("class") != "startingSalary" ){
								//prev next button hidden
								$(this)[0].container.find( $(".prev, .flickPaging .prev, .next, .flickPaging .next") ).css("visibility", "visible") 
								if( e.current == 0 ) { 
									$(this)[0].container.find( $(".prev, .flickPaging .prev") ).css("visibility", "hidden") 
								} else if( e.current == $(this)[0].container.find( $(".flicking > ul > li") ).length - 1 ) { 
									$(this)[0].container.find( $(".next, .flickPaging .next") ).css("visibility", "hidden") 
								}
							}
						}
					});

					if( el.parent().attr("class") != "startingSalary" ) {
						el.find( $(".prev, .flickPaging .prev") ).css("visibility", "hidden")
					}
					el.find(".prev, .next").bind( "click", function(e){
						if( $(this).attr("href") == "#" ) e.preventDefault();
					})
				})
				//flick set : e
				flickingVar.cache_is = true;
			}
		  });
		//script file load : e
	}
	//.flickingMainWrapper, flickingWrapper �����Ѵٸ� ���� : e
}


//////////////////// ��Ʈ���� ���� ////////////////////
//////////////////// ������Ʈ kcbDrawPieChart  ///////////////////////
var kcbDrawPieChartVar = function(){};
kcbDrawPieChartVar.cache_is = false;

function kcbDrawPieChart( id, _data ){
	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id
	
	//script file load : s
	var url = "/mr/howmoney/js/jquery.piegraph.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawPieChartVar.cache_is,
        success: function(data) {

			$( id ).pieGraph(
				{container: this,
				viewport: ".svgArea",
				width : 138,	//�⺻���ذ�
				height : 138,	//�⺻���ذ�
				date : _data
			})
			kcbDrawPieChartVar.cache_is = true;
        }
      });
	//script file load : e
}

//////////////////// Ŀ����Ʈ kcbDrawCurveChart  ///////////////////////
var kcbDrawCurveChartVar = function(){};
kcbDrawCurveChartVar.cache_is = false;

function kcbDrawCurveChart( id, range, x ){
	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id

	//script file load : s
	var url = "/mr/howmoney/js/jquery.curvegraph.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawCurveChartVar.cache_is,
        success: function(data) {

			$( id ).curveGraph(
				{container: this,
				rangeData : range,			//����ġ
				data : x,
				color:[ "33, 90, 169, 1"]	//����Ʈ, ���� �� r,g,b,alpha
			})
			kcbDrawCurveChartVar.cache_is = true;

        }
      });
	//script file load : e

}

//////////////////// ������Ʈ kcbDrawBarChartA~D  ///////////////////////
var kcbDrawBarChartAVar = function(){};
kcbDrawBarChartAVar.cache_is = false;
function kcbDrawBarChartA( id, range, x ){

	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id
	//script file load : s
	var url = "/mr/howmoney/js/jquery.barchart_a.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawBarChartAVar.cache_is,
        success: function(data) {			

			$( id ).barchartAGraph(
				{container: this,
				data : {
					rangeData : range,			//����ġ
					data : x
				}
			})
			kcbDrawBarChartAVar.cache_is = true;
        }
      });
}

var kcbDrawBarChartBVar = function(){};
kcbDrawBarChartBVar.cache_is = false;
function kcbDrawBarChartB( id, minData, maxData, option ){

	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id
	//script file load : s
	var url = "/mr/howmoney/js/jquery.barchart_b.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawBarChartBVar.cache_is,
        success: function(data) {			

			$( id ).barchartBGraph(
				{container: this,
				data : {
					minData : minData,
					maxData : maxData,
					option : option
				}
			})
			kcbDrawBarChartBVar.cache_is = true;
        }
      });
	//script file load : e

}

var kcbDrawBarChartCVar = function(){};
kcbDrawBarChartCVar.cache_is = false;
function kcbDrawBarChartC( id, _data, option ){

	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id
	//script file load : s
	var url = "/mr/howmoney/js/jquery.barchart_c.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawBarChartCVar.cache_is,
        success: function(data) {			

			$( id ).barchartCGraph(
				{container: this,
				data : {
					_data : _data,
					option : option
				}
			})
			kcbDrawBarChartCVar.cache_is = true;
        }
      });
	//script file load : e

}

var kcbDrawBarChartDVar = function(){};
kcbDrawBarChartDVar.cache_is = false;

function kcbDrawBarChartD( id, minData, avgData, maxData, option ){
	if( id.indexOf( "." ) == -1 && id.indexOf( "#" ) == -1  ) id = "#"+id

	//script file load : s
	var url = "/mr/howmoney/js/jquery.barchart_d.pulip.js";
	$.ajax({
        url: url,
		type:'get',
        dataType: 'script',
		cache: kcbDrawBarChartDVar.cache_is,
        success: function(data) {			

			$( id ).barchartDGraph(
				{container: this,
				data : {
					averageTitle : "���",
					minData : minData,
					avgData : avgData,
					maxData : maxData,
					option : option
				}
			})
			kcbDrawBarChartDVar.cache_is = true;
        }
      });
	//script file load : e
}