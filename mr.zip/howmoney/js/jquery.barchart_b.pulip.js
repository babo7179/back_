/*
 �ۼ���		: PULIP COMMUNICATIONS - Smart Media Group
 ���������� : 2013-07-23 11:12
*/

(function($, undefined) {
	window.barchartBGraph = function(options) {
		
		options = options || {};

		options = $.extend({
				container: null,
				data: null
			}, options);

		var data = options.data

	/*
		- ������ ����׷��� ( ����� �ϳ��� ���������մϴ�. )
		http://dwps.allcredit.co.kr:7070/mr/howmoney/html/manage/manage1-3.html
		�����ڵ� Ÿ�� class = graphGrade

		�Լ���
		kcbDrawBarChartB( id, minData = {}, maxData= {}, option = {} )


		id =		�׷����� ������ Ÿ��ID��
		minData = {
			min : 0,	�������� ���ߵ� �ۼ�Ʈ��
		}
		maxData = {
			max : 0,	�׷����� ǥ���� �ۼ�Ʈ�� ( ������ max - min ���� �׷�������ǥ�� )
		}
		option = {
			height : 7		//�׷��� ���α��̰� �ȼ�����
			color : #ffffff,	//�׷��� ��
			bgcolor : #ffffff,	//��׶��� ��
			sectionCount : 1 ~ 15	//���� ������ ������ ����
			shadow : true or false	//�׸���ȿ��
		}
	*/
		if( data.option.height == undefined ) data.option.height = 10
		if( data.option.lineBottom == undefined ) data.option.lineBottom = true;

		var container = $( options.container );
		var _barHeight = data.option.height;	//bar height
		function draw(){
			var htmls =	'';

			var _addClass = ""
			if( data.minData.min != 0 ) _addClass = "leftRadius";
			container.addClass("kcbDrawBarChartB");
			
			var _topPosition = ( parseInt( $(container).css("height") )/2 ) - ( _barHeight / 2 );
			
			htmls +=	'<span class="rightRadius ' + _addClass + '" style="position:absolute;left:' + data.minData.min  + '%;top:' + _topPosition + 'px;';
			htmls +=	'width:' + ( data.maxData.max - data.minData.min ) + '%;height:' + _barHeight + 'px;';
			htmls +=	'background:' + data.option.color +";";
			if( data.option.shadow == true ) htmls += "-webkit-box-shadow:1px 1px 1px 0px rgba(0, 0, 0, 0.3);-moz-box-shadow:1px 1px 1px 0px rgba(0, 0, 0, 0.3);box-shadow:1px 1px 1px 0px rgba(0, 0, 0, 0.3);"
			htmls +=	';">'
			//�������ڻ���
			if(data.minData.minStr != undefined) {
				var markLeftPosition = 2;
				var markLeftTextColor = data.option.color
				if( parseInt( data.minData.min ) <= 22 ) {
					markLeftTextColor = "#FFFFFF";
				} else { 
					markLeftPosition = -( ( data.minData.minStr.replace(",", "").length * 4.5 )+6 );
				}
				htmls += '<mark class="leftMark" style="color:' + markLeftTextColor + ';top:' + (( _barHeight / 2 ) - 5 ) + 'px;'
				htmls += 'left:' + markLeftPosition + 'px;">' + data.minData.minStr + '</mark>'
			}
			//�������ڻ���
			if(data.maxData.maxStr != undefined) {
				var markRightPosition = 3;
				var markRightTextColor = data.option.color
				if( parseInt( data.maxData.max ) >= 78 ) {
					markRightTextColor = "#FFFFFF";
				} else { 
					markRightPosition = -(( data.maxData.maxStr.replace(",", "").length * 4.5 )+6 );
				}

				htmls += '<mark style="color:' + markRightTextColor + ';top:' + (( _barHeight / 2 ) - 5 ) + 'px;';						
				htmls += 'right:' + markRightPosition + 'px;">' + data.maxData.maxStr + '</mark>';
			}
			htmls +=	'</span>';

			

			//��׶��� �������λ���
			var _style ="";
			if( data.option.bgcolor != undefined ) _style += "background: rgba(188, 216, 239, 0.2);"

			if( data.option.lineBottom ) _style += "background-image:url(/mr/howmoney/img/common/graph_bg_h.png),";
				else	_style += "background-image:";

			for( i = 0; i < data.option.sectionCount; i++ ){
				_style += "url(/mr/howmoney/img/common/stats_graph_bg.png)" + getStyleComma(i, data.option.sectionCount)
			}

			if( data.option.lineBottom ) _style += "background-position:left bottom,"
				else	_style += "background-position:" 

			for( i = 0; i < data.option.sectionCount; i++ ){
				_style += ( (100/( data.option.sectionCount - 1 )) * i ) + "% 0px" + getStyleComma(i, data.option.sectionCount)
			}

			if( data.option.lineBottom ) _style += "background-repeat:repeat-x,"
				else	_style += "background-repeat:"

			for( i = 0; i < data.option.sectionCount; i++ ){
				_style += "no-repeat" + getStyleComma(i, data.option.sectionCount)
			}

			if( data.option.lineBottom ) _style += "background-size:3px 1px,"
				else	_style += "background-size:"

			for( i = 0; i < data.option.sectionCount; i++ ){
				_style += "1px 70px" + getStyleComma(i, data.option.sectionCount)
			}

			$( container ).attr("style" , _style)


			if( $( container ).children().length > 0 ) $( container ).find( $( container ).children()[0] ).before(htmls );
				else  $( htmls ).appendTo( container );
			
		}

		draw();
	};

	function getStyleComma( index, total ){
		var _comma = ";"
		if( index == total - 1 || total == 1) { 
			_comma = ";"
		} else if( index < total ) { 
			_comma = ","
		}  
		return _comma;
	}

	$.fn.barchartBGraph = function(options) {
		options = options || {};
		options.container = this;
		barchartBGraph(options);
		return this;
	};
}(jQuery));
