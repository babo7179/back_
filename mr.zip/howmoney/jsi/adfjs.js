function adfJsAttachEventHandler(id, event, fnEventHandler ) {
    $('#'+id).on(event, fnEventHandler);
}
function adfJsDocLoaded(fnOnLoad) {
    $(document).ready(fnOnLoad);
}
function adfJsGetValueById(id) {
    return $('#'+id).val();
}
function adfJsGetValue(id) {
    return adfJsGetValueById(id);
}
function adfJsSetFocusById(id) {
    $('#'+id).focus();
}
function adfJsSetFocus(id) {
    adfJsSetFocusById(id);
}
function adfJsAlert(msg) {
    alert(msg);
}
function adfJsCallAjaxPost( url, data, fnSuccess, fnError )
{
	$.ajax({
		type:"POST",
		url:url,
		data:data,
		contentType:"application/x-www-form-urlencoded;charset=UTF-8",
		dataType:"text",
		success:fnSuccess,
		error:fnError	
	});
}
