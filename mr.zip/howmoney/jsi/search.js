jQuery().ready(function()
{
	$(".search > input,.searchInputArea > input").on("keyup keydown keypress",function (){
		var tempAuto = localStorage.getItem("howmoneyAutoCom");
		
		if(null != tempAuto && '' != tempAuto){
			var tempAutoArray = tempAuto.split(";");
			
			if($(this).val().trim()!=""){
				var tempAutoArray2 = searchAutoList($(this).val(), tempAutoArray);
			}else{
				$("#"+$(this).attr("id")+"_list").addClass("none");
				return;
			}
			
			if(tempAutoArray2.length < 1){
				$("#"+$(this).attr("id")+"_list").addClass("none");
				return;
			}
			
			var searchHtml = "";
			for(var i=0; i<tempAutoArray2.length;i++){
				searchHtml += "<li><a href=\"javascript:setComNm('"+$(this).attr("id")+"','"+tempAutoArray2[i]+"');\">"+tempAutoArray2[i]+"</a></li>\n";
			}
			$("#"+$(this).attr("id")+"_list > ul").html(searchHtml);
			$("#"+$(this).attr("id")+"_list").removeClass("none");
		}
	});		$("#jobForm").submit(function(){				searchComNm('comNm');		return false;	});
});
function searchComNm(obj){
	var earchStr = $("#"+obj).val();
	var limit_char = /[~!\#$^*\=+|:;?"<>']/;
	if(limit_char.test(earchStr))
	{
		alert("Ư�����ڴ� �˻� �� �� �����ϴ�.");
		$("#"+obj).val("");
		return false;
	}
	if(earchStr.trim()=="" || earchStr.trim().length < 2)
	{
		alert("2���� �̻� �Է��ϼ���.");
		return false;
	}
	
	$("#COM_NM").val(earchStr);
	var tempAuto = localStorage.getItem("howmoneyAutoCom");
	if(null == tempAuto || '' == tempAuto)
	{
		localStorage.setItem("howmoneyAutoCom",earchStr);
	}else{
		var tempAutoArray = tempAuto.split(";");
		var autoListAddFlag = false;
		var setAutoList = "";
		for(var i=0; i<tempAutoArray.length;i++)
		{
			if(autoListAddFlag){
				setAutoList += ";";
				autoListAddFlag = false;
			}
			if(tempAutoArray[i] != earchStr && i<=30)
			{
				setAutoList += tempAutoArray[i];
				autoListAddFlag = true;
			}
		}
		
		localStorage.setItem("howmoneyAutoCom",earchStr+";"+setAutoList);
	}
	document.jobForm.submit();
}
function searchAutoList(comNm, tempAutoArray)
{
	var aLength = tempAutoArray.length;
	for(var i = aLength-1; i>=0;i--){
		if(tempAutoArray[i].toUpperCase().indexOf(comNm.toUpperCase())==-1){
			tempAutoArray.splice(i,1);
		}
	}
	return tempAutoArray;
}
// Auto Complete List�� Id�� obj�� ���� + "_list"�� id�� �ο��ؾ��Ѵ�.
function setComNm(obj, val){
	$("#"+obj).val(val);
	$("#"+obj + "_list").addClass("none");
}
