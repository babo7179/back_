function haircut(val) {
	if ( typeof val === 'string' ) { 
		return eval(val.replace(/,/g, ''));
	} else {
		return val;
	}
}

function kcbPieChart( id, _data ){
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;
	
	var data2 = new Array();
	var minVal = _data[0][1];
	var maxVal = _data[0][1];
	var sumVal = 0;
	for ( var i in _data ) {
		sumVal += _data[i][1];
		if ( minVal > _data[i][1] ) minVal = _data[i][1];
		if ( maxVal < _data[i][1] ) maxVal = _data[i][1];
	}
	var j = 0;
	for ( var i in _data ) {
		if ( sumVal / 100 > _data[i][1] ) continue;
		data2[j] = new Array();
		data2[j][0] = _data[i][0];
		data2[j][1] = Math.round(_data[i][1] *100 / sumVal, 2);
		j++;
	}
	kcbDrawPieChart( id, data2);
    // kcbDrewPieChart( ����ID, [[�÷���, ��] * list] );
	//kcbDrawPieChart( "pieChart1", [ [ "#63b1f3", 100 ], [ "#2eb098", 200 ], [ "#f1666b", 30 ], [ "#723083", 350 ], [ "#0091d2", 100 ], [ "#9bcd6e", 120 ], [ "#836bc7", 200 ] ]);
}

function calMultiplier(x) {
	var mult = 0.1;
	for ( var i = 0 ; i < 10 ; i++ ) {
		if ( Math.floor(x / mult) == 0 ) {
			mult /= 10;
			break;
		} 
		mult *= 10;
	}
	return mult;
}

function calMinMaxSection( min, max, sectionCount ) {
	var minVal=min;
	var maxVal=max;
	var multiplier=1;
	var sectionSize=1;
	
	//console.log('calMinMaxSection min=' + min + ' max=' + max + ' sectionCount=' + sectionCount);

	if ( min == max ) {
		sectionSize = calMultiplier(max);
		minVal = min - (sectionSize * Math.floor(sectionCount/2));
		maxVal = minVal + (sectionSize * (sectionCount-1));
	} else {
		sectionSize = (maxVal - minVal) / (sectionCount-2);
			
		minVal = minVal - (0.1 * sectionSize);
		if ( minVal < 0 ) minVal = 0;
		maxVal = maxVal + (0.1 * sectionSize);
		if ( minVal == 0 ) {
			sectionSize = (maxVal - minVal) / (sectionCount-1);
		} else {
			sectionSize = (maxVal - minVal) / (sectionCount-2);
		}
	
		multiplier = calMultiplier(sectionSize);
		//console.log('calMinMaxSection multiplier=' + multiplier );
		
		//console.log('calMinMaxSection sectionSize(before)=' + sectionSize );
		sectionSize = Math.ceil(sectionSize / multiplier) * multiplier;
		minVal = Math.floor(minVal / sectionSize) * sectionSize;
		maxVal = minVal + (sectionSize * (sectionCount-1));
		if ( maxVal - max > sectionSize * 1.5 && minVal > sectionSize / 2) {
			minVal -= Math.floor(sectionSize/2);
			maxVal -= Math.floor(sectionSize/2);
		}
		//console.log('calMinMaxSection sectionSize(after)=' + sectionSize );
		//console.log('calMinMaxSection minVal = ' + minVal);
		//console.log('calMinMaxSection maxVal = ' + maxVal);
	}
	var result = new Array();
	result[0] = minVal;
	result[1] = maxVal;
	result[2] = sectionSize;
	return result;
}

function kcbCurveChart( id, _data ){
	//console.log('start kcbCurveChart ++');
	var sectionCount = 5;
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;
	
	var data2 = new Array();
	
	var minVal = _data[0][1];
	var maxVal = _data[0][1];
	for ( var i in _data ) {
		if ( minVal > _data[i][1] ) minVal = _data[i][1];
		if ( maxVal < _data[i][1] ) maxVal = _data[i][1];
	}
	
	var ret = calMinMaxSection(minVal, maxVal, sectionCount);
	var sectionSize = ret[2];
	minVal = ret[0];
	maxVal = ret[1];
	
	var yaxis = new Array();
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		yaxis[i] = Math.round((minVal + sectionSize * i) * 100) / 100  ;
	}
	
	for ( var i = 0 ; i < _data.length; i++ ) {
		data2[i] = new Array();
		data2[i][0] = _data[i][0];
		data2[i][1] = Math.round( (_data[i][1] - minVal) * 100 / (maxVal-minVal) );
	}
	//alert ('data2 = ' + data2 );
	kcbDrawCurveChart( id, yaxis, data2);
	//kcbDrawCurveChart ( ����ID, [y�ప��], [[x�׸�, ��(%)] * list] );
	//kcbDrawCurveChart( "curveGraph2", [ 110, 120, 130, 140, 160 ], [ [2009, 20], [2010, 0], [2011, 100], [2012, 80] ]);
	//console.log('end kcbCurveChart ++');
}

function kcbCurveChartIndex( id, _data ){
	////console.log('start kcbCurveChartIndex ++');
	var sectionCount = 5;
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;
	
	var data2 = new Array();
	
	var ret = calMinMaxSection(minVal, maxVal, sectionCount);
	var sectionSize = 10;
	var minVal = 90;
	var maxVal = 130;
	
	var yaxis = new Array();
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		yaxis[i] = Math.round((minVal + sectionSize * i) * 100) / 100  ;
	}
	
	for ( var i = 0 ; i < _data.length; i++ ) {
		data2[i] = new Array();
		data2[i][0] = _data[i][0];
		data2[i][1] = Math.round( (_data[i][1] - minVal) * 100 / (maxVal-minVal) );
	}
	kcbDrawCurveChart( id, yaxis, data2);
	//console.log('end kcbCurveChartIndex ++');
}

function kcbBarChartVertical( id, _data ){
	//console.log('start kcbBarChartVertical ++');
	var sectionCount = 5;
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;
	
	var data2 = new Array();
	
	var minVal = _data[0][1];
	var maxVal = _data[0][1];
	for ( var i in _data ) {
		if ( minVal > _data[i][1] ) minVal = _data[i][1];
		if ( maxVal < _data[i][1] ) maxVal = _data[i][1];
	}
	var ret = calMinMaxSection(minVal, maxVal, sectionCount);
	var sectionSize = ret[2];
	minVal = ret[0];
	maxVal = ret[1];
	
	var yaxis = new Array();
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		yaxis[i] = (Math.round((minVal + sectionSize * i) * 100) / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");  ;
	}
	
	for ( var i = 0 ; i < _data.length; i++ ) {
		data2[i] = new Array();
		data2[i][0] = _data[i][0];
		data2[i][1] = Math.round( (_data[i][1] - minVal) * 100 / (maxVal-minVal) );
	}
	kcbDrawBarChartA( id, yaxis, data2);
	//console.log('end kcbBarChartVertical ++');
}


function kcbBarChartMinMaxAvg( id, minarg, maxarg, avgarg ){
	//console.log('start kcbBarChartMinMaxAvg ++');
	var sectionCount = 5;
	if (id === undefined || id === null) return false;
	
	var min = minarg, max = maxarg, avg = avgarg;

	if ( (''+avgarg).indexOf("*") != -1 ) { avg = 5000; min = 3000; max = 7000; }
	if ( (''+min).indexOf("*") != -1 )    { min = haircut(avg) - 2000; }
	if ( (''+max).indexOf("*") != -1 )    { max = haircut(avg) + 2000; }
	
	min = haircut(min);
	max = haircut(max);
	avg = haircut(avg);
	
	var ret = calMinMaxSection(min, max, sectionCount);
	var sectionSize = ret[2];
	var minVal = ret[0];
	var maxVal = ret[1];
	
	var xaxis = new Array();
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		xaxis[i] = (Math.round((minVal + sectionSize * i) * 100) / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")  ;
	}
	
	var minPercent = Math.round( (min - minVal) * 100 / (maxVal-minVal) );
	var minPercentStr = min.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	var maxPercent = Math.round( (max - minVal) * 100 / (maxVal-minVal) );
	var maxPercentStr = max.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	var avgPercent = Math.round( (avg - minVal) * 100 / (maxVal-minVal) );
	var avgPercentStr = avg.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	
	if ( (''+avgarg).indexOf("*") != -1 ) {
		avgPercentStr = ""; minPercent = ""; maxPercent = "";
	}
	if ( (''+minarg).indexOf("*") != -1 ) {
		minPercent = "";
	}
	if ( (''+maxarg).indexOf("*") != -1 ) {
		maxPercent = "";
	}
	
	kcbDrawBarChartD(id, 
		{min: minPercent, minStr:minPercentStr}, 
		{avg: avgPercent, avgStr:avgPercentStr}, 
		{max: maxPercent, maxStr:maxPercentStr}, 
		{sectionCount:xaxis}
	);
	//console.log('end kcbBarChartMinMaxAvg ++');
}

function createHtml(htmlStr) {
	var frag = document.createDocumentFragment(),
		temp = document.createElement('div');
	temp.innerHTML = htmlStr;
	while (temp.firstChild) {
		frag.appendChild(temp.firstChild);
	}
	return frag;
}

function kcbBarChartCompare( id, _data ){
	//console.log('start kcbBarChartCompare ++');
	var sectionCount = 5;
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;

	for (var i = 0 ; i < _data.length ; i++ ) {
		_data[i][1] = haircut(_data[i][1])
	}
	
	var dataSize = _data.length;
	
	var maxVal = _data[0][1];
	var minVal = _data[0][1];
	for ( var i in _data ) {
		if ( maxVal < _data[i][1] ) maxVal = _data[i][1];
		if ( minVal > _data[i][1] ) minVal = _data[i][1];
	}
	var ret = calMinMaxSection(minVal, maxVal, sectionCount);
	var sectionSize = ret[2];
	minVal = ret[0];
	maxVal = ret[1];
	
	var data2 = new Array();
	var idDiv = document.getElementById(id);
	var idNamed = "";
	var fragment;
	//fragment = createHtml("<div id=\"_kcbBarChartCompareDiv" + id + "\" class="graph"><ul id=\"barChart\"></ul><ul id=\"barValue\"></ul></div>");
	fragment = createHtml("<ul id=\"barChart\"></ul><div id=\"_" + id + "Info\" class=\"info length" + sectionCount + "\"><p class=\"unit\">(���� : ����)</p></div>");
	idDiv.appendChild(fragment);
	var idLiChart = document.getElementById( id ).getElementsByTagName('ul')[0];
	var idLiVal = document.getElementById( id ).getElementsByTagName('ul')[1];
	for ( var i = 0 ; i < dataSize - 1; i++ ) {
		idNamed = "_kcbBarChartCompareLi" + id + i;
		fragment = createHtml("<li><b>"+ _data[i][0] +"</b><div id=\""+ idNamed + "\"></div></li>"); 
		idLiChart.appendChild(fragment);
		var calVal = Math.round( (_data[i][1] - minVal) * 100 / (maxVal-minVal) );
		kcbDrawBarChartB(idNamed, {min:0}, {max:calVal, maxStr:calVal?_data[i][1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","):"" }, {	color : "#659acc", sectionCount : sectionCount });
	}
	// ������
	idNamed = "_kcbBarChartCompare" + id + "MySalary";
	fragment = createHtml("<li><b>" + _data[dataSize-1][0] + "</b><div id=\""+ idNamed + "\"></div></li>"); 
	idLiChart.appendChild(fragment);
	var calVal = Math.round( (_data[dataSize-1][1] - minVal) * 100 / (maxVal-minVal) );
	kcbDrawBarChartB(idNamed, {min:0}, {max:calVal, maxStr: calVal?_data[dataSize-1][1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","):""}, {	height : 14,							//�׷��� ���α��̰� �ȼ�����, default = 7
										color : "#e55050",						//�׷��� ��
										bgcolor : "rgba(188, 216, 239, 0.2)",	//�⺻�� ������, �������� �������γ��������� raba ���ʿ� 
										shadow : true,							//�׸���ȿ�� default = false
										sectionCount : sectionCount, 						// sectionCount �ּҰ� 2��									
										lineBottom:false}						// �ϴ��������� ǥ������ default = ture; ����������Ʈ�� �ϴ����������� ������մϴ�.
										);

	idDiv = document.getElementById( "_" + id + "Info" );
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		fragment = createHtml("<p>" + (Math.round((minVal + sectionSize * i) * 100) / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "</p>");
		idDiv.appendChild(fragment);	
	}
	
	//console.log('end kcbBarChartCompare ++');
}

function kcbBarChartCompareGender( id, _data ){
	//console.log('start kcbBarChartCompareGender ++');
	var sectionCount = 4;
	if (id === undefined || id === null) return false;
	if (_data === undefined || _data === null || _data.length <= 0 ) return false;
	
	var dataSize = _data.length;

	for (var i = 0 ; i < _data.length ; i++ ) {
		_data[i][1] = haircut(_data[i][1]);
		_data[i][2] = haircut(_data[i][2]);
	}
		
	var maxVal = _data[0][1];
	var minVal = _data[0][1];
	for ( var i in _data ) {
		if ( maxVal < _data[i][1] ) maxVal = _data[i][1];
		if ( maxVal < _data[i][2] ) maxVal = _data[i][2];
		if ( minVal > _data[i][1] ) minVal = _data[i][1];
		if ( minVal > _data[i][2] ) minVal = _data[i][2];
		
	}
	var ret = calMinMaxSection(minVal, maxVal, sectionCount);
	var sectionSize = ret[2];
	minVal = ret[0];
	maxVal = ret[1];
	
	var data2 = new Array();
	var idDiv = document.getElementById(id);
	var idNamed = "";
	var fragment;
	//fragment = createHtml("<div id=\"_kcbBarChartCompareDiv" + id + "\" class="graph"><ul id=\"barChart\"></ul><ul id=\"barValue\"></ul></div>");
	fragment = createHtml("<ul id=\"_barChart98\"></ul><div class=\"info length" + sectionCount + "\" id=\"_kcbBarChart98Unit\"><p class=\"unit\">(���� : ����)</p></div>");
	idDiv.appendChild(fragment);
	var idLiChart = document.getElementById( id ).getElementsByTagName('ul')[0];
	for ( var i = 0 ; i < dataSize; i++ ) {
		idNamed = "_kcbBarChartGenderLi" + id + i;
		fragment = createHtml("<li><b>" + _data[i][0] + "</b><div id=\""+ idNamed + "\"></div></li>"); 
		idLiChart.appendChild(fragment);
		var calVal1 = Math.round( (_data[i][1] - minVal) * 100 / (maxVal-minVal) );
		var calVal2 = Math.round( (_data[i][2] - minVal) * 100 / (maxVal-minVal) );
		kcbDrawBarChartC(idNamed, [ [{min:0}, {max:calVal1, maxStr:_data[i][1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}, "#4886c2" ], 
		                           [{min:0}, {max:calVal2, maxStr:_data[i][2].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}, "#e55050" ]  ], 
		                           {sectionCount : sectionCount, lineBottom:false }
		);
	}
	
	idDiv = document.getElementById("_kcbBarChart98Unit");
	for ( var i = 0 ; i < sectionCount ; i++ ) {
		fragment = createHtml("<p>" + (Math.round((minVal + sectionSize * i) * 100) / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "</p>");
		idDiv.appendChild(fragment);
	}
	//console.log('end kcbBarChartCompareGender ++');
}
