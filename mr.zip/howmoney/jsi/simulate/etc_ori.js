			// **************** 기타 관련 ****************>> //
			/**
			 * 쿠키저장
			 * @param   string name 쿠키명
			 * @param	string value 쿠키값
			 * @param	string expiredays 쿠키 만기일수
			 */
			function setCookie(name, value, expiredays) {
				var todayDate = new Date();
				todayDate.setDate(todayDate.getDate() + expiredays);
				document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";";
			}
			
			function check_window() {
				if ( document.getElementById("oneweek").checked ){
					setCookie(cookie_name, "Y" , 7);
				}else{
					setCookie(cookie_name, "N", 7);
				}
			}
				
			/**
			 * 쿠키조회
			 * @param   string name 쿠키명
			 * @return   string name 쿠키값
			 */
			function getCookie(name) {
				var Found = false;
				var start, end; 
				var i = 0;
			
				while(i <= document.cookie.length) {
					start = i;
					end = start + name.length;
					if(document.cookie.substring(start, end) == name) { 
						Found = true;
						break;
					}
					i++;
				}
			
				if(Found == true) {
					start = end + 1;
					end = document.cookie.indexOf(';', start);
			
					if(end < start) {
						end = document.cookie.length;
					}
					return document.cookie.substring(start, end);
				}
				return '';
			}
			
			// 쿠키 저장 여부 확인 후 공지 팝업 출력
			function getNotice(layer_gbn) {
				if(!validCheck()) return;
				
				// 사용기간 만료일 경우 제한
				if(useType == "E") {
					infoLayer_open("expireLayer");
					return;
				}
				
				// 체험판일 경우 일괄종합예측 제한
				if(useType == "T" && layer_gbn == "m") {
					infoLayer_open("limitLayer1");
					return;
				}
				
				var notice = getCookie(cookie_name);
				if(notice.length > 0) {
					if(notice.indexOf("Y") != 0) {
						notice_open();
						notice_layer = layer_gbn;
					} else {
						if(layer_gbn == "s") {
							item_choice_open();
						} else if(layer_gbn == "m") {
							tot_simul();
						}
					}
				} else {
					notice_open();
					notice_layer = layer_gbn;
				}
			}
			// <<**************** 기타 관련 **************** //
			
			// **************** 공통 관련 ****************>> //
			// 결과 문구 셋팅
			function resultMsgSet(result, divGbn) {
				var resultArr = result.split("|");
				
				var updownGbn = "";
				var chgGrad = 0;
				var chg_txt = "";
				var chg_txt1 = "";
				var amt_txt = "";
				var amt_symbol = "";
				var info_txt = "";
				var grad_amt = resultArr[3];
				
				if(eval(resultArr[0]) == eval(resultArr[1])) {
					updownGbn = "E";
				} else if((eval(resultArr[0]) - eval(resultArr[1])) > 0) {
					updownGbn = "U";
					chgGrad = eval(resultArr[0]) - eval(resultArr[1]);
					chg_txt = "상승";
					chg_txt1 = "개선될";
					amt_txt = "지출을 줄일 수 있습니다.";
					amt_symbol = "+";
					info_txt = "이로 인해 대출이자율 하락, 대출개설 가능성, 카드 발급 가능성 상승이 예상됩니다.";
				} else {
					updownGbn = "D";
					chgGrad = eval(resultArr[1]) - eval(resultArr[0]);
					chg_txt = "하락";
					chg_txt1 = "하락할";
					amt_txt = "지출이 늘어날 수 있습니다.";
					amt_symbol = "-";
					info_txt = "이로 인해 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성 하락이 예상됩니다.";
				}
				
				// 이미지 처리 (상승/하락/유지)
				var img = "";
				if(updownGbn == "E") {
					img = "/sys/img/am/am57/layer/creditRateing_equal.gif"
				} else if(updownGbn == "U") {
					img = "/sys/img/am/am57/layer/creditRateing_up.gif"
				} else {
					img = "/sys/img/am/am57/layer/creditRateing_down.gif"
				}
				
				var gudMsg = "";
				var strTerm = ""; 				
				// 예상 결과 문구 셋팅
				if(gradViewYN == "N"){
					var gradMsg = "";
					if(updownGbn == "E") {
						gradMsg = "<img src='/sys/img/am/am57/layer/result_txt04.gif' alt='현재등급 그대로' />";
						document.getElementById("gradMsg_" + divGbn).innerHTML = gradMsg;
					} else {
						gradMsg = "<span class='result_txt02'><img src='/sys/img/am/am57/layer/result_txt02.gif' alt='현재등급에서' /></span><span id='chg_grad1" + divGbn + "'></span><span class='result_txt02'><img src='/sys/img/am/am57/layer/result_txt03.gif' alt='등급' /></span>";
						document.getElementById("gradMsg_" + divGbn).innerHTML = gradMsg;
						document.getElementById("chg_grad1" + divGbn).innerHTML = "<strong class='n01'>" + chgGrad + "</strong>";
					}
					
					document.getElementsByName("img_grad")[divGbn].src = img;
					document.getElementsByName("chg_percent")[divGbn].innerHTML = "<strong class='sy01'>" + resultArr[2] + "</strong>%";
					
					if(updownGbn == "E") {
						gudMsg  = "<p class='creditValue_cmt301'>고객님은 입력하신 신용정보가 변경되어도 <strong>등급을 유지할 확률이 <span id='chg_percent" + divGbn + "'></span></strong>입니다. </p>";
						gudMsg += "<p class='pt25'><img src='/sys/img/am/am57/layer/result_check.gif' alt='보다 구체적인 예측을 하시려면, 고객님의 현재등급 확인이 필요합니다.'><a href='javascript:fncAP1100()' class='pl5'><img src='/sys/img/am/am57/layer/result_go.gif' alt='확인하러가기'></a></p>";
						
						document.getElementById("gudMsg_" + divGbn).innerHTML = gudMsg;
						
						document.getElementById("chg_percent" + divGbn).innerHTML = resultArr[2] + "%";
					} else {
						gudMsg  = "<p class='creditValue_cmt301'>고객님은 <strong><span id='chg_grad2" + divGbn + "'></span>등급 <span id='chg_txt" + divGbn + "'></span>할 확률이 <span id='chg_percent" + divGbn + "'></span></strong>입니다. 등급이 변경되면, 고객님이 만약 1억원의 대출을 받았을 <br />경우, <span id='grad_amt" + divGbn + "'></span>원의 연간대출이자 <span id='amt_txt" + divGbn + "'></span></p>";
						gudMsg += "<p class='pt25'><img src='/sys/img/am/am57/layer/result_check.gif' alt='보다 구체적인 예측을 하시려면, 고객님의 현재등급 확인이 필요합니다.'><a href='javascript:fncAP1100()' class='pl5'><img src='/sys/img/am/am57/layer/result_go.gif' alt='확인하러가기'></a></p>";
						
						document.getElementById("gudMsg_" + divGbn).innerHTML = gudMsg;
						
						document.getElementById("chg_grad2" + divGbn).innerHTML = chgGrad;
						document.getElementById("chg_txt" + divGbn).innerHTML = chg_txt;
						document.getElementById("chg_percent" + divGbn).innerHTML = resultArr[2] + "%";
						document.getElementById("grad_amt" + divGbn).innerHTML = grad_amt;
						document.getElementById("amt_txt" + divGbn).innerHTML = amt_txt;
					}
				} else {
					if(updownGbn == "E") {
						gudMsg  = "<p>고객님은 현재 <span id='bef_grad1" + divGbn + "'>7</span>등급으로, 입력하신 신용정보가 변경되어도 <span id='chg_term" + divGbn + "'></span> 등급을 유지할 확률이 <span id='chg_percent1" + divGbn + "'><strong>75%</strong></span>입니다.<p>";
						gudMsg += "<p class='pt25'>고객님의 등급에 변경이 없어 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성에는 영향이 없습니다.</span> 대출/카드와 등급의 관계를 확인하시려면, <a href='javascript:goPage(\"chk\")'><strong>대출/카드 진단</strong><img src='/sys/img/am/am57/layer/btn_goDiagnosis.gif' alt='바로가기'></a>을 이용해 보세요.</p>";
						
						if((divGbn != "M1" || divGbn != "M2") && (divGbn == "0" || divGbn == "1")) {
							strTerm = "3개월 이후에도 ";
						} else {
							strTerm = "1년동안  ";
						}
	
						document.getElementById("gudMsg_" + divGbn).innerHTML = gudMsg;
						if(divGbn == "M1" || divGbn == "M2") {
							// 예상 결과 테이블 셋팅
							document.getElementById("bef_grad" + divGbn).innerHTML = "<strong class='b'>" + resultArr[0] + "</strong>";
							document.getElementById("aft_grad" + divGbn).innerHTML = "<strong class='y'>" + resultArr[1] + "</strong>";
							document.getElementById("img_grad" + divGbn).src = img;
							document.getElementById("chg_percent" + divGbn).innerHTML = "<strong class='sy'>" + resultArr[2] + "</strong>%";
							document.getElementById("grad_amt" + divGbn).innerHTML = "<strong>" + grad_amt + "</strong>원";
						} else {
							// 예상 결과 테이블 셋팅
							document.getElementsByName("bef_grad")[divGbn].innerHTML = "<strong class='b'>" + resultArr[0] + "</strong>";
							document.getElementsByName("aft_grad")[divGbn].innerHTML = "<strong class='y'>" + resultArr[1] + "</strong>";
							document.getElementsByName("img_grad")[divGbn].src = img;
							document.getElementsByName("chg_percent")[divGbn].innerHTML = "<strong class='sy'>" + resultArr[2] + "</strong>";
						}
						
						document.getElementById("bef_grad1"+divGbn).innerHTML = resultArr[0];
						document.getElementById("chg_percent1"+divGbn).innerHTML = "<strong>" + resultArr[2] + "%</strong>";
						
						if(document.getElementById("chg_term" + divGbn)) {
							document.getElementById("chg_term" + divGbn).innerHTML = strTerm;
						}
					} else {
						gudMsg  = "<p>고객님은 현재 <span id='bef_grad1" + divGbn + "'>7</span>등급으로, <span id='chg_term" + divGbn + "'></span><span id='aft_grad1" + divGbn + "'><strong>4등급</strong></span>으로 <span id='chg_grad" + divGbn + "'>3</span>등급 <span id='chg_txt" + divGbn + "'>상승</span>할 확률이 ";
						gudMsg += "<span id='chg_percent1" + divGbn + "'><strong>75%</strong></span>입니다.<br>고객님의 등급이 <span id='aft_grad2" + divGbn + "'>4</span>등급으로 바뀔 경우, ";
						gudMsg += "1억원의 대출을 받았을 경우 <span id='grad_amt1" + divGbn + "'><strong>5,534,100원</strong></span>의 연간 대출이자 <span id='amt_txt" + divGbn + "'>지출을 줄일 수 있습니다.</span><p>";
						gudMsg += "<p class='pt25'><span id='info_txt" + divGbn + "'>이로 인해 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성 하락이 예상됩니다.</span> 대출/카드와 등급의 관계를 확인하시려면, <a href='javascript:goPage(\"chk\")'><strong>대출/카드 진단</strong><img src='/sys/img/am/am57/layer/btn_goDiagnosis.gif' alt='바로가기'></a>을 이용해 보세요.</p>";
						
						if((divGbn != "M1" || divGbn != "M2") && (divGbn == "0" || divGbn == "1")) {
							strTerm = "3개월 이후에 ";
						} else {
							strTerm = "1년 내에 ";
						}
	
						document.getElementById("gudMsg_" + divGbn).innerHTML = gudMsg;
						if(divGbn == "M1" || divGbn == "M2") {
							// 예상 결과 테이블 셋팅
							document.getElementById("bef_grad" + divGbn).innerHTML = "<strong class='b'>" + resultArr[0] + "</strong>";
							document.getElementById("aft_grad" + divGbn).innerHTML = "<strong class='y'>" + resultArr[1] + "</strong>";
							document.getElementById("img_grad" + divGbn).src = img;
							document.getElementById("chg_percent" + divGbn).innerHTML = "<strong class='sy'>" + resultArr[2] + "</strong>%";
							document.getElementById("grad_amt" + divGbn).innerHTML = "<strong>" + amt_symbol + grad_amt + "</strong>원";
						} else {
							// 예상 결과 테이블 셋팅
							document.getElementsByName("bef_grad")[divGbn].innerHTML = "<strong class='b'>" + resultArr[0] + "</strong>";
							document.getElementsByName("aft_grad")[divGbn].innerHTML = "<strong class='y'>" + resultArr[1] + "</strong>";
							document.getElementsByName("img_grad")[divGbn].src = img;
							document.getElementsByName("chg_percent")[divGbn].innerHTML = "<strong class='sy'>" + resultArr[2] + "</strong>";
						}
						
						// 예상 결과 안내 문구 셋팅
						document.getElementById("bef_grad1" + divGbn).innerHTML = resultArr[0];
						document.getElementById("aft_grad1" + divGbn).innerHTML = "<strong>" + resultArr[1] + "등급</strong>";
						document.getElementById("aft_grad2" + divGbn).innerHTML = resultArr[1];
						document.getElementById("chg_grad" + divGbn).innerHTML = chgGrad;
						document.getElementById("chg_txt" + divGbn).innerHTML = chg_txt;
						document.getElementById("chg_percent1" + divGbn).innerHTML = "<strong>" + resultArr[2] + "%</strong>";
						document.getElementById("grad_amt1" + divGbn).innerHTML = "<strong>" + grad_amt + "원</strong>";
						document.getElementById("amt_txt" + divGbn).innerHTML = amt_txt;
						document.getElementById("info_txt" + divGbn).innerHTML = info_txt;
	
						if(document.getElementById("chg_term" + divGbn)) {
							document.getElementById("chg_term" + divGbn).innerHTML = strTerm;
						}
					}
				}
			}
			
			// 페이지 이동
			function goPage(page_gbn) {
				if(page_gbn == "chk") {
					XecureNavigate("/CommonSvl?tc=kcb.acs.am.am80.cmd.AM8300_LoanInterestSummaryCmd&topsub=1&McNum=10&leftsub=12", "_blank");
				} else if(page_gbn == "ae0809") {
					window.open("/acs/ae/ae0809/AE0809_MoneyToDayEvent.jsp", "_blank")
				} else if(page_gbn == "csi") {
					window.open("/acs/ap/ap1/AP1900.jsp?MainNum=2&topsub=2&McNum=14", "_blank");
				}
			}
			
			// 다음 단계로
			function goNext(gbn) {
				var imgTrigger = choice_menu.getElementsByTagName("a");
				var next_gbn = -1;
			
				imgTrigger.item(i).imgEl = imgTrigger.item(i).getElementsByTagName("img").item(0);
				for(var i = gbn; i < imgTrigger.length; i++) {
					if(imgTrigger.item(i).imgEl.src.indexOf("_a.gif") > 0) {
						if (i == 7 && item7 != 0) {
							continue;
						} else if (i == 8 && item8 != 0) {
							continue;
						} else {
							next_gbn = i;
						}
					}
					
					if(next_gbn > gbn) {
						break;
					}
				}
				
				if(next_gbn > gbn) {
					//
				} else {
					for(var i = imgTrigger.length-1; i >= 0; i--) {
						
						if(imgTrigger.item(i).imgEl.src.indexOf("_a.gif") > 0) {
							if (i == 7 && item7 != 0) {
								continue;
							} else if (i == 8 && item8 != 0) {
								continue;
							} else {
								next_gbn = i;
							}
						}
					}
				}

				if (next_gbn < 0) {
					var imgTrigger2 = btmResultView1.getElementsByTagName("a");
					imgTrigger2.item(0).imgEl = imgTrigger2.item(0).getElementsByTagName("img").item(0);
					
					if(imgTrigger2.item(0).imgEl.src.indexOf("_a.gif") > 0) {
						alert("더이상 입력 가능한 항목이 없습니다.\n종합결과보기 버튼을 클릭하여 신용등급이 어떻게 바뀌는지 예측해 보세요.");
					} else {
						alert("더이상 입력 가능한 항목이 없습니다.\n추가로 항목을 선택해서 종합결과를 예측해 보세요.");
						item_choice_open();
					}
					next_gbn = gbn;
				}
				
				menu_choice(next_gbn);
			}
			
			// 자릿수 만큼 값 채우기
			function lpad(inputStr,fill,length) {
				var n = length - inputStr.length;
				var rtnStr ="";
				
				for (i =0; i < n; i++) rtnStr = rtnStr + fill;
				
				rtnStr = rtnStr + inputStr;
				
				return rtnStr;
			}
			
			// 자릿수 만큼 값 채우기
			function rpad(inputStr,fill,length) {
				var n = length - inputStr.length;
				var rtnStr ="";
				
				for (i =0; i < n; i++) rtnStr = rtnStr + fill;
				
				rtnStr = inputStr + rtnStr;
				
				return rtnStr;
			}
			
			// 금액 입력 체크
			function amtChk(input_Obj) {
				var dispName = input_Obj.getAttribute("dispName");
				var minValue = input_Obj.getAttribute("minValue");
				var maxValue = input_Obj.getAttribute("maxValue");
				var unitValue = input_Obj.getAttribute("unitValue");
				var inpValue = input_Obj.value;
			
				if (dispName == null) {
					dispName = "";
				}
				
				if (unitValue == null) {
					unitValue = "";
				}
				
				inpValue = deleteCommaStr(inpValue);

				if(inpValue.length >= 1 && !isFloat(inpValue)) {
					alert("숫자만 입력 가능합니다.");
					input_Obj.value = "";
					input_Obj.focus();
					return;
				}
				
				if(inpValue.length > 1 && inpValue.substr(0,1) == "0") {
					alert("첫번째 값이 0입니다. 입력 값을 확인해 주세요.");
					input_Obj.value = "";
					input_Obj.focus();
					return;
				}
				
				if (minValue != null) {
					if (eval(deleteCommaStr(minValue)) > inpValue) {
						alert(dispName + " 값이 최소값(" + addCommaStr(minValue) + unitValue + ") 미만입니다.");
						input_Obj.value = addCommaStr(minValue);
						input_Obj.focus();
						return;
					}
				}
			
				if (maxValue != null) {
					if (eval(deleteCommaStr(maxValue)) < inpValue) {
						alert(dispName + " 값이 최대값(" + addCommaStr(maxValue) + unitValue + ")을 초과합니다.");
						input_Obj.value = addCommaStr(maxValue);
						input_Obj.focus();
						return;
					}
				}
				
				if(inpValue.length > 1) {
					addComma(input_Obj);
				}
			}
			
			// 예상 테이블에 동적Row 추가
			function addRow(gbn) {
				var Obj = itemData[gbn];
				var result = false;
				
				if(run_simul_chk()) {
					to_bottom("choice_" + Obj);
					return;
				}
				
				// 최대 등록 갯수 확인
				if(eval("tblRow_" + Obj) > 2){
					alert("최대 3건 까지만 등록 가능합니다.");
					addClear(gbn);
					return;
				}
				
				if (gbn == "2" || gbn == "4") {
					result = addRow_new(gbn);
				} else if (gbn == "3") {
					result = addRow_loanrepay(gbn);
				} else if (gbn == "5") {
					result = addRow_overduerepay(gbn);
				}
				
				// 테이블 공통 순번 재생성, 입력항목 초기화, 레이어 스크롤 이동
				if(result == true) {
					reOrder("tbl_" + Obj);
					addClear(gbn);	
					to_bottom("choice_" + Obj);
				}
			}
					
			// 예상 테이블에 동적Row 삭제
			function removeRow(row, gbn, all_gbn) {
				var Obj = itemData[gbn];
				var result = false;
				
				if (gbn == "2" || gbn == "3" || gbn == "4") {
					if(gbn == "3" && all_gbn == "a") {
						result = removeRow_Type1(row, gbn, all_gbn);
					} else {
						result = removeRow_Type1(row, gbn);
					}
				} else if (gbn == "5") {
					if(all_gbn == "a") {
						result = removeRow_Type2(row, gbn, all_gbn);
					} else {
						result = removeRow_Type2(row, gbn);
					}
				}
				
				if(result == true) {
					reOrder("tbl_" + Obj);
				}
			}			
			
			// 테이블 Row 추가/삭제 시 순번 재 설정
			function reOrder(tbl) {
				var tbl = document.getElementById(tbl);
				var cntRow = tbl.rows.length;
				var j = 1;
			
				// 타이틀 Row는 제외
				for(var i=1; i<cntRow; i++) {
					if(tbl.rows[i].cells(0)){
						tbl.rows[i].cells(0).innerHTML = j;
						j++;
					}
				}
			}
			
			// 스크롤 최하단으로 이동
			function to_bottom(Obj) { 
				var objDiv = document.getElementById(Obj);
				objDiv.scrollTop = objDiv.scrollHeight;
			}
			// <<**************** 공통 관련 **************** //			


			// 콤마 삭제
			function deleteCommaStr(value) {
				return value.replace(/[,]/gi, "");
			}

			function optChgPercent(Obj_sel, mod) {

				var listObj = document.getElementById(mod+"list_loanrepay");
				if(listObj.selectedIndex == 0){
					alert("금융계좌를 먼저 선택해 주세요.");
//					listObj.focus();
//					Obj_sel.selectedIndex = 0;
					return;
				}

				var listVal = listObj[listObj.selectedIndex].value;
				if(listVal == 'all'){
					listObj.focus();
					return;
				}

				var listArr = listVal.split("|");
				if (Obj_sel[Obj_sel.selectedIndex].value == ''){
					document.getElementById(mod+"amt_loanrepay").value = "";
				} else {
					var calcVal = (listArr[5] * Obj_sel[Obj_sel.selectedIndex].value) / 100;
					document.getElementById(mod+"amt_loanrepay").value = addCommaStr(calcVal+"");
				}
			}
