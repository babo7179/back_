	// 입력 항목 구분
	var itemData = ["cardcash", "cardbalance", "newloan", "loanrepay", "newoverdue", "overduerepay", "overduemaintain", "creditinfo", "personinfo"];
	// Item별 결과 문구 목록
	var itemResultMesages = ["현금서비스 이용잔액 변경 시, 3개월 후", 
	    		            "신용카드 이용잔액이 변경 시, 3개월 후", 
	    		            "대출이 추가될 경우, 1년 이내에 변경될", 
	    		            "대출이 상환될 경우, 1년 이내에 변경될", 
	    		            "연체가 추가될 경우, 1년 이내에 변경될", 
	    		            "연체금액을 상환할 경우, 1년 이내에 변경될", 
	            			"현재 보유하고 있는 연체를 유지할 경우, 1년 이내에 변결될"];
	
    // 예상 결과 보기 파라미터 업무구분
    var ifJobGbn1 = ["N4", "N5", "N3", "P2", "N1", "P1", "N2"];
    var ifJobGbn2 = ["P3", "P4"];

	// **************** 예상결과 보기 관련 ****************>> //
	// 예상 결과 보기 - 이미지 변경, 비동기 데이터 송/수신
	function resultSimulator(type, gbn) {
		var Obj = itemData[gbn];
	
		var resultObj = "";
		if(type == "i") {
			resultObj = document.getElementById("input_" + Obj);
			var dispName = resultObj.getAttribute("dispName");
			if (dispName == null) {
				dispName = "";
			}
			
			if(resultObj.value.trim() == "") {
				alert(dispName + " 값을 입력해 주세요.");
				resultObj.focus();
				return;
			}
			
			if(gbn == "0") {
				if(totCshAmt == 0 && resultObj.value == 0) {
					alert("현금 서비스 이용 금액이 존재하지 않아 산출이 불가능 합니다.");
					return;
				} else if(totCshAmt == deleteCommaStr(resultObj.value)) {
					alert("입력 금액이 현재 현금 서비스 이용 금액과 동일합니다. 다시 입력해 주세요.");
					return;
				} else if (eval(deleteCommaStr(resultObj.value)) > 5000) {
					alert("현금 서비스 이용 잔액값이 최대값을 초과합니다.");
					resultObj.value = 5000;
					return;
				}
			}
			
			if(gbn == "1") {
				if(totCardAmt == 0 && resultObj.value == 0) {
					alert("카드 이용 잔액이 존재하지 않아 산출이 불가능 합니다.");
					return;
				} else if(totCardAmt == deleteCommaStr(resultObj.value)) {
					alert("입력 금액이 현재 카드 이용 잔액 금액과 동일합니다. 다시 입력해 주세요.");
					return;
				} else if (eval(deleteCommaStr(resultObj.value)) > 5000) {
					alert("카드 이용 잔액값이 최대값을 초과합니다.");
					resultObj.value = 5000;
					return;
				}
			}
			
			if(gbn == "6") {
				if(dlqCnt == 0) {
					alert("연체 보유 계좌가 존재하지 않아 산출이 불가능 합니다.");
					return;
				}					
			}
		} else if(type == "t") {
			resultObj = document.getElementById("tbl_" + Obj);
			var cntRow = $("#tbl_"+Obj).find("tr").length;
			if(cntRow < 1) {
				alert($("#tbl_"+Obj).attr("dispName") + "을(를) 추가해 주세요");
				return;
			}
		}
	
		
		var sendHeaderStr = resultStrMakeHeader("S",1);
		var sendBodyStr = resultStrMakeBody(type,gbn,"S");
		var sendStr = sendHeaderStr + sendBodyStr;

		goSubmit(sendStr, "rspFnS", gbn);
	}

	// 산출
	function goSubmit(strParam, fncNm, gbn, simul_gbn) {
		// 변수 설정
		var actForm = document.RESULT_SIM;
		actForm.REQ_MSG.value = strParam;
		actForm.FNC_NM.value = fncNm;
		actForm.DIV_GBN.value = gbn;
		
		if(strParam.substring(0,1) == "M") {
			var strArr = strParam.split("|");
			if(strArr.length == 1) {
				actForm.SIMUL_GBN.value = strParam.substring(16,17);
			} else {
				var cntN = 0;
				var cntP = 0;
				
				if(strParam.substring(16,17) == "N") {
					cntN++;
				} else if(strParam.substring(16,17) == "P") {
					cntP++;
				}
				
				for(var i=1; i<strArr.length; i++) {
					var strDelim = strArr[i];
					if(strDelim.substring(0,1) == "N") {
						cntN++;
					} else if(strDelim.substring(0,1) == "P") {
						cntP++;
					}
				}

				if(cntN > 0 && cntP > 0) {
					actForm.SIMUL_GBN.value = "M";
				} else if(cntN > 0 && cntP == 0) {
					actForm.SIMUL_GBN.value = "N";
				} else if(cntN == 0 && cntP > 0) {
					actForm.SIMUL_GBN.value = "P";
				}
			}
			
		} else if(strParam.substring(0,1) == "S") {
			actForm.SIMUL_GBN.value = strParam.substring(16,17);
		}

		// 조회
		//XecureSubmit(actForm);
		$.ajax({
			type:"POST",
			url:resultUrl,
			data:$("#RESULT_SIM").serialize(),
			contentType:"application/x-www-form-urlencoded;charset=UTF-8",
			dataType:"json",
			success:viewResultSimulator,
			error:function(data,status,err){
				alert(err);	
			}
		});

	}

	// 인터페이스 전송 문자 공통 부분
	function resultStrMakeHeader(make_type, cnt) {
		var headerString = "";
		
		// 공통 부분 만들기
		headerString += make_type; 				// 처리구분 (단변 : S, 다변 : M)
		headerString += custNo;			// CB 고객번호
		headerString += lpad(cnt+"", "0", 3);	// 입력정보건수 (단변이면 001, 다변이면 최대 004)
		
		return headerString;
	}
	
	// 인터페이스 전송 문자 - 업무 부분(개별 확인하기).. - 문서 참조..
	function resultStrMakeBody(obj_type, gbn, simul_gbn) {
		var Obj = itemData[gbn];
		
		var bodyString = "";
		var resultObj = "";
		
		// 개별 부분 만들기
		// 업무구분 - 항목 상관없이 동일한 위치
		if(gbn == "0" || gbn == "1") {
			var cardObj = document.getElementById("input_" + Obj);
			var currCardAmt = 0;
			
			if(gbn == "0") {
				currCardAmt = totCshAmt;
			} else if(gbn == "1") {
				currCardAmt = totCardAmt;
			}
			
			if(eval(deleteCommaStr(cardObj.value)) > currCardAmt) {
				bodyString += ifJobGbn1[gbn]	// 현금서비스/카드 일 경우 증가
			} else if(eval(deleteCommaStr(cardObj.value)) <= currCardAmt) {
				bodyString += ifJobGbn2[gbn]	// 현금서비스/카드 일 경우 감소
			}
		} else {
			bodyString += ifJobGbn1[gbn]		// 일반 업무구분 
		}
		
		// * 연체 유지는 종합 산출에서는 제외 된다.
		if(obj_type == "i") { // 현금서비스/카드이용
			resultObj = document.getElementById("input_" + Obj);
			
			if(gbn == "0" || gbn == "1") {
				var cardAmt = eval(deleteCommaStr(resultObj.value)) * 10000; // 현금서비스/카드는 금액 (원단위)
				bodyString += lpad(cardAmt+"", "0", 12);
			} else if(gbn == "6" && simul_gbn == "S") {
				bodyString += lpad(resultObj.value, "0", 3);
			}
		} else if(obj_type == "t") { // 신규대출/신규연체/대출상환/연체상환 
			resultObj = document.getElementById("tbl_" + Obj);
			var tblCnt = $("#tbl_"+Obj).find("tr").length + 1;
			
			if(gbn == "2" || gbn == "4") { //신규대출/신규연체
				bodyString += lpad((tblCnt - 1)+"", "0", 3); // 총 개수(최대 3건, 003)
				if(tblCnt > 1) {
					for(var i=1; i<tblCnt; i++) {
						bodyString += lpad(document.getElementsByName(Obj + "_jbTpCd")[i-1].value, "0", 2); // 업권
						bodyString += lpad(document.getElementsByName(Obj + "_txAgncCd")[i-1].value, "0", 6); // 기관코드
						bodyString += lpad((eval(document.getElementsByName(Obj + "_Amt")[i-1].value) * 10000)+"", "0", 12); // 대출/연체 금액
					}
				 }
			} else if(gbn == "3") { // 대출상환
				if(tblCnt > 1) {
					if (document.getElementsByName(Obj + "_gbn")[0].value == "all") {
						bodyString += "999"; // 총 개수(최대 3건, 999)
						// 전체 상환일 경우 반복부 무시
					} else {
						bodyString += lpad((tblCnt - 1)+"", "0", 3); // 총 개수(최대 3건, 003)						
						for(var i=1; i<tblCnt; i++) {
							var biz_gbn = document.getElementsByName(Obj + "_gbn")[i-1].value;
							bodyString += biz_gbn // 구분
							bodyString += lpad(document.getElementsByName(Obj + "_jbTpCd")[i-1].value, "0", 2); // 업권
							bodyString += rpad(document.getElementsByName(Obj + "_txAgncCd")[i-1].value, " ", 7); // 기관코드
							
							if(biz_gbn == "K") { // KCB
								bodyString += "000000000000000"; // 은행연합회 대출사유(2), 대출발생일자(8), KFB대출일련번호(5) 값 없음
								bodyString += lpad(document.getElementsByName(Obj + "_mgtAcctNo")[i-1].value, "0", 16); // 관리계좌번호
							} else if(biz_gbn == "F") { // KFB
								bodyString += lpad(document.getElementsByName(Obj + "_lnReason")[i-1].value, "0", 2); // 은행연합회 대출사유
								bodyString += lpad(document.getElementsByName(Obj + "_lnDt")[i-1].value, "0", 8); // 대출발생일자
								bodyString += lpad(document.getElementsByName(Obj + "_lnSeq")[i-1].value, "0", 5); // KFB대출일련번호
								bodyString += "0000000000000000"; // 관리계좌번호(16) 값 없음
							}
						
							bodyString += lpad((eval(document.getElementsByName(Obj + "_Amt")[i-1].value) * 10000)+"", "0", 12); // 금액
						}
					}
				}
			} else if(gbn == "5") { // 연체상환
				if(tblCnt > 1) {
					if (document.getElementsByName(Obj + "_gbn")[0].value == "all") {
						bodyString += "999"; // 총 개수(최대 3건, 999)
						// 전체 상환일 경우 반복부 무시
					} else {
						bodyString += lpad((tblCnt - 1)+"", "0", 3); // 총 개수(최대 3건, 003)
						for(var i=1; i<tblCnt; i++) {
							bodyString += document.getElementsByName(Obj + "_gbn")[i-1].value; // 구분
							bodyString += lpad(document.getElementsByName(Obj + "_jbTpCd")[i-1].value, "0", 2); // 업권
							bodyString += rpad(document.getElementsByName(Obj + "_txAgncCd")[i-1].value, " ", 7); // 기관코드
						}
					}
				 }
			}
		}
		
		bodyString += "|"						// 항목 구분자
		
		return bodyString;		
	}
	

	// 항목별 결과 셋팅
	viewResultSimulator = function(data) {
		
		var checkData = resultData = eval('data.result');
		if(checkData == null || checkData == 'undefined' || checkData.length == 0) {
			alert('일시적인 오류로 고객님의 신용평점 산출이 되지 않았습니다.\n다시 시도해 주세요.');
			return;
		}
		
		var resultData = eval('data.result.GRADE_RESULT');
		
		if (resultData.isSuccess == 'true') {

			var gbn = $("#DIV_GBN").val();

			var updownGbn = "";
			
			var befGrad    = resultData.BEF_GRAD;
			var resultGrad = resultData.RESULT_GRAD;
			var resultPrlt = resultData.RESULT_PRLT;
			var resultAmt  = resultData.RESULT_AMT;
			var chgGrad;
			
			var chg_txt;
			var chg_txt1;
			var amt_txt;
			var amt_symbol;
			var info_txt;
			var strTerm;
			
			if(eval(befGrad) == eval(resultGrad)) {
				updownGbn = "E";
				amt_symbol = "";
			} else if((eval(befGrad) - eval(resultGrad)) > 0) {
				updownGbn = "U";
				chgGrad = eval(befGrad) - eval(resultGrad);
				chg_txt = "상승";
				chg_txt1 = "개선될";
				amt_txt = "지출을 줄일 수 있습니다.";
				amt_symbol = "+";
				info_txt = "이로 인해 대출이자율 하락, 대출개설 가능성, 카드 발급 가능성 상승이 예상됩니다.";
			} else {
				updownGbn = "D";
				chgGrad = eval(resultGrad) - eval(befGrad);
				chg_txt = "하락";
				chg_txt1 = "하락할";
				amt_txt = "지출이 늘어날 수 있습니다.";
				amt_symbol = "-";
				info_txt = "이로 인해 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성 하락이 예상됩니다.";
			}
			
			// 이미지 처리 (상승/하락/유지)
			var statusImg = "";
			if(updownGbn == "E") {
				//img = "/sys/img/am/am57/layer/creditRateing_equal.gif";
				statusImg = "icon_simulate_equal.gif";
			} else if(updownGbn == "U") {
				statusImg = "icon_simulate_up.gif";
			} else {
				statusImg = "icon_simulate_down.gif";
			}
			
			if((gbn != "M1" || gbn != "M2") && (gbn == "0" || gbn == "1")) {
				strTerm = "3개월 이후에 ";
			} else {
				strTerm = "1년 내에 ";
			}
			
			var fncNm = $("#FNC_NM").val();
			
			var resultHtml;
			
			if (fncNm == "rspFnM1" || fncNm == "rspFnM2") {
				resultHtml="<h3 class=\"tit-type-13\"><img src=\""+imgUrl+"/08.report/tit_simulate_0116.gif\" alt=\"신용등급 종합분석 결과\" /></h3>\n";
			} else {
				resultHtml="<h3 class=\"tit-type-13\"><img src=\""+imgUrl+"/08.report/tit_simulate_0103.gif\" alt=\"예상결과\" /> "+itemResultMesages[gbn]+" <strong class=\"color-01\">"+custName+"</strong>님의 예상등급입니다.</h3>\n";
			}
			resultHtml+="\n";
			resultHtml+="<table cellpadding=\"0\" cellspacing=\"0\" class=\"report-table-type01\" summary=\"예상결과 상세\">\n";

			if (gradViewYN) {
				// 정식판
				resultHtml+="<colgroup><col width=\"24%\" /><col width=\"4%\" /><col width=\"24%\" /><col width=\"24%\" /><col width=\"24%\" /></colgroup>\n";
				resultHtml+=" \n";
				resultHtml+="<thead>\n";
				resultHtml+="	<tr class=\"center-07\">\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010301.gif\" alt=\"현재등급\" /> ("+startDt+")</th>\n";
				resultHtml+="		<th>&nbsp;</th>\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010302.gif\" alt=\"예상등급\" /> ("+endDt+")</th>\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010303.gif\" alt=\"예상결과\" /> </th>\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010304.gif\" alt=\"변경확률\" /> </th>\n";
				resultHtml+="	</tr>\n";
				resultHtml+="</thead>\n";
				resultHtml+="<tbody>\n";
				resultHtml+="	<tr class=\"brno-02\">\n";
				resultHtml+="		<td><strong>"+befGrad+"</strong> <img src=\""+imgUrl+"/08.report/txt_grade_02.gif\" alt=\"등급\" /></td>\n";
				resultHtml+="		<td><img src=\""+imgUrl+"/08.report/icon_arrow_change.gif\" alt=\"에서\" /></td>\n";
				resultHtml+="		<td><strong>"+resultGrad+"</strong> <img src=\""+imgUrl+"/08.report/txt_grade_02.gif\" alt=\"등급\" /></td>\n";
				resultHtml+="		<td><img src=\""+imgUrl+"/08.report/"+statusImg+"\" alt=\"하락\" /></td>\n";
				resultHtml+="		<td><strong>"+resultPrlt+"</strong> <img src=\""+imgUrl+"/08.report/txt_persent_01.gif\" alt=\"%\" /></td>\n";
				resultHtml+="	</tr>\n";
				if (fncNm == "rspFnM1" || fncNm == "rspFnM2") {
					resultHtml+="	<tr class=\"brno-03\">\n";
					resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010306.gif\" alt=\"예상 경제 효과\" /> </th>\n";
					resultHtml+="		<td colspan=\"4\"><strong>"+amt_symbol+addCommaStr(resultAmt)+"</strong> <img src=\""+imgUrl+"/08.report/txt_money_02.gif\" alt=\"원\" /></td>\n";
					resultHtml+="	</tr>\n";
				}
				resultHtml+="</tbody>\n";
				resultHtml+="</table>\n";
				if(updownGbn == "E") {
					resultHtml+="<p class=\"info-22\">고객님은 현재 "+befGrad+"등급으로, 입력하신 신용정보가 변경되어도 <strong class=\"color-01\">"+resultGrad+"등급</strong>을 유지할 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.<br />고객님의 등급에 변경이 없어 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성에는 영향이 없습니다.<br />대출/카드와 등급의 관계를 확인하시려면, <a href=\"/ADFCommonSvl?SCRN_ID=s08001967069\" target=\"_blank\"><strong>대출안심관리</strong></a> 또는 <a href=\"/ADFCommonSvl?SCRN_ID=s06033351704\" target=\"_blank\"><strong>카드안심관리</strong></a>를 이용해보세요.</p>\n";
				} else {
					resultHtml+="<p class=\"info-22\">고객님은 현재 "+befGrad+"등급으로, "+strTerm+" <strong class=\"color-01\">"+resultGrad+"등급</strong>으로 "+chgGrad+"등급 "+chg_txt1+" 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.<br />고객님의 등급이 "+resultGrad+"등급으로 바뀔 때, 1억원의 대출을 받았을 경우 <strong class=\"color-01\">"+addCommaStr(resultAmt)+"원</strong>의 연간 대출이자 "+amt_txt+"<br />이로 인해 대출이자율 상승, 대출개설 및 카드 발급 가능성 "+chg_txt+"이 예상됩니다.<br />대출/카드와 등급의 관계를 확인하시려면, <a href=\"/ADFCommonSvl?SCRN_ID=s08001967069\" target=\"_blank\"><strong>대출안심관리</strong></a> 또는 <a href=\"/ADFCommonSvl?SCRN_ID=s06033351704\" target=\"_blank\"><strong>카드안심관리</strong></a>를 이용해보세요.</p>\n";
				}
			} else {
				// 체험판
				resultHtml+="<colgroup><col width=\"70%\" /><col width=\"30%\" /></colgroup>\n";
				resultHtml+="\n";
				resultHtml+="<thead>\n";
				resultHtml+="	<tr class=\"center-07\">\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010303.gif\" alt=\"예상결과\" /></th>\n";
				resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010304.gif\" alt=\"변경확률\" /></th>\n";
				resultHtml+="	</tr>\n";
				resultHtml+="</thead>\n";
				resultHtml+="<tbody>\n";
				resultHtml+="	<tr class=\"brno-02\">\n";
				if(updownGbn == "E") {
					resultHtml+="		<td class=\"val\"><img src=\""+imgUrl+"/08.report/txt_simulate_010301.gif\" alt=\"현재등급에서\" /> &nbsp;&nbsp;<img src=\""+imgUrl+"/08.report/"+statusImg+"\" alt=\""+chg_txt+"\" /></td>\n";
				} else {
					resultHtml+="		<td class=\"val\"><img src=\""+imgUrl+"/08.report/txt_simulate_010301.gif\" alt=\"현재등급에서\" /> &nbsp;&nbsp;<strong>"+chgGrad+"</strong> <img src=\""+imgUrl+"/08.report/txt_grade_02.gif\" alt=\"등급\" />  &nbsp;&nbsp;<img src=\""+imgUrl+"/08.report/"+statusImg+"\" alt=\""+chg_txt+"\" /></td>\n";
				}
				resultHtml+="		<td><strong>"+resultPrlt+"</strong> <img src=\""+imgUrl+"/08.report/txt_persent_01.gif\" alt=\"%\" /></td>\n";
				resultHtml+="	</tr>\n";
				resultHtml+="</tbody>\n";
				resultHtml+="</table>\n";
				if(updownGbn == "E") {
					resultHtml+="<p class=\"info-22\"><strong class=\"color-01\">"+custName+"</strong>고객님은 입력하신 신용정보가 변경되어도 등급을 유지할 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.</p>\n";
				} else {
					resultHtml+="<p class=\"info-22\"><strong class=\"color-01\">"+custName+"</strong>고객님은 1등급 "+chg_txt1+" 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.<br />등급이 변경되면, 고객님이 만약 <strong class=\"color-01\">1</strong>억원의 대출을 받았을 경우 <strong class=\"color-01\">"+addCommaStr(resultAmt)+"원</strong>의 연간 대출이자 "+amt_txt+"</p>\n";
				}
				resultHtml+="\n";
				resultHtml+="<div class=\"simulate-box-type-02\">\n";
				resultHtml+="	<p class=\"txt\"><strong>"+custName+"</strong>고객님은 체험판 이용중이셔서 등급 변동폭과 확률만 제공됩니다.<br />몇 등급이 될 것인지 보다 정확한 등급정보를 확인하시겠습니까?</p>\n";
				resultHtml+="	<p class=\"btn\"><a href=\"#none\"><img src=\""+imgUrl+"/08.report/btn_confirm_02.gif\" alt=\"확인하러 가기\" /></a></p>\n";
				resultHtml+="</div>\n";
			}

			resultHtml+=" \n";
			if (fncNm == "rspFnM2") {
				resultHtml+="<h3 class=\"tit-type-02\"><img src=\""+imgUrl+"/08.report/tit_simulate_0117.gif\" alt=\"신용정보 변경조건\" /></h3>\n";

				// 0 : 현금서비스, 1: 신용카드, 2: 신규대출, 3: 대출상환, 4:신규연체 5:연체상환
				for(var idx=0; idx < 6; idx++) {

					var Obj = itemData[idx];

					if($("#complete_img_"+Obj).html().length > 1) {
						if(idx == 0 || idx == 1) {
							resultHtml+="<h4 class=\"tit-type-19\">"+$("#tot_amt_"+Obj).attr("dispName")+" 변경</h4>\n";
							resultHtml+="<div class=\"info-29\">현재 "+$("#tot_amt_"+Obj).attr("dispName")+" <strong>"+$("#tot_amt_"+Obj).val()+" 만원</strong>으로 변경합니다.</div>\n";
							resultHtml+="\n";
						} else {
							resultHtml+="<h4 class=\"tit-type-19\">"+$("#tot_"+Obj).attr("dispName")+" 변경</h4>\n";
							resultHtml+=generateSimTotHtml(idx);
							resultHtml+="\n";
						}
					}
				}
				resultHtml+="<p class=\"info-30\"><span>※</span>신용등급의 반영은 신용정보 변경조건을 실행하시더라도 경우에 따라 최대 3년까지 기간이 소요될 수 있습니다.</p>\n";
				resultHtml+="<p class=\"info-32\"><strong>현재의 변경조건을 목표로 신용등급관리를 시작해보세요. 꾸준한 신용관리는 신용등급 상승에 도움이 됩니다.</strong></p>\n";
				resultHtml+="<p class=\"button-center-01\"><a href=\"javascript:viewSimulaterBody('0');\"><img src=\""+imgUrl+"/08.report/btn_reprediction.gif\" alt=\"다시 예상하기\" /></a></p>\n";
			} else if (fncNm == "rspFnM1") {
				resultHtml+="<p class=\"button-center-01\"><a href=\"javascript:callAjax(resultSelectUrl);\"><img src=\""+imgUrl+"/08.report/tn_reselect.gif\" alt=\"다시 선택하기\" /></a> <a href=\"javascript:viewResultSimulatorDetail();\"><img src=\""+imgUrl+"/08.report/btn_detail_view_02.gif\" alt=\"자세히 보기\" /></a></p>\n";
			} else {
				resultHtml+="<p class=\"button-center-01\"><a href=\"javascript:retrySimul('"+gbn+"')\"><img src=\""+imgUrl+"/08.report/btn_condition_rewrite.gif\" alt=\"조건 다시 입력하기\" /></a> <a href=\"javascript:goSimulNext('"+gbn+"');\"><img src=\""+imgUrl+"/08.report/btn_next_step.gif\" alt=\"다음 단계로\" /></a></p>\n";
			}
			resultHtml+=" \n";

			// 종합예측 결과
			if (fncNm == "rspFnM2") {

				$("[id^='tab_layer']").hide();
				$("#result_total").html(resultHtml);
				
				// 시뮬레이터 입력 정보 초기화
				setSimulaterInit();

				// 시뮬레이터 종합 결과 페이지로 이동
				viewSimulaterBody('3');

			// 항목별 상세예측 > 종합예측결과
			} else if (fncNm == "rspFnM1") {
				resultSimData = resultData;	// 자세히 보기 위한 Data Set.
				
				$("[id^='tab_layer']").hide();
				$("[id^='result_simul_']").hide();
				$("#result_simul_tot").html(resultHtml).show();
				
				var topHtml;
				
				topHtml = "<h3 class=\"tit-type-16\"><img src=\""+imgUrl+"/08.report/tit_01030701.gif\" alt=\"신용등급 종합분석\" /></h3>\n";
				topHtml += "<p class=\"info-10\"><img src=\""+imgUrl+"/08.report/txt_01030701.gif\" alt=\"고객님께서 입력하신 모든 항목들을 조합해 예측한 결과입니다.\" /></p>\n";
				
				$("#simulateDivTop").html(topHtml);
				$("#result_tot_simulate").hide();
				
			// 항목별 상세예측 항목별 결과
			} else {
			
				if ($("#"+itemData[gbn]).find("img").length == 0 ){
					var completeImg = "<img src=\""+imgUrl+"/08.report/icon_write_end.gif\" id=\"complet_img_"+itemData[gbn]+"\" alt=\"입력완료\" />";
		
					$("#tab_layer"+gbn).hide();
					$("#result_simul_"+itemData[gbn]).html(resultHtml).show();
					
					$("#"+itemData[gbn]).append(completeImg);
					$("#simItem"+gbn).val("C");
				}
				
				viewTotSimulator();
			
			}

		} else {

			alert('일시적인 오류로 고객님의 신용평점 산출이 되지 않았습니다.\n다시 시도해 주세요.');
		}
		
	};

	generateSimTotHtml = function(idx) {
		var Obj = itemData[idx];
		var itemHtml = "";

		// 데이터 조회를 위한 비활성화 해제
		/*
		$("#tot_"+idx).find('input[type=text]').removeClass("readonly").removeAttr("disabled");
		
		$("#tot_"+idx).find('select').each(function() {
			$(this).next().remove();
			$(this).unbind('.sSelect').sSelect({listWidth : $(this).attr("listWidth")});
		});
		*/

		itemHtml+="<table cellpadding=\"0\" cellspacing=\"0\" class=\"report-table-type01\">\n";

		if (idx == 2) {
			// 신규 대출
			var businessObj = document.getElementById("tot_list_" + Obj);
			var instituteObj = document.getElementById("tot_txList_" + Obj);

			var jbTpNm = businessObj[businessObj.selectedIndex].text;
			var	txAgncNm = instituteObj[instituteObj.selectedIndex].text;
			var amtObj = document.getElementById("tot_amt_" + Obj);

			itemHtml+="<colgroup><col width=\"8%\" /><col width=\"30%\" /><col width=\"26%\" /><col width=\"20%\" /></colgroup>\n";
			itemHtml+="<thead>\n";
			itemHtml+="	<tr class=\"center-07\">\n";
			itemHtml+="		<th>순번</th>\n";
			itemHtml+="		<th>업권</th>\n";
			itemHtml+="		<th>기관명</th>\n";
			itemHtml+="		<th>대출금액</th>\n";
			itemHtml+="	</tr>\n";
			itemHtml+="</thead>\n";
			itemHtml+="<tbody>\n";
			itemHtml+= "<tr class=\"brno\">\n";
			itemHtml+= 	"<td>1</td>\n";
			itemHtml+= 	"<td>"+jbTpNm+"</td>\n";
			itemHtml+= 	"<td>"+txAgncNm+"</td>\n";
			itemHtml+= 	"<td class=\"right-01\">"+amtObj.value+"만원</td>\n";
			itemHtml+= "</tr>\n";
			itemHtml+="</tbody>\n";


		} else if (idx == 3) {
			// 대출 금액 상환
			var listObj = document.getElementById("tot_list_" + Obj);
			listVal = listObj[listObj.selectedIndex].value;

			itemHtml+="<colgroup><col width=\"8%\" /><col width=\"30%\" /><col width=\"26%\" /><col width=\"20%\" /></colgroup>\n";
			itemHtml+="<thead>\n";
			itemHtml+="	<tr class=\"center-07\">\n";
			itemHtml+="		<th>순번</th>\n";
			itemHtml+="		<th>기관명</th>\n";
			itemHtml+="		<th>대출종류</th>\n";
			itemHtml+="		<th>상환금액</th>\n";
			itemHtml+="	</tr>\n";
			itemHtml+="</thead>\n";
			itemHtml+="<tbody>\n";
			if(listVal == "all") {
				itemHtml+= "<tr class=\"brno\">\n";
				itemHtml+= 	"<td>1</td>\n";
				itemHtml+= 	"<td colspan=\"3\">전체 상환</td>\n";
				itemHtml+= "</tr>\n";			
			} else {
				var listArr = listVal.split("|");
				var listJbTpNm = listArr[2];
				var listTxAgncNm = listArr[4];
				var amtObj = document.getElementById("tot_amt_" + Obj);

				itemHtml+= "<tr class=\"brno\">\n";
				itemHtml+= 	"<td>1</td>\n";
				itemHtml+= 	"<td>"+listJbTpNm+"</td>\n";
				itemHtml+= 	"<td>"+listTxAgncNm+"</td>\n";
				itemHtml+= 	"<td class=\"right-01\">" + amtObj.value + "만원</td>\n";
				itemHtml+= "</tr>\n";			
			}
			itemHtml+="</tbody>\n";


		} else if (idx == 4) {
			// 신규 연체
			var businessObj = document.getElementById("tot_list_" + Obj);
			var instituteObj = document.getElementById("tot_txList_" + Obj);

			var jbTpNm = businessObj[businessObj.selectedIndex].text;
			var	txAgncNm = instituteObj[instituteObj.selectedIndex].text;
			var amtObj = document.getElementById("tot_amt_" + Obj);

			itemHtml+="<colgroup><col width=\"8%\" /><col width=\"30%\" /><col width=\"26%\" /><col width=\"20%\" /></colgroup>\n";
			itemHtml+="<thead>\n";
			itemHtml+="	<tr class=\"center-07\">\n";
			itemHtml+="		<th>순번</th>\n";
			itemHtml+="		<th>업권</th>\n";
			itemHtml+="		<th>기관명</th>\n";
			itemHtml+="		<th>연체금액</th>\n";
			itemHtml+="	</tr>\n";
			itemHtml+="</thead>\n";
			itemHtml+="<tbody>\n";
			itemHtml+= "<tr class=\"brno\">\n";
			itemHtml+= 	"<td>1</td>\n";
			itemHtml+= 	"<td>"+jbTpNm+"</td>\n";
			itemHtml+= 	"<td>"+txAgncNm+"</td>\n";
			itemHtml+= 	"<td class=\"right-01\">"+amtObj.value+"만원</td>\n";
			itemHtml+= "</tr>\n";
			itemHtml+="</tbody>\n";


		} else if (idx == 5) {
			// 연체상환
			var listObj = document.getElementById("tot_list_" + Obj);
			listVal = listObj[listObj.selectedIndex].value;

			itemHtml+="<colgroup><col width=\"8%\" /><col width=\"26%\" /><col width=\"21%\" /><col width=\"20%\" /><col width=\"15%\" /></colgroup>\n";
			itemHtml+="<thead>\n";
			itemHtml+="	<tr class=\"center-07\">\n";
			itemHtml+="		<th>순번</th>\n";
			itemHtml+="		<th>기관명</th>\n";
			itemHtml+="		<th>종류(수집기관)</th>\n";
			itemHtml+="		<th>기존 연체기간</th>\n";
			itemHtml+="		<th>연체금액</th>\n";
			itemHtml+="	</tr>\n";
			itemHtml+="</thead>\n";
			itemHtml+="<tbody>\n";
			if(listVal == "all") {
				itemHtml+= "<tr class=\"brno\">\n";
				itemHtml+= 	"<td>1</td>\n";
				itemHtml+= 	"<td colspan=\"4\">전체 상환</td>\n";
				itemHtml+= "</tr>\n";			
			} else {
				var listArr = listVal.split("|");
				var listJbTpNm = listArr[2];
				var listTxAgncNm = listArr[4];
				var listOverdueTerm = listArr[5];
				var listOverdueAmt = listArr[6];
				var listOverdueGbn = listArr[7];

				var listOverdueTerm2;
				if(listOverdueGbn == "F") {
					listOverdueTerm2 = listOverdueTerm;
				} else {
					listOverdueTerm2 = listOverdueTerm;
				}

				itemHtml+= "<tr class=\"brno\">\n";
				itemHtml+= 	"<td>1</td>\n";
				itemHtml+= 	"<td>"+listJbTpNm+"</td>\n";
				itemHtml+= 	"<td>"+listOverdueTerm2+"</td>\n";
				itemHtml+= 	"<td>"+listTxAgncNm+"</td>\n";
				itemHtml+= 	"<td class=\"right-01\">" + listOverdueAmt + "만원</td>\n";
				itemHtml+= "</tr>\n";			
			}
			itemHtml+="</tbody>\n";
		}
		itemHtml+="</table>\n";

		return itemHtml
	};

	// 항목별 결과 자세히보기
	viewResultSimulatorDetail = function() {

		var resultData = resultSimData;
		
		if (resultData.isSuccess == 'true') {

			var updownGbn = "";
			
			var befGrad    = resultData.BEF_GRAD;
			var resultGrad = resultData.RESULT_GRAD;
			var resultPrlt = resultData.RESULT_PRLT;
			var resultAmt  = resultData.RESULT_AMT;
			var chgGrad;
			
			var chg_txt;
			var chg_txt1;
			var amt_txt;
			var amt_symbol;
			var info_txt;
			var strTerm;
			
			if(eval(befGrad) == eval(resultGrad)) {
				updownGbn = "E";
				amt_symbol = "";
			} else if((eval(befGrad) - eval(resultGrad)) > 0) {
				updownGbn = "U";
				chgGrad = eval(befGrad) - eval(resultGrad);
				chg_txt = "상승";
				chg_txt1 = "개선될";
				amt_txt = "지출을 줄일 수 있습니다.";
				amt_symbol = "+";
				info_txt = "이로 인해 대출이자율 하락, 대출개설 가능성, 카드 발급 가능성 상승이 예상됩니다.";
			} else {
				updownGbn = "D";
				chgGrad = eval(resultGrad) - eval(befGrad);
				chg_txt = "하락";
				chg_txt1 = "하락할";
				amt_txt = "지출이 늘어날 수 있습니다.";
				amt_symbol = "-";
				info_txt = "이로 인해 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성 하락이 예상됩니다.";
			}
			
			// 이미지 처리 (상승/하락/유지)
			var statusImg = "";
			if(updownGbn == "E") {
				//img = "/sys/img/am/am57/layer/creditRateing_equal.gif";
				statusImg = "icon_simulate_equal.gif";
			} else if(updownGbn == "U") {
				statusImg = "icon_simulate_up.gif";
			} else {
				statusImg = "icon_simulate_down.gif";
			}
			
			strTerm = "1년 내에 ";
			
			var fncNm = $("#FNC_NM").val();
			
			var resultHtml;
			
			if (fncNm == "rspFnM1" || fncNm == "rspFnM2") {
				resultHtml="<h3 class=\"tit-type-13\"><img src=\""+imgUrl+"/08.report/tit_simulate_0116.gif\" alt=\"신용등급 종합분석 결과\" /></h3>\n";
			} else {
				resultHtml="<h3 class=\"tit-type-13\"><img src=\""+imgUrl+"/08.report/tit_simulate_0103.gif\" alt=\"예상결과\" /> "+itemResultMesages[gbn]+" <strong class=\"color-01\">고객</strong>님의 예상등급입니다.</h3>\n";
			}
			resultHtml+="\n";
			resultHtml+="<table cellpadding=\"0\" cellspacing=\"0\" class=\"report-table-type01\" summary=\"예상결과 상세\">\n";
			resultHtml+="<colgroup><col width=\"24%\" /><col width=\"4%\" /><col width=\"24%\" /><col width=\"24%\" /><col width=\"24%\" /></colgroup>\n";
			resultHtml+=" \n";
			resultHtml+="<thead>\n";
			resultHtml+="	<tr class=\"center-07\">\n";
			resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010301.gif\" alt=\"현재등급\" /> ("+startDt+")</th>\n";
			resultHtml+="		<th>&nbsp;</th>\n";
			resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010302.gif\" alt=\"예상등급\" /> ("+endDt+")</th>\n";
			resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010303.gif\" alt=\"예상결과\" /> </th>\n";
			resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010304.gif\" alt=\"변경확률\" /> </th>\n";
			resultHtml+="	</tr>\n";
			resultHtml+="</thead>\n";
			resultHtml+="<tbody>\n";
			resultHtml+="	<tr class=\"brno-02\">\n";
			resultHtml+="		<td><strong>"+befGrad+"</strong> <img src=\""+imgUrl+"/08.report/txt_grade_02.gif\" alt=\"등급\" /></td>\n";
			resultHtml+="		<td><img src=\""+imgUrl+"/08.report/icon_arrow_change.gif\" alt=\"에서\" /></td>\n";
			resultHtml+="		<td><strong>"+resultGrad+"</strong> <img src=\""+imgUrl+"/08.report/txt_grade_02.gif\" alt=\"등급\" /></td>\n";
			resultHtml+="		<td><img src=\""+imgUrl+"/08.report/"+statusImg+"\" alt=\"하락\" /></td>\n";
			resultHtml+="		<td><strong>"+resultPrlt+"</strong> <img src=\""+imgUrl+"/08.report/txt_persent_01.gif\" alt=\"%\" /></td>\n";
			resultHtml+="	</tr>\n";
			resultHtml+="	<tr class=\"brno-03\">\n";
			resultHtml+="		<th><img src=\""+imgUrl+"/08.report/tit_simulate_010306.gif\" alt=\"예상 경제 효과\" /> </th>\n";
			resultHtml+="		<td colspan=\"4\"><strong>"+amt_symbol+addCommaStr(resultAmt)+"</strong> <img src=\""+imgUrl+"/08.report/txt_money_02.gif\" alt=\"원\" /></td>\n";
			resultHtml+="	</tr>\n";
			resultHtml+="</tbody>\n";
			resultHtml+="</table>\n";
			if(updownGbn == "E") {
				resultHtml+="<p class=\"info-22\"><strong class=\"color-01\">"+custName+"</strong>고객님은 현재 "+befGrad+"등급으로, 입력하신 신용정보가 변경되어도 <strong class=\"color-01\">"+resultGrad+"등급</strong>을 유지할 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.<br />고객님의 등급에 변경이 없어 대출이자율 상승, 대출개설 가능성, 카드 발급 가능성에는 영향이 없습니다.<br />대출/카드와 등급의 관계를 확인하시려면, <a href=\"#none\"><strong>대출/카드 진단</strong></a>을 이용해보세요.</p>\n";
			} else {
				resultHtml+="<p class=\"info-22\"><strong class=\"color-01\">"+custName+"</strong>고객님은 현재 "+befGrad+"등급으로, "+strTerm+" <strong class=\"color-01\">"+resultGrad+"등급</strong>으로 "+chgGrad+"등급 "+chg_txt1+" 확률이 <strong class=\"color-01\">"+resultPrlt+"%</strong>입니다.<br />고객님의 등급이 "+resultGrad+"등급으로 바뀔 때, 1억원의 대출을 받았을 경우 <strong class=\"color-01\">"+addCommaStr(resultAmt)+"원</strong>의 연간 대출이자 "+amt_txt+"<br />이로 인해 대출이자율 상승, 대출개설 및 카드 발급 가능성 "+chg_txt+"이 예상됩니다.<br />대출/카드와 등급의 관계를 확인하시려면, <a href=\"#none\"><strong>대출/카드 진단</strong></a>을 이용해보세요.</p>\n";
			}
			resultHtml+=" \n";
			resultHtml+="<h3 class=\"tit-type-02\"><img src=\""+imgUrl+"/08.report/tit_simulate_0117.gif\" alt=\"신용정보 변경조건\" /></h3>\n";
			resultHtml+="<div id=\"simInputItems\"></div>\n";
			resultHtml+="<p class=\"info-30\"><span>※</span>신용등급의 반영은 신용정보 변경조건을 실행하시더라도 경우에 따라 최대 3년까지 기간이 소요될 수 있습니다.</p>\n";
			resultHtml+="<p class=\"info-32\"><strong>현재의 변경조건을 목표로 신용등급관리를 시작해보세요. 꾸준한 신용관리는 신용등급 상승에 도움이 됩니다.</strong></p>\n";

			resultHtml+="<p class=\"button-center-01\"><a href=\"javascript:viewSimulaterBody('0');\"><img src=\""+imgUrl+"/08.report/btn_reprediction.gif\" alt=\"다시 예상하기\" /></a></p>\n";
			resultHtml+=" \n";
			
			

			// 종합예측 결과
			$("[id^='tab_layer']").hide();
			$("#result_total").html(resultHtml);

			// 신용정보 변경조건 입력
			$("[name^='simItem']").each(function(idx) {
				if ($(this).val() == 'C'){
					var Obj = itemData[idx];
					var itemHtml = "";
					if (idx == 0 || idx == 1) {
						itemHtml+="<h4 class=\"tit-type-19\">"+$("#input_"+Obj).attr("dispName")+" 변경</h4>\n";
						itemHtml+="<div class=\"info-29\">현재 "+$("#input_"+Obj).attr("dispName")+" <strong>"+$("#input_"+Obj).val()+" 만원</strong>으로 변경합니다.</div>\n";
						itemHtml+="\n";

						$("#simInputItems").append(itemHtml);
					} else if (idx == 2 || idx == 3 || idx == 4 || idx == 5) {
						itemHtml+="<h4 class=\"tit-type-19\">"+$("#tbl_"+Obj).attr("dispName")+" 추가</h4>\n";
						itemHtml+="<table id=\"sim_input_"+Obj+"\" cellpadding=\"0\" cellspacing=\"0\" class=\"report-table-type01\" summary=\""+$("#tbl_"+Obj).attr("dispName")+" 추가 목록\">\n";
						itemHtml+="</table>\n";

						$("#simInputItems").append(itemHtml);
						$("#sim_input_"+Obj).append($("#table_"+Obj).html());

						$("#sim_input_"+Obj).find("[id=del_row_"+Obj+"]").remove();

					}
					
				}
			});

			// 시뮬레이터 입력 정보 초기화
			setSimulaterInit();

			// 시뮬레이터 종합 결과 페이지로 이동
			viewSimulaterBody('3');

		} else {

			alert('일시적인 오류로 고객님의 신용평점 산출이 되지 않았습니다.\n다시 시도해 주세요.');
		}
		
	};

	// 항목별 초기화
	retrySimul = function(gbn) {
		var Obj = itemData[gbn];

		// 단 항목 입력
		if (gbn == '0' || gbn == '1' || gbn == '6') {
			$("#input_"+Obj).val($("#input_"+Obj).attr("defaultValue"));

		// 멀티 항목 입력
		} else {
			$("#tab_layer"+gbn).find('input[type=text]').each(function() {
				$(this).val($(this).attr("defaultValue"));
			});
			
			$("#tab_layer"+gbn).find('select').each(function() {
				$(this).children("option[index=0]").attr("selected", true);
				$(this).resetSS();
			});

			$("#tbl_"+Obj).html("");
		}

		$("#simItem"+gbn).val("I");
		$("#complet_img_"+Obj).remove();

		$("#result_simul_"+Obj).html("").hide();
		$("#tab_layer"+gbn).show();

		viewTotSimulator();

	};

	// 다음항목 변경
	goSimulNext = function(gbn) {

		var firstGbn = '';
		var nextGbn = '';
		var dataComplete = 'Y';
		var dataCompleteCnt = 0;

		$("[name^='simItem']").each(function(idx) {

			if ($(this).val() == 'I'){
				
				if (firstGbn == ''){
					firstGbn = ''+idx;
				}

				if (nextGbn == '' && idx > gbn){
					nextGbn = ''+idx;
				}

				if (idx < 7) {
					dataComplete = 'N';
				}
				
			} else if ($(this).val() == 'C'){
				dataCompleteCnt++;
			}

		});

		if (dataComplete == 'Y' && nextGbn == '') {
			if(dataCompleteCnt > 2) {
				alert("더이상 입력 가능한 항목이 없습니다.\n종합결과보기 버튼을 클릭하여 신용등급이 어떻게 바뀌는지 예측해 보세요.");
			} else {
				alert("더이상 입력 가능한 항목이 없습니다.\n추가로 항목을 선택해서 종합결과를 예측해 보세요.");
			}
		} else {
			if (nextGbn == '') {
				nextGbn = firstGbn;
			}

			var Obj = itemData[nextGbn];

			$('#'+Obj).trigger('click');

		}

	};
