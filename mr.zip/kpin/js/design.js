$(function(){
	// input checkbox

	var cbcheck = function(obj){
		var obj = $(obj),
			lb = obj.find("label"),
			input = obj.find("input[type='checkbox']"),
			acb = obj.find("span.all input[type='checkbox']"),
			alink = obj.find("span.all .checkbox"),
			flag = null,
			s;


		input.prop("checked", false);
		$(".mvnoAgree").css("display","none");
		lb.each(function(){
			$(this).click(function(i){
				var cbpar = $(this).closest(".use_sel"),
					chbg = $(this).find(".checkbox"),
					ipt = $(this).parent().find("input[type='checkbox']"),
					itemsp = cbpar.find(".left").filter(":not('.all')"), //��� ���Ǹ� ������ ���� (��������)
					itemcn = itemsp.find(".checkbox:visible"), //��� ���Ǹ� ������ bg (�˶�������)
					itemip = itemsp.find("input[type='checkbox']:visible"); // ��� ���Ǹ� ������ checkbox(�˶�������)

				cbaction(chbg, ipt); // Ŭ���� bg on_off

				if ($(this).parent("span").hasClass("all")){
					s = "all"	 //��� ����
				}else if($(this).hasClass("mvnolb")){
					s = "mvno"	//�˶���
				}else{
					s = "normal" //���
				}

				switch(s){
					case "all" :
						if(acb.prop("checked")){
							acb.prop("checked", true);
							alink.addClass("on");
							itemip.prop("checked", true);
							itemcn.addClass("on");
						}else{
							acb.prop("checked", false);
							alink.removeClass("on");
							itemip.prop("checked", false);
							itemcn.removeClass("on");
						}

						break;
					case "mvno" :
							if(ipt.prop("checked")){
								$(".mvnoAgree").css("display","block");
							}else{
								$(".mvnoAgree").css("display","none");
								if ($(".mvnoAgree").find("input").prop("checked")){
									$(".mvnoAgree").find("input").prop("checked", false);
									$(".mvnoAgree").find(".checkbox").removeClass("on");
								}
							}
						break;
						break;
					case "normal":
						if (itemsp.find("input:checked").length == itemip.length){
							//��ε��� ���¿��� üũ������ ��ε��� üũ����
							if(!acb.prop("checked")){
								acb.prop("checked", true);
								alink.addClass("on");
							}
						} else if (itemsp.find("input:checked").length < itemip.length ){
							if(acb.prop("checked")){
								acb.prop("checked", false);
								alink.removeClass("on");
							}
						}
						break;
				}
				return false;
			});
		});

		function cbaction(ch,ip){
			if (!ch.hasClass("on")){
				ch.addClass("on");
				ip.trigger("click");
			}else{
				ch.removeClass("on");
				ip.removeAttr("checked");
			}
		}
	};
	cbcheck(".use_sel");

	// 20141211 ���� S
	$(".use_sel .btn").click(function(){
		var txt = $(this).parent().parent().find(".full_text"),
			tabLink = txt.find(".cnt").prev().height();
		$(".contents.issue").height($(document).height());
		txt.css("display","block");
		$('.tabMenu ul > li.wrap').removeClass('on').find(".cnt").css("display","none");;
		txt.find(".tabMenu > ul > li:first-child").addClass("on").find(".cnt").css("display","block");
		txt.find(".tabMenu").height(txt.find(".tabMenu .cnt:visible").height() + tabLink);
		$("#header a.close.hide").fadeIn( function () {
			if($(this).prev(".toggle")){ $("a.toggle").hide(); };
		});
		txt.show().animate({
			left : "0"
		},300);
	});
	
	$("#header a.close.hide").click(function(){
		$(this).fadeOut( function () {
			if($(this).prev(".toggle")){ $("a.toggle").show(); };
		});
		$(".full_text:visible").animate({
			left : "100%"
		},{
			duration : 300,
			complete : function(){
			$(this).hide();
			}
		});
		$(".contents.issue").css("height","auto");
	});
	// 20141211 ���� E
	
	// 20141209 �߰�
	// tabMenu
	/*$('.tabMenu').height($('.tabMenu .cnt:visible').height() + 35);*/
	$('.tabMenu ul > li.wrap a').bind('click focusin',function(){
		$('.tabMenu ul > li.wrap').removeClass('on').find(".cnt").css("display","none");;
		$(this).parent().addClass('on').find(".cnt").css("display","block");;
		$('.tabMenu').height($(this).next('.cnt').height() + 35);
	});

	/** select_box **/
	if($(".selectbox").length > 0){
		$(".selectbox").selectbox().bind('change', function(){
			$('<div>Value of .selectbox changed to: '+$(this).val()+'</div>').appendTo('#demo-default-usage .demoTarget').fadeOut(5000, function(){
				$(this).remove();
			});
		});
	};
	
	/* notice */
	$(".notice li").click(function(){
		if($(this).find(".txt_notice").length > 0){
			var txt = $(this).find(".txt_notice");
			$(".notice li, .notice li dt").removeClass("on");
			$(".txt_notice").slideUp();
			if(txt.is(":visible")){
				$(this).removeClass("on");
				$(this).find("dt").removeClass("on");
				txt.slideUp();
			}else{
				$(this).addClass("on");
				$(this).find("dt").addClass("on");
				txt.slideDown();
			};
		};
	});
});