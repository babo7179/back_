/*
* rwdImageMaps jQuery plugin v1.5
*
* Allows image maps to be used in a responsive design by recalculating the area coordinates to match the actual image size on load and window.resize
*
* Copyright (c) 2013 Matt Stow
* https://github.com/stowball/jQuery-rwdImageMaps
* http://mattstow.com
* Licensed under the MIT license
*/
;(function(a){a.fn.rwdImageMaps=function(){var c=this;var b=function(){c.each(function(){if(typeof(a(this).attr("usemap"))=="undefined"){return}var e=this,d=a(e);a("<img />").load(function(){var g="width",m="height",n=d.attr(g),j=d.attr(m);if(!n||!j){var o=new Image();o.src=d.attr("src");if(!n){n=o.width}if(!j){j=o.height}}var f=d.width()/100,k=d.height()/100,i=d.attr("usemap").replace("#",""),l="coords";a('map[name="'+i+'"]').find("area").each(function(){var r=a(this);if(!r.data(l)){r.data(l,r.attr(l))}var q=r.data(l).split(","),p=new Array(q.length);for(var h=0;h<p.length;++h){if(h%2===0){p[h]=parseInt(((q[h]/n)*100)*f)}else{p[h]=parseInt(((q[h]/j)*100)*k)}}r.attr(l,p.toString())})}).attr("src",d.attr("src"))})};a(window).resize(b).trigger("resize");return this}})(jQuery);


//����ȭ function : e

$(document).ready(function() {
	
	 $('input').iCheck({
		checkboxClass: 'icheckbox',
		radioClass: 'iradio',
		increaseArea: '20%' // optional
	 });
	 // iCheck guide
	 //$('#input-1, #input-3').iCheck('check'); checked
	 //$('#input-1, #input-3').iCheck('uncheck'); remove checked
	 //$('#input-2, #input-4').iCheck('disable'); disabled
	 //$('#input-2, #input-4').iCheck('enable'); remove disabled

	$('img[usemap]').rwdImageMaps(); //Responsive Image map
	
	// 20141209 �߰�
	// tabMenu
	$('.tabMenu').height($('.tabMenu .on .cnt').height() + 35);
	$('.tabMenu .wrap a').bind('click focusin',function(){
		$('.tabMenu .wrap').removeClass('on');
		$(this).parent().addClass('on');
		$('.tabMenu').height($(this).next('.cnt').height() + 35);
	});
	
	
});


$.fn.setFaq = function() {
	return this.each(function(i, elm) {
		$elm = $(elm);
		$elm.find("dd").hide().end().on("click", "dt > a", function() {
			
			$elm.find("dd").hide();
			
			var dt = $(this).parent("dt");
			
			if(dt.hasClass("on")){
				dt.removeClass("on");
				dt.next("dd").slideUp(200);
			}else{
				$elm.find("dt").removeClass("on");
				dt.toggleClass("on");
				dt.next("dd").slideToggle(200);
			};
			
			return false;
		});
	});
};

//////////////////// load�� ���� ////////////////////

window.onload = function() {
	setTimeout(function() { if(window.pageYOffset == 0){ window.scrollTo(0, 1);} }, 100);

	// iOS
	if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i)) || (navigator.userAgent.match(/iPad/i))) {
		$("body").addClass("ios");
	}

	//Android
	if((navigator.userAgent.match(/Android/i))){
		$("body").addClass("android");
		
		// GalexyS2
		if( (navigator.userAgent.indexOf("SHW-M250")) != -1 ){
			$("body").addClass("galexyS2");
		}
	}
}

