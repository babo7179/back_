	/* *************************************************************
	 * Ahnlab Online Security ����
	 * *************************************************************/
	// ��ġ ���� üũ - Aos
	isInstalledAos = function() {
//		$.getScript("http://ahnlabdownload.nefficient.co.kr/aos/plugin/aosmgr_common.js", function(){
//			aos_set_authinfo("aosmgr_allcredit.html");
//			alert(aos_is_new());
//			return aos_is_new();
//		});
		
		var result    = false;
		result = isActiveXChk("aosmgr.aosmgrCtrl.1", "application/ahnlab/asp/npaosmgr.1");
		alert(result);
		return result;		
	};
	
	// ��� ���� üũ - Aos
	isUseChkAos = function() {
//		$.getScript("http://ahnlabdownload.nefficient.co.kr/aos/plugin/aosmgr_common.js", function(){
//			aos_set_authinfo("aosmgr_allcredit.html");
//			alert(aos_loaded());
//			return aos_loaded();
//		});	
		
		var result = false;
		var aosmgr = document.getElementById("AOSMGR");
		if ($.browser.msie) {
			try {
				if( aosmgr.object ) {
					result = true;
				}
			} catch( e ) { }
			result = false;  
		} else {
			try {
				if( typeof(aosmgr.IsRunning) != 'undefined') {
					try {
						if( aosmgr.IsInited() == false ) {
							result = false;
						}
					} catch( e2 ) { }
					
					result = true;    
				}
			}
			catch( e ) { }
			
			result = false;
		}
		alert(result);
		return result;
	};
	
	// ��ġ �� ���� - Aos
	isStartAos = function() {
		if(!isInstalledAos()) {
			if(document.URL.indexOf("securePop.jsp") > 0) {
				$.getScript("http://ahnlabdownload.nefficient.co.kr/aos/plugin/aosmgr_common.js", function(){
					aos_set_authinfo("aosmgr_allcredit.html");
			
					aos_set_option("asyncmode", true);
					aos_set_option("uimode", false);
			
					// ��ġ
					aos_write_object();
			
					aos_start('e5');
					return true;
				});
			} else {
				window.open("/sandbox/jhBaek/securePop.jsp");
			}
		} else {
			alert("�̹� ��ġ�Ǿ� �ֽ��ϴ�.");
			return true;
		}
	};
	/* *************************************************************
	 * Ahnlab Online Security ����
	 * *************************************************************/
	
	/* *************************************************************
	 * XecureWeb ����
	 * *************************************************************/
	// XecureWeb mimeTypes üũ�� -------->
	var XWBrowserCtrl = {
		mName				: "XecureWeb",
		mType				: null,
		mTypeWin32			: "application/xecureweb-plugin",
		mTypeLinux			: "application/xecure-plugin"
	}

	/* Netscape 4 */
	var XWNetscapeCtrl4 = {
		mName				: "XecureWeb",
		mType				: "application/x-SoftForum-XecSSL40"
	}
	//<--------- XecureWeb mimeTypes üũ��
	
	// XecureWeb Browser üũ�� -------->
	var mBrowserCtrl;
	getBrowserCtrl = function () {
		var mUserAgent = navigator.userAgent;
		var mPlatform  = navigator.platform;
		var cWIN32	   = "Win32";
		var cWIN64	   = "Win64";		
		var mType;
		
		if ($.browser.msie)	{				// Explorer
		} else if (mUserAgent.indexOf ("Mozilla/4") != -1)	{	// Netscape 4
			mBrowserCtrl = XWNetscapeCtrl4;
		} else {
			mBrowserCtrl = XWBrowserCtrl;
		}
		
		if ($.browser.msie)
			return "";
		
		if (mPlatform == cWIN32) {
			mType = mBrowserCtrl.mTypeWin32
		} else if (mPlatform == cWIN64) {
			mType = mBrowserCtrl.mTypeWin64
		} else {
			mType = mBrowserCtrl.mTypeLinux
		}
		
		return mType;
	}
	// <-------- XecureWeb Browser üũ�� 
	
	// ��ġ ���� üũ - XecureWeb
	isInstalledXecure = function() {
		var result    = false;
		var mType = getBrowserCtrl();

		result = isActiveXChk("Xwctl40.XecCtl40", mType)
	
		return result;
	};
	
	// ��� ���� üũ - XecureWeb
	isUseChkXecure = function() {
		var result = false;
		if(document.XecureWeb != null && typeof(document.XecureWeb) != "undefined") {
			result = true;
		}
		alert(result);
		return result;
	};
	
	// ��ġ �� ���� - XecureWeb
	isStartXecure = function() {
		if(isInstalledXecure()) {
			PrintObjectTag();
			SetConvertTable();
			PutCACert();
			$("head").append("<form name='xecure'><input type='hidden' name='p'></form>");		
		}
	};
//����ó���� ���� �����ؼ� ������
function PrintObjectTag2 ()
{
	var aBrowser	= gXWBrowser.mBrowser;
	var aPlatForm	= gXWBrowser.mPlatform;
	var aVersion	= null;
	var aObjectTag	= null;
	var aResult		= false;

	if (aBrowser == gXWBrowser.cMSIE)
	{
		aResult = true;
	}
	else if (aBrowser == gXWBrowser.cFIREFOX)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWFirefoxCtrl.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWFirefoxCtrl.mLinuxVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cMAC) != -1)
			aVersion = XWFirefoxCtrl.mMacVersion;
	}
	else if (aBrowser == gXWBrowser.cFIREFOX36)
	{
		gXWBrowser.mBrowserCtrl = XWFirefox36Ctrl;
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWFirefox36Ctrl.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWFirefox36Ctrl.mLinuxVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cMAC) != -1)
			aVersion = XWFirefox36Ctrl.mMacVersion;
	}

	else if (aBrowser == gXWBrowser.cCHROME)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWChromeCtrl.mWinVersion;
	}

	else if (aBrowser == gXWBrowser.cSAFARI)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWSafariCtrl.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWSafariCtrl.mLinuxVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cMAC) != -1)
			aVersion = XWSafariCtrl.mMacVersion;
	}
	else if (aBrowser == gXWBrowser.cOPERA)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWOperaCtrl.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWOperaCtrl.mLinuxVersion;
	}

	else if (aBrowser == gXWBrowser.cNETSCAPE)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWNetscapeCtrl.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWNetscapeCtrl.mLinuxVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cMAC) != -1)
			aVersion = XWNetscapeCtrl.mMacVersion;
	}

	else if (aBrowser == gXWBrowser.cNETSCAPE4)
	{
		if (aPlatForm.indexOf (gXWBrowser.cWIN) != -1)
			aVersion = XWNetscapeCtrl4.mWinVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1)
			aVersion = XWNetscapeCtrl4.mLinuxVersion;
		else if (aPlatForm.indexOf (gXWBrowser.cMAC) != -1)
			aVersion = XWNetscapeCtrl4.mMacVersion;
	}

	else
	{
		aVersion = null;
	}

	if (aResult == false && aVersion == null)
	{
		alert ("XecureWeb�� �� ������ " + aBrowser + "�� �������� �ʽ��ϴ�.");
		return false;
	}

    
	if (gXWBrowser.checkCtrl (aVersion))
	{

		if(  (aPlatForm.indexOf (gXWBrowser.cWIN) != -1) ) { // MS Win

			// Google Chrome
			if(  aBrowser == gXWBrowser.cCHROME ) {
				document.location.href="/XecureObject_multi/installpage/wk_install_cr.html";
			}
			// Safari
			else if(  aBrowser == gXWBrowser.cSAFARI ) {
				document.location.href="/XecureObject_multi/installpage/wk_install_sf.html";
			}
			// Opera
			else if(  aBrowser == gXWBrowser.cOPERA ) {
				document.location.href="/XecureObject_multi/installpage/wk_install_op.html";
			}
			// Firefox
			else  
				document.location.href="/XecureObject_multi/installpage/wk_install_ff.html";

		} else if(  (aPlatForm.indexOf (gXWBrowser.cLINUX) != -1) ) {
			// Linux FF ��ġ
			document.location.href="/XecureObject_multi/installpage/wk_install_linux_ff.html";
		}  else if(  (aPlatForm.indexOf (gXWBrowser.cMAC) != -1) ) {
			// MAC Safari ��ġ
			if (this.mPlatform == this.cMACINTEL)
					document.location.href="/XecureObject_multi/installpage/wk_install_mac_sf_intel.html";
				else
					document.location.href="/XecureObject_multi/installpage/wk_install_mac_sf_ppc.html";
		}else {
			alert ("�� ������ [" + aBrowser + "] �� ���� �������� �ʽ��ϴ�.");
		}
//		gXWBrowser.installCtrl();
		aResult = false;
	}
	else
	{
		aResult = true;
		
	}
	
	if (aResult)
	{
		aObjectTag = gXWBrowser.getObjectTag(0);
		if (aBrowser != gXWBrowser.cFIREFOX36 || gXWBrowser.mPlatform.indexOf("Linux") == -1)
		{
			//document.write (aObjectTag);
			$("head").append(aObjectTag);
		}
		else // Firefox 3.6
		{
			/********************************************************************
			 * Routine for Accessing to XPCOM component by XPCONNECT
			 ********************************************************************/
			netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
			var cid = "@softforum.com/xecurewebclient/service;1";
			var ccInterface = Components.interfaces.nsIXWClientComponent;
			ccObj = Components.classes[cid].getService().QueryInterface(ccInterface);
			document.XecureWeb = XWClientComponent;
		}
		
	}

	if (document.XecureWeb == undefined)
	{
		document.XecureWeb = document.getElementById ("XecureWeb");
	}
	
	
	if( aBrowser == gXWBrowser.cMSIE ) {
		if(!(document.XecureWeb == null || typeof(document.XecureWeb) == "undefined" || document.XecureWeb.object == null)) {
			SetConvertTable();	
		} else {
			// MS IE ��ġ
			document.location.href = "/XecureObject_multi/installpage/wk_install_ie.html";
		}
	}
		
	PutUBIKey();		
}
	isStartXecure2 = function() {
		if(!isInstalledXecure()) {
			alert("���� ����� ��ġ�մϴ�. ��ø� ��ٷ� �ּ���.");
			PrintObjectTag2();			
			SetConvertTable();
			PutCACert();
		} else {			
			return true;
		}
	};
	/* *************************************************************
	 * XecureWeb ����
	 * *************************************************************/
	
	/* *************************************************************
	 * Ű���� ���� ����
	 * *************************************************************/
	// ��ġ ���� üũ - Softcamp Secukey
	isInstalledScsk = function() {
		var result    = false;
		result = isActiveXChk("SCSK3.SCSK3Ctrl.1", "application/npscskxul");
		alert(result);
		return result;
	};
	
	// ��� ���� üũ - Softcamp Secukey
	isUseChkScsk = function() {
		var result = false;
		if (document.secukey == undefined) {
			document.secukey = document.getElementById ("secukey");
		}
		if(document.secukey != null && typeof(document.secukey) != "undefined") {
			result = true;
		}
		alert(result);
		return result;
	};
	
	// ��ġ �� ���� - Softcamp Secukey
	isStartScsk = function() {
		if(!isInstalledScsk()) {
			if(document.URL.indexOf("securePop.jsp") > 0) {
				$.getScript("http://dallcredit.kcb4u.com:10080/sys/js/secukey/secukey_multi.js", function(){
					SCSKInsert();
					return true;
				});
			} else {
				window.open("/sandbox/jhBaek/securePop.jsp");
			}
		} else {
			alert("�̹� ��ġ�Ǿ� �ֽ��ϴ�.");
			return true;
		}
	};
	/* *************************************************************
	 * Ű���� ���� ����
	 * *************************************************************/
	
	//ActiveX üũ
	isActiveXChk = function(Obj, mType) {
		var chkMime;
		var result = false;
		
		if ($.browser.msie) {
			try {
				var xObj = new ActiveXObject(Obj);
				if(xObj) {
					result = true;
				}
			} catch(e) {}
		} else {
			if (navigator.mimeTypes && navigator.mimeTypes.length) {
				chkMime = navigator.mimeTypes [mType];
				if (chkMime && chkMime.enabledPlugin) {
					result = true;
				}
			}
		}

		return result;
	};