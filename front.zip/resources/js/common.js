;(function($){$.browserTest=function(a,z){var u='unknown',x='X',m=function(r,h){for(var i=0;i<h.length;i=i+1){r=r.replace(h[i][0],h[i][1]);}return r;},c=function(i,a,b,c){var r={name:m((a.exec(i)||[u,u])[1],b)};r[r.name]=true;r.version=(c.exec(i)||[x,x,x,x])[3];if(r.name.match(/safari/)&&r.version>400){r.version='2.0';}if(r.name==='presto'){r.version=($.browser.version>9.27)?'futhark':'linear_b';}r.versionNumber=parseFloat(r.version,10)||0;r.versionX=(r.version!==x)?(r.version+'').substr(0,1):x;r.className=r.name+r.versionX;return r;};a=(a.match(/Opera|Navigator|Minefield|KHTML|Chrome/)?m(a,[[/(Firefox|MSIE|KHTML,\slike\sGecko|Konqueror)/,''],['Chrome Safari','Chrome'],['KHTML','Konqueror'],['Minefield','Firefox'],['Navigator','Netscape']]):a).toLowerCase();$.browser=$.extend((!z)?$.browser:{},c(a,/(camino|chrome|firefox|netscape|konqueror|lynx|msie|opera|safari)/,[],/(camino|chrome|firefox|netscape|netscape6|opera|version|konqueror|lynx|msie|safari)(\/|\s)([a-z0-9\.\+]*?)(\;|dev|rel|\s|$)/));$.layout=c(a,/(gecko|konqueror|msie|opera|webkit)/,[['konqueror','khtml'],['msie','trident'],['opera','presto']],/(applewebkit|rv|konqueror|msie)(\:|\/|\s)([a-z0-9\.]*?)(\;|\)|\s)/);$.os={name:(/(win|mac|linux|sunos|solaris|iphone)/.exec(navigator.platform.toLowerCase())||[u])[0].replace('sunos','solaris')};if(!z){$('html').addClass([$.os.name,$.browser.name,$.browser.className,$.layout.name,$.layout.className].join(' '));}};$.browserTest(navigator.userAgent);})(jQuery);//http://jquery.thewikies.com/browser/
;(function($){$.fn.bgIframe=$.fn.bgiframe=function(s){if($.browser.msie&&/6.0/.test(navigator.userAgent)){s=$.extend({top:'auto',left:'auto',width:'auto',height:'auto',opacity:true,src:'javascript:false;'},s||{});var prop=function(n){return n&&n.constructor==Number?n+'px':n;},html='<iframe class="bgiframe"frameborder="0"tabindex="-1"src="'+s.src+'"'+'style="display:block;position:absolute;z-index:-1;'+(s.opacity!==false?'filter:Alpha(Opacity=\'0\');':'')+'top:'+(s.top=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+\'px\')':prop(s.top))+';'+'left:'+(s.left=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+\'px\')':prop(s.left))+';'+'width:'+(s.width=='auto'?'expression(this.parentNode.offsetWidth+\'px\')':prop(s.width))+';'+'height:'+(s.height=='auto'?'expression(this.parentNode.offsetHeight+\'px\')':prop(s.height))+';'+'"/>';return this.each(function(){if($('> iframe.bgiframe',this).length==0)this.insertBefore(document.createElement(html),this.firstChild);});}return this;};})(jQuery);
;(function(c){var a=["DOMMouseScroll","mousewheel"];c.event.special.mousewheel={setup:function(){if(this.addEventListener){for(var d=a.length;d;){this.addEventListener(a[--d],b,false)}}else{this.onmousewheel=b}},teardown:function(){if(this.removeEventListener){for(var d=a.length;d;){this.removeEventListener(a[--d],b,false)}}else{this.onmousewheel=null}}};c.fn.extend({mousewheel:function(d){return d?this.bind("mousewheel",d):this.trigger("mousewheel")},unmousewheel:function(d){return this.unbind("mousewheel",d)}});function b(f){var d=[].slice.call(arguments,1),g=0,e=true;f=c.event.fix(f||window.event);f.type="mousewheel";if(f.wheelDelta){g=f.wheelDelta/120}if(f.detail){g=-f.detail/3}d.unshift(f,g);return c.event.handle.apply(this,d)}})(jQuery);
;(function($) {
 
	/***********************************************
	* 온로드 실행 함수
	************************************************/
	$(function() {

		/* body addClass */
		if($.browser.name == 'msie'){
			$('body').addClass($.browser.className);
		} else {
			$('body').addClass($.browser.name);
		}

		/* ajax용 링크 이벤트 설정 */
		$('a.call-ajax').live('click', function(ev) {
			ev.preventDefault();
			$.ajax({
				beforeSend : function() {},
				url : $(this).attr('href'),
				success : function(data) {
					data = unescape(data);
					$('body').append(dataProcessing(data));
				}
			});
		});

		/* ajax용 링크 이벤트 설정(iframe) */
		$('a.call-ajax2').live('click', function(ev) {
			ev.preventDefault();
			$.ajax({
				beforeSend : function() {},
				url : $(this).attr('href'),
				success : function(data) {
					data = unescape(data);
					$('body',parent.document).append(dataProcessing(data));
				}
			});
		});
		
		/* ajax용 링크 이벤트 설정 - hover 20121102 추가 */
		$('a.call-ajax3').live('mouseover', function(ev) {
			ev.preventDefault();
			$.ajax({
				beforeSend : function() {},
				url : $(this).attr('href'),
				success : function(data) {
					data = unescape(data);
					$('body').append(dataProcessing(data));
				}
			});
		});

		$("img").each(function(){
			if($(this).attr("title")=="") $(this).attr("title", $(this).attr("alt"));
		});

		$(window).bind("scroll",function(){
			$(".aside-content").css({"top" : 80- $(window).scrollTop()+"px"});
		});

		/* lnb navigation */
		var $navTimer;
		var $lnbNavWrap = $("#lnbNav");
		var $lnbNav = $lnbNavWrap.find(">li");
		var $lnbNavEl = $lnbNav.find("a");
		var $lnbNavList = $(".lnb-list");
		var $lnbNavListArea = $(".lnb-total-section");
		navLnb();

		function navLnb(){
			$lnbNavEl.hover(function(){
				clearTimeout($navTimer);
				$lnbNavEl.removeClass("on");
				$lnbNavList.hide();
				$lnbNavListArea.fadeIn();
				$(this).addClass("on");
				$lnbNavList.eq($lnbNav.index($(this).parent())).slideDown();
				//20120926 추가 S
				if($(this).hasClass('active')){
					$lnbNavListArea.css('z-index','20')
				}
				else{
					$lnbNavListArea.css('z-index','40');
				}
				//20120926 추가 E				
			},function(){
				//$navTimer = setTimeout(navLnbReset,1000);
			});

			$lnbNavList.hover(function(){
				clearTimeout($navTimer);
			},function(){
				$navTimer = setTimeout(navLnbReset,200);
			});

			$lnbNavList.find("a").hover(function(){
				$(this).find("img").attr("src", function(){return $(this).attr("src").replace("_off","_on")});
			},function(){
				$(this).find("img").attr("src", function(){return $(this).attr("src").replace("_on","_off")});
			});

			$lnbNavWrap.hover(function(){
				
			},function(){
				$navTimer = setTimeout(navLnbReset,50);
			});
		}

		function navLnbReset(){
			$lnbNavEl.removeClass("on");
			$lnbNavListArea.hide();
			$lnbNavList.hide();
		}

		/* snb navigation */
		$(".snb").navMenu({deps : 3});

		/* snb banner navigation */
		$(".side-banner").moveContents({
			conEl:">li",
			iconFlag : false,
			effect:"fade",
			autoPlay:true,
			changeTimer:3000,
			aniTimer : 1000
		});

		/* report view */
		$('a.btn-report').bind('click', function(ev) {
			if($("#openDialogReport").is(":animated")){
				return false;
			}else{
				if($(this).hasClass("btn-report-on")){
					reportClose();
					return false;
				}else{
					ev.preventDefault();
					$.ajax({
						beforeSend : function() {},
						url : $(this).attr('href'),
						success : function(data) {
							data = unescape(data);
							$('body').append(dataProcessing(data));
							$('a.btn-report').addClass("btn-report-on");
						}
					});
				}
			}
		});

		/* header search */
		$(".search-form .text").bind("focus",function(){
			$(".search-form").addClass("search-form-on");
		});
		$(".search-form .text").bind("blur",function(){
			if($(this).val()) $(".search-form").addClass("search-form-on");
			else $(".search-form").removeClass("search-form-on");
		});

		/* form 공통 */
		formInputText();

		if($.browser.className=="msie7"){
			$("input.text:not(.input-txt)").bind("focus",function(){
				$(this).addClass("focus");
			});

			$("input.text:not(.input-txt)").bind("blur",function(){
				$(this).removeClass("focus");
			});
		}

		/* css 관련 */
		tableBorderRight("tbl-type03-list");

		$(".goods-info .list-info:not(.list-info-big, .list-info-small)").each(function(){
			$(this).find(">li:odd").addClass("last");
		});

		/* iframe resize */
		function resizeIframe(){
			$("#boardFrame").css("height",function(){return $(this).contents().find("#wrap").height()+10});
			
			resizeIframeChk();
			
		};

		var iframeResizeTimer = null;
		function resizeIframeChk(){
			if(iframeResizeTimer) clearTimeout(iframeResizeTimer);
			
			iframeResizeTimer = setTimeout(resizeIframe, 100);
		}

		try{
			if($("iframe", parent.document).length>0){
				/*수정 외부호스트일경우 분기*/
				if($("iframe", parent.document).prop('src').indexOf('kcb.signra.com') < 0 
				   && $("iframe", parent.document).prop('src').indexOf('www.r114.com') < 0
				   && $("iframe", parent.document).attr('id') != "jobKoreaBoardFrame"	//20130829 junhj 하우머니잡코리아제휴에서 iframe 호출될 경우는 resize하지 않기
				   ){
				    var ClientIframe = -1
				    resizeIframe();
				}
				
				//var ClientIframe = $("iframe", parent.document).prop('src').indexOf('kcb.signra.com');//특정  도메인인  경우 resize 하지 않기
				//if (ClientIframe == -1)
				//{
				//	resizeIframe();
				//}
				
			}
		}catch(e){
		}
		
	});

	/***********************************************
	* default tab
	************************************************/
	$.fn.defaultTab = function(options) {
		return this.each(function() {
			options = options || {};
			var $cont = $(this);
			var parentSelecter = $cont.attr('class');
			var opts = $.extend({}, $.fn.defaultTab.defaults, options || {});
			var $eventEls = $(opts.eventEls, $cont);
			var $eventChildren = $(opts.eventChildren, $cont)
			var $ajaxTarget = $('div #' + opts.ajaxTarget);
			tabActive($eventEls.eq(opts.defaultIndex), $eventEls);

			$eventEls.bind('click focus', function(ev) {
				tabActive($(this), $eventEls);
				if ($eventChildren.size()) {
					var target = $(this).attr('href');
					if ($(target).find('a:first')[0]) {
						target = $(target).find('a:first');
						tabActive(target, $eventChildren);
					} else {
						tabActive(false, $eventChildren);
					}
				}
				ev.preventDefault();
			});

			$eventEls.hover(
				function() {
					$(this).parent().addClass(opts.hoverClass);
				},
				function() {
					$(this).parent().removeClass(opts.hoverClass);
				}
			);

			if ($eventChildren) {
				$eventChildren.bind('focus', function(ev) {
					$parents = $(this).parents();
					$parents =  $parents.filter(function() {return $(this).attr('id')});
					$target = $('a[href*=' + $parents.eq(0).attr('id') + ']');
					tabActive($target, $eventEls);
					ev.preventDefault();
				});
			}

			function tabActive(obj, eventEls) {
				var self = obj;
				var current = $(eventEls).index($(self)[0]);
				if(!self) current = -1;
				$(eventEls).each(function(n) {
					var href = $(this).attr('href');
					// URL 을 표준 링크로 만든다
					if (!$.support.herfNormalized) {
						var loc = window.location;
						href = href.replace(loc.protocol + '//' + loc.host + loc.pathname, '');
					}

					if(current == n) {
						$(this).parent().addClass(opts.tabOnClass);
						$(this).find('img').attr('src', function() {return this.src.replace(opts.offimg, opts.onimg);});
						$cont.find(href).removeClass(opts.hiddenClass);

						if(href.indexOf('html') != -1) {
							var target = href.replace(/.+\.html/,'');
							if(target) href = href.split('#')[0];

							$ajaxTarget.load(href , function() {
								if(opts.clickCallback) opts.clickCallback($cont);
							});

							$.ajax({
								beforeSend : function() {},
								url : href,
								success : function(data) {
									var html = dataProcessing(data);
									$ajaxTarget.html(html);
								},
								complete : function() {
									if(opts.clickCallback) opts.clickCallback($cont);
								}
							});
						}
					} else {
						$(this).parent().removeClass(opts.tabOnClass);
						$(this).find('img').attr('src', function() {return this.src.replace(opts.onimg, opts.offimg);});
						$cont.find(href).addClass(opts.hiddenClass);
						if(opts.clickCallback) opts.clickCallback($cont);
					}
				});
			}
		});
	};

	$.fn.defaultTab.defaults = {
		ajaxTarget : 'AjaxContentWrap',
		eventEls : 'a',
		eventChildren : false,
		tabOnClass : 'on',
		hoverClass : 'hover',
		onimg : '_on.gif',
		offimg : '_off.gif',
		hiddenClass : 'display-none',
		defaultIndex : 0,
		clickCallback : false	//testTabFunction
	}

	/***********************************************
	* Modal
	************************************************/
	$.fn.modal = function(options) {
		return this.each(function(n) {
			options = options || {};
			var $cont = $(this);
			var opts = $.extend({}, $.fn.modal.defaults, options || {});
			var $overlay;
			if (opts.modal) {
				$overlay = $('<div>');
				$overlay.addClass(opts.modal_class);
				$('body').append($overlay);
			}

			setSize();

			function setSize() {
				var browser_width = $(window).width();
				var browser_height = $(window).height();
				var cont_width = $cont.outerWidth();
				var cont_height = $cont.outerHeight();
				var margin_top = Math.floor(cont_height /2) * (-1) + 'px';
				var margin_left = Math.floor(cont_width /2) * (-1) + 'px';
				var modal_width = Math.floor(browser_width) + 'px';
				var modal_height = Math.floor(browser_height) + 'px';
				var top = $(window).scrollTop() + (browser_height /2);
				var left = '50%';

				if (opts.view_port) {

					if (browser_height < opts.view_height) {
						margin_top = 0;
						top = (opts.view_height /2) - (Math.floor(cont_height /2));
						modal_height = opts.view_height;
					}

					if (browser_width < opts.view_width) {
						margin_left = 0;
						left = (opts.view_width /2) - (Math.floor(cont_width /2));
						modal_width = opts.view_width;
					}
				}

				/*20121102 추가 S : 추가 팝업레이어 왼쪽 고정위치에 정렬*/
				if(opts.fix_left) margin_left = Math.floor(cont_width /2) * (-1) -(opts.fix_left/2) + 'px';
				/*//20121102 추가 E*/
				if(opts.position_top) top = opts.position_top, margin_top = 0;
				if(opts.position_left) left = opts.position_left, margin_left = 0;

				$cont.css({'position' : 'absolute', 'z-index' : opts.z_index,'top' : top, 'left' : left, 'margin-top' : margin_top, 'margin-left' : margin_left});
				if (opts.modal) $overlay.css({'width' : modal_width, 'height' : modal_height, 'z-index' : opts.z_index - 1});
			};

			$(window).bind('resize', function() {
				if (opts.view_port) {
					setSize();
				}
			});

			//$(opts.close_trigger, $cont).focus();

			if (opts.draggable) {
				$('.draggable-handle', $cont).click(function() {
					var temp = 0;
					$('div.dialog-type01').each(function(n) {
						if ($cont.attr('id') == $(this).attr('id')) return;
						if (Number($cont.css('z-index')) <= Number($(this).css('z-index'))) {
							temp = Number($(this).css('z-index')) + 1;
							$cont.css('z-index', temp);
						};

					});
				});
				$cont.draggable({
					handle: '.draggable-handle',
					containment: '#container', scroll: false
				});
			} else {
				$('.draggable-handle', $cont).css('display', 'none');
			}

			$(opts.close_trigger, $cont).live('click', function() {
				modalRemove();
			});

			function modalRemove() {
				$cont.remove();
				if (opts.modal) $overlay.remove();
				if (opts.beforeclose) opts.beforeclose();
				if (opts.comeBackId && $("#"+opts.comeBackId)!=null ) $("#"+opts.comeBackId).focus();	// 2014-09-29 jhoon add for comeBackId
			}
			
			// 초점 이동 반복을 위한 처리
			if($cont.find('a.focus-repeater').length < 1){
				$cont.append('<a href="#' + $cont.attr('id') + '" class="focus-repeater" title="go top div"> </a>');
			}
			
			$cont.find('a.focus-repeater').focusin(function(){
				$cont.attr('tabindex', 0).focus();
			});
			
			$cont.attr('tabindex',0).focus();
			

		});
	};

	$.fn.modal.defaults = {
		beforeclose : false,
		close_trigger : '.btn-close',
		draggable : false,
		modal : false,
		modal_class : 'modal-overlay',
		position_left : false,
		position_top : false,
		view_port : true,
		view_width : 980,
		view_height : false,
		z_index : 9999,
		fix_left : false/*20121102 추가 : 추가 팝업레이어 왼쪽 고정위치에 정렬 옵션 추가*/
	}

})(jQuery);

function callAjax(linkvalue){
	$.ajax({
		beforeSend : function() {},
		url : linkvalue,
		success : function(data) {
			data = unescape(data);
			$('body').append(dataProcessing(data));
		}
	});
}

/***********************************************
* dataProcessing
************************************************/
function dataProcessing(data) {
	data = data.replace(/<script.*>.*<\/script>/ig,""); // Remove script tags
	data = data.replace(/<\/?meta.*>/ig,""); //Remove link tags
	data = data.replace(/<\/?link.*>/ig,""); //Remove link tags
	data = data.replace(/<\/?html.*>/ig,""); //Remove html tag
	data = data.replace(/<\/?body.*>/ig,""); //Remove body tag
	data = data.replace(/<\/?head.*>/ig,""); //Remove head tag
	data = data.replace(/<\/?!doctype.*>/ig,""); //Remove doctype
	data = data.replace(/<title.*>.*<\/title>/ig,""); // Remove title tags
	return data;
}

/***********************************************
* dialogAlert
************************************************/
function dialogAlert(msg, callback, obj) {
	var self = obj;
	var msg = msg;
	var href = $(self).attr('href');
	var callbackfunc = callback;
	var html = [], h = -1;
	html[++h] = '<div class="dialog-type01 dialog-type01-alert" id="openDialogAlert">';
	html[++h] = '<div id="popHeader" class="dialog-header">';
	html[++h] = '<h1>알림 메세지</h1>';
	html[++h] = '</div>';
	html[++h] = '<div id="popContainer" class="dialog-content">';
	html[++h] = '<p>';
	html[++h] = msg;
	html[++h] = '</p>';
	html[++h] = '</div>';
	html[++h] = '<div class="dialog-footer" id="popFooter">';
	if (callbackfunc) {
		html[++h] = '<a href="#none" onclick="'+callback+'"><img src="../../resources/img/00.common/btn_type01_confirm.gif" alt="확인" title=""/></a> ';
		html[++h] = '<a href="#none" class="btn-close"><img src="../../resources/img/00.common/btn_type01_cancel02.gif" alt="취소" title=""/></a>';
	}else{
		html[++h] = '<a href="#none" class="btn-close"><img src="../../resources/img/00.common/btn_type01_confirm.gif" alt="확인" title=""/></a>';
	}
	html[++h] = '</div>';
	html[++h] = '</div>';

	jQuery('body',parent.document).append(html.join(''));
	//extensionBox('.dialog-alert');
	parent.jQuery('div.dialog-type01-alert').modal({
		modal : true,
		z_index : 10001
	});
}

function dialogAlertTest(){
	alert("확인버튼 클릭시 호출되는 함수가 실행됩니다.");
	$("#openDialogAlert").remove();
	$(".modal-overlay").remove();
}

/***********************************************
* dialog Style
************************************************/
function extensionBox(selecter) {
	cont = jQuery(selecter);
	jQuery(cont).addClass('extension-box');
	jQuery(cont)
		.append('<div class="resizable-s">')
			.children('div.resizable-s')
			.width(function() {return jQuery(this).width() - 30})
			.css('margin-left', '30px')
		.end()
		.append('<div class="resizable-w">')
			.children('div.resizable-w').height(function() {return jQuery(cont).height() - 30})
		.end()
		.append('<div class="resizable-ws">');
}

/***********************************************
* 암시적 레이블 명시적으로 적용
************************************************/
function explicitLabel(cssName, margin) {
	$('.'+cssName+" label").each(function(){
		$(this).css('padding-left', function() {return $(this).next().outerWidth(true)});
		$("#"+$(this).attr("for")).css({
			'margin-left' : function() {
				return -$(this).prev().outerWidth(true)
			},
			'margin-right' : function() {
				if (margin) {
					return $(this).prev().width() + margin;
				} else {
					return $(this).prev().width()+15;
				}
			}
		});
	});
}

/***********************************************
* 테이블 우측보더 삭제
************************************************/
function tableBorderRight(cssName) {
	var els = $('table[class*='+cssName+']');
	var index;
	var row_count;
	$(els).find('tr').children(':last-child').each(function(n) {
		if($(this).attr('rowspan') > 1) {
			row_count = $(this).attr('rowspan') + n;
			index = n;
		};
		if((n > index) && (n < row_count)) return;
		$(this).css('border-right', 'none');
	});
}

/***********************************************
* moveContents
************************************************/
(function($) {

	$.fn.moveContents = function(options){
		return this.each(function(){
			var opts = $.extend({}, $.fn.moveContents.defaults, options || {});
			options = options || {};
			var $cont = $(this);																			//이동컨텐츠 전체 element
			var $contEventEl = opts.iconFlag? $cont.find(opts.eventEl) : null;		//클릭이벤트 element
			var $contEventCon = $cont.find(opts.conEl);										//실제 변경컨텐츠 element
			var $contConCnt = $contEventCon.length;											//변경컨텐츠갯수
			var $contSelIndex = opts.defaultIndex;												//현재선택된 컨텐츠의 index값
			var $contTimer;																				//오토플레이 시간변수
			var $btnPrev = $cont.find(opts.btnPrev);											//이전버튼
			var $btnNext = $cont.find(opts.btnNext);											//다음버튼
			var $btnPlay = $cont.find(opts.btnPlay);											//사용자컨트롤 플레이버튼
			var $btnStop = $cont.find(opts.btnStop);											//사용자컨트롤 정지버튼
			var $moveMode = true;																		//오토플레이 slide시 자동변경 방향
			var $playMode = true;																		//사용자 컨트롤러에 의한 애니메이션 상태
			var $oldSelIndex;																				//선택된 컨텐츠 이전 선택 index값
			var $iconMode;																				//아이콘클릭이벤트일때만 true

			if(opts.slideValue){
				var $slideValue = opts.slideValue;
			}
			else{
				if(opts.slideFor=="left" || opts.slideFor=="right") var $slideValue = $contEventCon.eq(0).outerWidth();
				else var $slideValue = $contEventCon.eq(0).outerHeight();
			}

			if(opts.addContain) $cont.addClass(opts.addContain);

			/*********************************************************
			//컨텐츠갯수가 복수일때 이벤트 설정(하나일때는 아이콘 버튼 미출력)
			**********************************************************/
			if($contConCnt>1){

				/* 디스플레이 초기화 - effect : slide */
				if(opts.effect=="slide"){
					$contEventCon.each(function(){
						var new_position = newPosition($(this));
						switch(opts.slideFor)
						{
							case "right":
							$(this).css({"right":new_position});
							break;

							case "top":
							$(this).css({"top":new_position});
							break;

							case "bottom":
							$(this).css({"bottom":new_position});
							break;

							default:
							$(this).css({"left":new_position});
							break;
						}

						if($contEventEl) $contEventEl.eq($contSelIndex).addClass(opts.onClass);
					});

				/* 디스플레이 초기화 - effect : circle  */
				}else if(opts.effect=="circle"){
					$contEventCon.eq(0).addClass("on");
					var viewSize = opts.circleSide;
					var $sideDeps = Math.floor(($contConCnt+2)/3);

					$cont.css("width",$contEventCon.eq(0).outerWidth()+(($contConCnt-1)*viewSize));

					//출력사이즈 정보
					var $circle_info = new Array();

					if(opts.slideFor=="vertical"){
						$circle_info[0] = new Array();
						$circle_info[0]["width"] = $contEventCon.eq(0).width();
						$circle_info[0]["height"] = $contEventCon.eq(0).height();
						$circle_info[0]["top"] = opts.circleSide*$sideDeps;
						$circle_info[0]["left"] = 0;
						$circle_info[0]["z-index"] = $contEventCon.eq(0).css("z-index");

						for(i=1;i<=$sideDeps;i++){
							$circle_info[i] = new Array();
							$circle_info[i]["width"] = $circle_info[i-1]["width"]*opts.circleRatio;
							$circle_info[i]["height"] = $circle_info[i-1]["height"]*opts.circleRatio;
							$circle_info[i]["left"] = ($circle_info[0]["width"]-$circle_info[i]["width"])/2;
							$circle_info[i]["top_prev"] = $circle_info[0]["top"]-viewSize*i;
							$circle_info[i]["top_next"] = $circle_info[0]["top"]+$circle_info[0]["height"]-($circle_info[i]["height"]-viewSize*i);

							//깊이별 컨텐츠 가로사이즈 = 상위deps 가로사이즈 * 축소비율
							//깊이별 컨텐츠 세로사이즈 = 상위deps 세로사이즈 * 축소비율
							//깊이별 컨텐츠 Top 좌표 = (최상위컨텐츠 높이값 - 자기자신 높이값) /2
							//깊이별 좌측 컨텐츠 Left 좌표  = 상위컨텐츠 좌측좌표값 - (좌측 보여지는 영역 가로사이즈 * deps)
							//깊이별 우측 컨텐츠 Left 좌표  = 최상위컨텐츠 좌측좌표값 + 최상위컨텐츠 가로사이즈 - (자기자신 전체가로사이즈 - 우측 보여지는 영역 가로사이즈)
						}
					}else{
						$circle_info[0] = new Array();
						$circle_info[0]["width"] = $contEventCon.eq(0).width();
						$circle_info[0]["height"] = $contEventCon.eq(0).height();
						$circle_info[0]["left"] = opts.circleSide*$sideDeps;
						$circle_info[0]["top"] = 0;
						$circle_info[0]["z-index"] = $contEventCon.eq(0).css("z-index");

						for(i=1;i<=$sideDeps;i++){
							$circle_info[i] = new Array();
							$circle_info[i]["width"] = $circle_info[i-1]["width"]*opts.circleRatio;
							$circle_info[i]["height"] = $circle_info[i-1]["height"]*opts.circleRatio;
							$circle_info[i]["top"] = ($circle_info[0]["height"]-$circle_info[i]["height"])/2;
							$circle_info[i]["left_prev"] = $circle_info[0]["left"]-viewSize*i;
							$circle_info[i]["left_next"] = $circle_info[0]["left"]+$circle_info[0]["width"]-($circle_info[i]["width"]-viewSize*i);

							//깊이별 컨텐츠 가로사이즈 = 상위deps 가로사이즈 * 축소비율
							//깊이별 컨텐츠 세로사이즈 = 상위deps 세로사이즈 * 축소비율
							//깊이별 컨텐츠 Top 좌표 = (최상위컨텐츠 높이값 - 자기자신 높이값) /2
							//깊이별 좌측 컨텐츠 Left 좌표  = 상위컨텐츠 좌측좌표값 - (좌측 보여지는 영역 가로사이즈 * deps)
							//깊이별 우측 컨텐츠 Left 좌표  = 최상위컨텐츠 좌측좌표값 + 최상위컨텐츠 가로사이즈 - (자기자신 전체가로사이즈 - 우측 보여지는 영역 가로사이즈)
						}
					}
					moveAni_circle();

					$contEventCon.bind("click",function(){
						$contSelIndex = $contEventCon.index($(this));
						moveAni_circle();
					});

				/* 디스플레이 초기화 - effect : accordion */
				}else if(opts.effect=="accordion"){
					var $accordionMax = opts.accordionMax?opts.accordionMax:$contEventCon.eq(0).outerWidth();
					$cont.css("width",($contConCnt-1)*opts.accordionMin+$accordionMax);
					$contEventCon.bind(opts.conEvent,function(){
						$contSelIndex = $contEventCon.index($(this));
						moveAni_accordion();
					});

					if(opts.autoPlay && opts.conEvent=="mouseover"){
						$contEventCon.hover(function(){
							clearTimeout($contTimer);
						},function(){
							$contTimer = setTimeout(moveIndexPlus,opts.changeTimer);
						});
					}
					moveAni_accordion();

				/* 디스플레이 초기화 - effect : show , fade */
				}else{
					$cont.each(function(){
						$contEventCon.hide();
						$contEventCon.eq($contSelIndex).show();
						if($contEventEl) $contEventEl.eq($contSelIndex).addClass(opts.onClass);
					});
				}

				/* 아이콘버튼 디스플레이 */
				if(opts.iconFlag) displayIcon();

				/* 이동버튼(이전,다음) 디스플레이 및 이벤트설정*/
				if(opts.btnFlag){
					moveContentsBtn();
					if($contConCnt>opts.slideView){
						$btnNext.bind("click",function(){ if(!$(this).hasClass(opts.btnNextOff)) moveIndexPlus();});
						$btnPrev.bind("click",function(){ if(!$(this).hasClass(opts.btnPrevOff)) moveIndexMinus();});
					}
				}else{
					$btnPrev.hide();
					$btnNext.hide();
				}

				/* $contEventEl 이벤트설정 */
				if(opts.iconFlag){
					$contEventEl.bind(opts.iconFlagEvent,function(){
						$moveMode = $contEventEl.index($(this))-$contSelIndex>0? true : false;
						$iconMode=true;
						$oldSelIndex = $contSelIndex;
						$contSelIndex = $contEventEl.index($(this));
						moveContentsAnimation();
						return opts.eventReturn;
					});
				}else{
					if($contEventEl) $contEventEl.hide();
				}

				/* 오토플레이 이벤트 설정(컨텐츠 오버시 오토플레이 일시멈춤) */
				$contEventCon.hover(function(){
					clearTimeout($contTimer);
				},function(){
					if($playMode && opts.autoPlay) callAnimation();
				});

				/* delayTimer에 의한 자동애니메시션 설정*/
				if($playMode && opts.autoPlay) setTimeout(callAnimation,opts.delayTimer);

				/* 플레이 컨트롤러 설정 */
				if(opts.controlFlag){
					$btnPlay.bind("click",function(){
						$playMode = true;
						$btnPlay.hide(); //20130503 접근성관련 추가
						$btnStop.show(); //20130503 접근성관련 추가
						$contTimer = setTimeout(moveIndexPlus,opts.changeTimer);
					});
					$btnStop.bind("click",function(){
						$playMode = false;
						$btnStop.hide(); //20130503 접근성관련 추가
						$btnPlay.show(); //20130503 접근성관련 추가
						clearTimeout($contTimer);
					});
				}

				/* 콜백함수설정 */
				if(opts.conCallBack){
					$contEventCon.bind("click",function(){
						$contEventCon.removeClass("sel");
						$(this).addClass("sel");
						opts.conCallBack();
					});
				}
			}else{
				if($contEventEl) $contEventEl.hide();
			}

			/********************************************************
			//다음컨텐츠보기
			********************************************************/
			function moveIndexPlus(){
				$moveMode = true;
				$oldSelIndex = $contSelIndex;
				$contSelIndex++;
				if($contSelIndex>$contConCnt-1) $contSelIndex=0;
				moveContentsAnimation();
			}

			/*********************************************************
			//이전컨텐츠보기
			*********************************************************/
			function moveIndexMinus(){
				$moveMode = false;
				$oldSelIndex = $contSelIndex;
				$contSelIndex--;
				if($contSelIndex<0) $contSelIndex = $contConCnt-1;
				moveContentsAnimation();
			}

			/*********************************************************
			//오토플레이 호출 함수
			*********************************************************/
			function callAnimation(){
				clearTimeout($contTimer);
				$contTimer = setTimeout(moveIndexPlus,opts.changeTimer);
			}

			/*********************************************************
			//아이콘버튼 디스플레이함수
			*********************************************************/
			function displayIcon(){
				$contEventCon.each(function(){
					if($contEventCon.index($(this))!=$contSelIndex){
						$contEventEl.eq($contEventCon.index($(this))).removeClass(opts.onClass);
						if(opts.onImage){
							$contEventEl.eq($contEventCon.index($(this))).find('img').attr('src', function() {return $(this).attr("src").replace("_on", "_off");});
						}
					}else{
						$contEventEl.eq($contEventCon.index($(this))).addClass(opts.onClass);
						if(opts.onImage){
							$contEventEl.eq($contEventCon.index($(this))).find('img').attr('src', function() {return $(this).attr("src").replace("_off", "_on");});
						};
					}
				});
			}

			/*********************************************************
			//버튼 디스플레이 설정 함수
			*********************************************************/
			function moveContentsBtn(){
				if(opts.btnFlagDisabled){
					if($contSelIndex<1 && !opts.btnFlagAll) $btnPrev.addClass(opts.btnPrevOff);
					else $btnPrev.removeClass(opts.btnPrevOff);

					if($contSelIndex+opts.slideView>=$contConCnt && !opts.btnFlagAll) $btnNext.addClass(opts.btnNextOff);
					else $btnNext.removeClass(opts.btnNextOff);
				}else{
					if($contSelIndex<1 && !opts.btnFlagAll) $btnPrev.hide();
					else $btnPrev.show();

					if($contSelIndex>=$contConCnt-1 && !opts.btnFlagAll) $btnNext.hide();
					else $btnNext.show();
				}
			}

			/*********************************************************
			//선택된 index에 따른 새 위치값 계산
			*********************************************************/
			function newPosition(obj){
				var value = $contEventCon.index(obj) - $contSelIndex;
				console.log(value+"i")
				if(opts.slideRepeat && !$iconMode){
					if($moveMode){
						if(value>=opts.slideView) value = value - $contConCnt;
						if(value<-1) value = value + $contConCnt;
					}else{
						if(value>opts.slideView) value = value - $contConCnt;
						if(value<=(-1)*($contConCnt-opts.slideView)) value = value + $contConCnt;
					}
				}
				value = value * $slideValue;
				return value;
			}

			/*********************************************************
			//Animation - effect : show일때
			*********************************************************/
			function moveAni_show(){
				$contEventCon.each(function(){

					if($contSelIndex==$contEventCon.index($(this))) $(this).addClass(opts.onClass);
					else $(this).removeClass(opts.onClass);

					if($contEventCon.index($(this))!=$contSelIndex) $(this).hide();
					else $(this).show();
				});
			}

			/*********************************************************
			//Animation -effect : fade일때
			*********************************************************/
			function moveAni_fade(){
				$contEventCon.each(function(){

					if($contSelIndex==$contEventCon.index($(this))) $(this).addClass(opts.onClass);
					else $(this).removeClass(opts.onClass);

					if($contEventCon.index($(this))!=$contSelIndex) $(this).fadeOut(opts.aniTimer);
					else $(this).fadeIn(opts.aniTimer);
				});
			}

			/*********************************************************
			//Animation - effect : slide일때
			*********************************************************/
			function moveAni_slide(){
				/* 슬라이드반복설정일때 애니메이션 효과를 위한 시작위치 재설정 */
				
				if(opts.slideRepeat){
					$contEventCon.each(function(){
						var value = Number($(this).css(opts.slideFor).replace("px",""))/$slideValue;
						if($moveMode){
							if(value<0) value = value + $contConCnt;
						}
						else{

							if(value>=opts.slideView) value = value - $contConCnt;
						}
						value = value*$slideValue;
						$(this).css(opts.slideFor,value);
					});
				}

				/* 새위치설정 */
				$contEventCon.each(function(){
					
					var new_position = newPosition($(this));

					if($contSelIndex==$contEventCon.index($(this))) $(this).addClass(opts.onClass);
					else $(this).removeClass(opts.onClass);
					console.log(new_position)
					switch(opts.slideFor)
						
					{
						case "right":
						$(this).stop().animate({"right":new_position}, opts.aniTimer, opts.easing);
						break;

						case "top":
						$(this).stop().animate({"top":new_position}, opts.aniTimer, opts.easing);
						break;

						case "bottom":
						$(this).stop().animate({"bottom":new_position}, opts.aniTimer, opts.easing);
						break;

						default:
						$(this).stop().animate({"left":new_position}, opts.aniTimer, opts.easing);
						break;
					}
				});
			}

			/*********************************************************
			//Animation - effect : circle일때
			*********************************************************/
			function moveAni_circle(){
				$contEventCon.eq($contSelIndex)
					.addClass("on")
					.css("z-index",$circle_info[0]["z-index"])
					.animate({
						"opacity" : 1,
						"left" : $circle_info[0]["left"],
						"top" : $circle_info[0]["top"],
						"width" : $circle_info[0]["width"],
						"height" : $circle_info[0]["height"]
					}, opts.aniTimer, opts.easing);

				for(i=1;i<=$sideDeps;i++){
					prevIndex = $contSelIndex-i;
					if(prevIndex<0) prevIndex = prevIndex+$contConCnt;

					nextIndex = $contSelIndex+i;
					if(nextIndex>=$contConCnt) nextIndex = nextIndex-$contConCnt;

					var newIndex = $circle_info[0]["z-index"]-(i*2);
					if($moveMode){
						var newIndex_prev = newIndex-1;
						var newIndex_next = newIndex-2;
					}else{
						var newIndex_prev = newIndex-2;
						var newIndex_next = newIndex-1;
					}

					if(opts.slideFor=="vertical"){
						$contEventCon.eq(prevIndex)
							.removeClass("on")
							.css("z-index",newIndex_prev)
							.animate({
								"opacity" : opts.circleOpacity,
								"top" : $circle_info[i]["top_prev"],
								"left" : $circle_info[i]["left"],
								"width" : $circle_info[i]["width"],
								"height" : $circle_info[i]["height"]
							}, opts.aniTimer, opts.easing);

						$contEventCon.eq(nextIndex)
							.removeClass("on")
							.css("z-index",newIndex_next)
							.animate({
								"opacity" : opts.circleOpacity,
								"top" : $circle_info[i]["top_next"],
								"left" : $circle_info[i]["left"],
								"width" : $circle_info[i]["width"],
								"height" : $circle_info[i]["height"]
							}, opts.aniTimer, opts.easing);
					}else{
						$contEventCon.eq(prevIndex)
							.removeClass("on")
							.css("z-index",newIndex_prev)
							.animate({
								"opacity" : opts.circleOpacity,
								"left" : $circle_info[i]["left_prev"],
								"top" : $circle_info[i]["top"],
								"width" : $circle_info[i]["width"],
								"height" : $circle_info[i]["height"]
							}, opts.aniTimer, opts.easing);

						$contEventCon.eq(nextIndex)
							.removeClass("on")
							.css("z-index",newIndex_next)
							.animate({
								"opacity" : opts.circleOpacity,
								"left" : $circle_info[i]["left_next"],
								"top" : $circle_info[i]["top"],
								"width" : $circle_info[i]["width"],
								"height" : $circle_info[i]["height"]
							}, opts.aniTimer, opts.easing);
					}
				}
			}

			/*********************************************************
			//Animation - effect : accordion일때
			*********************************************************/
			function moveAni_accordion(){
				$contEventCon.each(function(){
					var new_position = opts.accordionMin*$contEventCon.index($(this));
					if($contSelIndex<$contEventCon.index($(this))) new_position = new_position + ($accordionMax-opts.accordionMin);

					$(this).stop(true).animate({
						"left" : new_position
					}, opts.aniTimer, opts.easing);

					if($contEventCon.index($(this))==$contSelIndex) $(this).addClass(opts.onClass);
					else $(this).removeClass(opts.onClass);
				});
			}

			/*********************************************************
			//컨텐츠 디스플레이 함수
			*********************************************************/
			function moveContentsAnimation(){

				clearTimeout($contTimer);

				switch(opts.effect)
				{
					case "fade":
					moveAni_fade();
					break;

					case "slide":
					moveAni_slide();
					break;

					case "circle":
					moveAni_circle();
					break;

					case "accordion":
					moveAni_accordion();
					break;

					default:
					moveAni_show();
					break;
				}

				//아이콘버튼 재설정
				if(opts.iconFlag) displayIcon();

				//이동버튼출력 재설정
				if(opts.btnFlag) moveContentsBtn();

				//오토플레이 재설정
				if(opts.autoPlay && $playMode) callAnimation();

				//콜백함수
				if(opts.changeCallBack) opts.changeCallBack();

				$iconMode = false;
			}
		});
	};

	$.fn.moveContents.defaults = {
		eventEl : ">ul a",
		conEl : ">div",
		defaultIndex : 0,
		addContain : null,
		onClass : "on",
		onImage : false,
		iconFlag : true,
		iconFlagEvent : "click",
		btnFlag : false,
		btnFlagAll : false,
		btnFlagDisabled : false,
		btnPrev : ".btn-prev",
		btnNext : ".btn-next",
		btnPrevOff : "btn-prev-off",
		btnNextOff : "btn-next-off",
		autoPlay : false,
		delayTimer : 0,
		changeTimer : 2000,
		controlFlag : false,
		btnPlay : ".btn-play",
		btnStop : ".btn-stop",
		effect : "show",
		easing : "linear",
		aniTimer : 600,
		slideFor : "left",
		slideValue : null,
		slideView : 1,
		slideRepeat : false,
		circleRatio : 0.8,
		circleSide : 20,
		circleOpacity : 0.9,
		accordionMin : 50,
		accordionMax : null,
		conEvent : "click",
		changeCallBack : null,
		conCallBack : null,
		eventReturn : false
	};

})(jQuery);


/***********************************************
* toggleContents
************************************************/
(function($) {

	/* 펼침메뉴 */
	$.fn.toggleContents = function(options){
		options = options || {};
		var opts = $.extend({}, $.fn.toggleContents.defaults, options || {});

		return this.each(function() {

			var $cont = $(this);
			var $eventEl = $cont.find(opts.eventEl);
			var $conEl = $cont.find(opts.conEl);
			var $conTimer;

			//초기화
			$conEl.hide();
			$cont.removeClass(opts.onClass);

			//이벤트설정
			if(opts.openEvent=="hover"){
				$eventEl.hover(function(){
					displayOpen();
				},function(){
					$conTimer = setTimeout(displayClose,1000);
				});

				$conEl.hover(function(){
					clearTimeout($conTimer);
				},function(){
					displayClose();
				});
			}else{
				$eventEl.bind("click",function(){
					if($conEl.is(":hidden")) displayOpen();
					else displayClose();
					return false;
				});

				/* 수정필요!!
				$(document).not($conEl).bind("click",function(){
					displayClose();
				});
				*/
			}

			//컨텐츠내 이벤트 발생시 메뉴초기화
			if(opts.conEventEl){
				$conEl.find(opts.conEventEl).bind('click',function(){
					displayClose();
				});
			}

			//닫기버튼 있을경우 이벤트추가
			if(opts.closeEl){
				$cont.find(opts.conEl).bind('click',function(){
					displayClose();
					return false;
				});
			}

			//디스플레이(open)
			function displayOpen(){
				$cont.addClass(opts.onClass);

				switch(opts.effect)
				{
					case "slide":
					$conEl.slideDown(opts.aniTimer, opts.easing);
					break;

					case "fade":
					$conEl.fadeIn(opts.aniTimer, opts.easing);
					break;

					default:
					$conEl.show();
					break;
				}

				if(opts.callBack) opts.callBack();
			}

			//디스플레이(close)
			function displayClose(){
				$cont.removeClass(opts.onClass);
				switch(opts.effect)
				{
					case "slide":
					$conEl.slideUp(opts.aniTimer, opts.easing);
					break;

					case "fade":
					$conEl.fadeOut(opts.aniTimer, opts.easing);
					break;

					default:
					$conEl.hide();
					break;
				}
			}
		});
	};

	$.fn.toggleContents.defaults = {
		eventEl : ">button",
		conEl : ">div",
		conEventEl : null,
		closeEl : null,
		onClass : null,
		effect : "show",
		aniTimer : 600,
		easing : "linear",
		openEvent : "click",
		callBack : null
	};

})(jQuery);

/***********************************************
* navMenu
************************************************/
(function($) {

	$.fn.navMenu = function(options){
		return this.each(function() {
			options = options || {};
			var opts = $.extend({}, $.fn.navMenu.defaults, options || {});

			var $navEl = $(this);
			var $thisDeps = null;
			var $selEl = null;


			/* 초기화*/
			$navEl.find("ul").hide();
			$navEl.find("."+opts.onClass).addClass(opts.defaultClass).find(">ul").show();
			resetImg();

			/* 이벤트설정 */
			$navEl.find("a").bind("click",function(){
				$thisDeps = ($(this).prop("class").replace("deps0",""))*1;
				$selEl = $(this);

				if($(this).attr("href")!="#none" || ($(this).parent().attr("id")!=null && opts.ajaxTarget)){
					if(opts.ajaxTarget){
						$navEl.find("li").removeClass();
						for(i=$thisDeps;i>=1;i--){
							if($thisDeps==i) $selEl = $selEl.parent();
							else $selEl = $selEl.parent().parent();
							$selEl.addClass(opts.onClass+" " +opts.defaultClass);
						}
						resetNav();
						/*
						$.ajax({
							beforeSend : function() {},
							url : $(this).attr("href"),
							success : function(data) {
								$(opts.ajaxTarget).children().remove();
								$(opts.ajaxTarget).append(dataProcessing(data));
							}
						});
						*/
						return false;
					}else{
						return true;
					}
				}else{
					resetNav();
					$(this)
						.parent().addClass(opts.onClass)
						.end()
						.siblings("ul").slideDown();
					resetImg();
					return false;
				}
			});

			function resetNav(){
				$navEl.find("li").removeClass(opts.activeClass);

				for(i=$thisDeps;i>=1;i--){
					if($thisDeps==i) $selEl = $selEl.parent();
					else $selEl = $selEl.parent().parent();
					$selEl.addClass(opts.activeClass);
				}

				$navEl.find("li:not(."+opts.defaultClass+")").each(function(){
					if(!$(this).hasClass(opts.activeClass)){
						$(this).removeClass("on").find(">ul").stop(true).slideUp();
					}
				});
				resetImg();
			}

			/* 이미지 설정 */
			function resetImg(){
				$navEl.find("li:not(."+opts.onClass+")>a").find("img").attr("src",function(){return $(this).attr("src").replace("_on","_off");});
				$navEl.find("li."+opts.onClass+">a").find("img").attr("src",function(){return $(this).attr("src").replace("_off","_on");});
			}

		});
	};

	$.fn.navMenu.defaults = {
		onClass : "on",
		defaultClass : "default",
		activeClass : "active",
		deps : 2,
		ajaxTarget : false
	};
})(jQuery);

/***********************************************
* tooltip
************************************************/
(function($) {

	$.fn.toolTip = function(options){
		return this.each(function() {
			options = options || {};
			var opts = $.extend({}, $.fn.toolTip.defaults, options || {});

			var $targetEl = $(this).next(opts.targetEl);
			var $toolTimer;

			$(this).hover(function(){
				if(opts.position){
					$targetEl.css({
						left : opts.position_left,
						top : opts.position_top
					});
				}
				$targetEl.css('z-index', 9999);
				$targetEl.show();
			}, function() {
				$targetEl.hide();
			});
		});
	};

	$.fn.toolTip.defaults = {
		targetEl : ".tooltip",
		position : false,
		position_left : 0,
		position_top : 0
	};
})(jQuery);

/***********************************************
* selectbox design
************************************************/
(function($){
	//add class to html tag
	$('html').addClass('stylish-select');

	//create cross-browser indexOf
	Array.prototype.indexOf = function (obj, start) {
		for (var i = (start || 0); i < this.length; i++) {
			if (this[i] == obj) {
				return i;
			}
		}
	}

	//utility methods
	$.fn.extend({
		getSetSSValue: function(value){
			if (value){
				//set value and trigger change event
				$(this).val(value).change();
				return this;
			} else {
				return $(this).find(':selected').val();
			}
		},
		//added by Justin Beasley
		resetSS: function(){
			var oldOpts = $(this).data('ssOpts');
			$this = $(this);
			$this.next().remove();
			//unbind all events and redraw
			$this.unbind('.sSelect').sSelect(oldOpts);
		}
	});

	$.fn.sSelect = function(options) {

		return this.each(function(){

		var defaults = {
			defaultText: 'Please select',
			listWidth: 95,
			animationSpeed: 0, //set speed of dropdown
			listMaxHeight: '210', //set css max-height value of dropdown (높이값 21px 13개로 기본세팅함)
			containerClass: '', //additional classes for container div
			containerOnClass: 'select-list-on', //additional classes for container div on
			disabled : false
		};

		//initial variables
		var opts = $.extend(defaults, options),
		$input = $(this),
		$containerDivText = $('<div class="selected-headline"></div>'),
		$containerDiv = $('<div class="select-list-box ' + opts.containerClass + '"></div>'),
		$newUl = $('<ul class="select-list" style="visibility:hidden;"></ul>'),
		itemIndex = -1,
		currentIndex = -1,
		keys = [],
		prevKey = false,
		prevented = false,
		$newLi;

		//added by Justin Beasley
		$(this).data('ssOpts',options);

		//build new list
		$containerDiv.insertAfter($input);
		$containerDiv.attr("tabindex", $input.attr("tabindex") || "0");
		$containerDiv.css("width",opts.listWidth+"px");
		$containerDivText.prependTo($containerDiv);
		$newUl.appendTo($containerDiv);
		$input.hide();

		//added by Justin Beasley (used for lists initialized while hidden)
		$containerDivText.data('ssReRender',!$containerDivText.is(':visible'));

			//test for optgroup
			if ($input.children('optgroup').length == 0){
				$input.children().each(function(i){
					var option = $(this).html();
					var key = $(this).val();

					//add first letter of each word to array
					keys.push(option.charAt(0).toLowerCase());
					if ($(this).prop('selected') == true){
						opts.defaultText = option;
						currentIndex = i;
					}
					$newUl.append($('<li><a href="#none" onclick="void(0);">'+option+'</a></li>').data('key', key));

				});
				//cache list items object
				$newLi = $newUl.children().children();

			} else { //optgroup
				$input.children('optgroup').each(function(){

					var optionTitle = $(this).attr('label'),
					$optGroup = $('<li class="select-list-option-title">'+optionTitle+'</li>');

					$optGroup.appendTo($newUl);

					var $optGroupList = $('<ul></ul>');

					$optGroupList.appendTo($optGroup);

					$(this).children().each(function(){
						++itemIndex;
						var option = $(this).html();
						var key = $(this).val();
						//add first letter of each word to array
						keys.push(option.charAt(0).toLowerCase());
						if ($(this).prop('selected') == true){
							opts.defaultText = option;
							currentIndex = itemIndex;
						}
						$optGroupList.append($('<li><a href="JavaScript:void(0);">'+option+'</a></li>').data('key',key));
					})
				});
				//cache list items object
				$newLi = $newUl.find('ul li a');
			}

			//get heights of new elements for use later
			//var newUlHeight = $newUl.outerHeight(),
			var newUlHeight = $newUl.height(),
			containerHeight = $containerDiv.height(),
			newLiLength = $newLi.length;

			//check if a value is selected
			if (currentIndex != -1){
				navigateList(currentIndex, true);
			} else {
				//set placeholder text
				$containerDivText.html(opts.defaultText);
			}

			//decide if to place the new list above or below the drop-down
			function newUlPos(){
				var containerPosY = $containerDiv.offset().top,
				docHeight = jQuery(window).height(),
				scrollTop = jQuery(window).scrollTop();

				//if height of list is greater then max height, set list height to max height value
				if (newUlHeight > parseInt(opts.listMaxHeight)) {
					newUlHeight = parseInt(opts.listMaxHeight);
				}

				containerPosY = containerPosY-scrollTop;
				if (containerPosY+newUlHeight >= docHeight){
					$newUl.css({
						//top: '-'+newUlHeight-1+'px',
						top: containerHeight-1+'px',
						width : opts.listWidth-2+'px',
						height: newUlHeight
					});
					$input.onTop = true;
				} else {
					$newUl.css({
						top: containerHeight-1+'px',
						width : opts.listWidth-2+'px',
						height: newUlHeight
					});
					$input.onTop = false;
				}
			}

			//run function on page load
			newUlPos();

			//run function on browser window resize
			$(window).bind('resize.sSelect scroll.sSelect', newUlPos);

			//positioning
			function positionFix(){
				$containerDiv.css('position','relative');
			}

			function positionHideFix(){
				$containerDiv.css('position','static');
			}

			$containerDivText.bind('click.sSelect',function(event){
				if(opts.disabled){
					return false;
				}else{
					event.stopPropagation();

					//added by Justin Beasley
					if($(this).data('ssReRender')) {
						newUlHeight = $newUl.height('').height();
						containerHeight = $containerDiv.height();
						$(this).data('ssReRender',false);
						newUlPos();
					}

					//hide all menus apart from this one
					$('.select-list').not($(this).next()).hide()
						.parent()
							.css('position', 'static')
							.removeClass('select-list-selfocus');

					//show/hide this menu
					$newUl.toggle();
					positionFix();
					//scroll list to selected item
					$newLi.eq(currentIndex).focus();

					if($newUl.is(":hidden")) $containerDiv.removeClass(opts.containerOnClass);
					else $containerDiv.addClass(opts.containerOnClass);
				}
			});

			$newLi.bind('click.sSelect',function(e){
				var $clickedLi = $(e.target);

				//update counter
				currentIndex = $newLi.index($clickedLi);

				//remove all hilites, then add hilite to selected item
				prevented = true;
				navigateList(currentIndex);
				$newUl.hide();
				$containerDiv.css('position','static');//ie
				$containerDiv.removeClass(opts.containerOnClass);

			});

			$newLi.bind('mouseenter.sSelect',
				function(e) {
					var $hoveredLi = $(e.target);
					$hoveredLi.addClass('select-list-hover');
				}
			).bind('mouseleave.sSelect',
				function(e) {
					var $hoveredLi = $(e.target);
					$hoveredLi.removeClass('select-list-hover');
				}
			);

			function navigateList(currentIndex, init){
				$newLi.removeClass('select-list-selected')
				.eq(currentIndex)
				.addClass('select-list-selected');

				if ($newUl.is(':visible')){
					$newLi.eq(currentIndex).focus();
				}

				var text = $newLi.eq(currentIndex).html();
				var val = $newLi.eq(currentIndex).parent().data('key');

				//page load
				if (init == true){
					$input.val(val);
					$containerDivText.html(text);
					return false;
				}

				try {
					$input.val(val)
				} catch(ex) {
					// handle ie6 exception
					$input[0].selectedIndex = currentIndex;
				}

				$input.change();
				$containerDivText.html(text);
			}

			$input.bind('change.sSelect',function(event){
				$targetInput = $(event.target);
				//stop change function from firing
				if (prevented == true){
					prevented = false;
					return false;
				}
				$currentOpt = $targetInput.find(':selected');

				//currentIndex = $targetInput.find('option').index($currentOpt);
				currentIndex = $targetInput.find('option').index($currentOpt);

				navigateList(currentIndex, true);
			});

			//handle up and down keys
			function keyPress(element) {
				//when keys are pressed
				$(element).unbind('keydown.sSelect').bind('keydown.sSelect',function(e){
					var keycode = e.which;

					//prevent change function from firing
					prevented = true;

					switch(keycode) {
						case 40: //down
						case 39: //right
							incrementList();
							return false;
							break;
						case 38: //up
						case 37: //left
							decrementList();
							return false;
							break;
						case 33: //page up
						case 36: //home
							gotoFirst();
							return false;
							break;
						case 34: //page down
						case 35: //end
							gotoLast();
							return false;
							break;
						case 13:
						case 27:
							$newUl.hide();
							$containerDiv.removeClass(opts.containerOnClass);
							positionHideFix();
							return false;
							break;
					}

					//check for keyboard shortcuts
					keyPressed = String.fromCharCode(keycode).toLowerCase();

					var currentKeyIndex = keys.indexOf(keyPressed);

					if (typeof currentKeyIndex != 'undefined') { //if key code found in array
						++currentIndex;
						currentIndex = keys.indexOf(keyPressed, currentIndex); //search array from current index
						if (currentIndex == -1 || currentIndex == null || prevKey != keyPressed) currentIndex = keys.indexOf(keyPressed); //if no entry was found or new key pressed search from start of array

						navigateList(currentIndex);
						//store last key pressed
						prevKey = keyPressed;
						return false;
					}
				});
			}

			function incrementList(){
				if (currentIndex < (newLiLength-1)) {
					++currentIndex;
					navigateList(currentIndex);
				}
			}

			function decrementList(){
				if (currentIndex > 0) {
					--currentIndex;
					navigateList(currentIndex);
				}
			}

			function gotoFirst(){
				currentIndex = 0;
				navigateList(currentIndex);
			}

			function gotoLast(){
				currentIndex = newLiLength-1;
				navigateList(currentIndex);
			}

			$containerDiv.bind('click.sSelect',function(e){
				e.stopPropagation();
				keyPress(this);
			});

			$containerDiv.bind('focus.sSelect',function(){
				$(this).addClass('select-list-selfocus');
				keyPress(this);
			});

			$containerDiv.bind('blur.sSelect',function(){
				$(this).removeClass('select-list-selfocus');
			});

			//hide list on blur
			$(document).bind('click.sSelect',function(){
				$containerDiv.removeClass('select-list-selfocus');
				$newUl.hide();
				$containerDiv.removeClass(opts.containerOnClass);
				positionHideFix();
			});

			//add classes on hover
			$containerDivText.bind('mouseenter.sSelect',
				function(e) {
					var $hoveredTxt = $(e.target);
					$hoveredTxt.parent().addClass('select-list-selhover');
				}
			).bind('mouseleave.sSelect',
				function(e) {
					var $hoveredTxt = $(e.target);
					$hoveredTxt.parent().removeClass('select-list-selhover');
				}
			);

			//reset left property and hide
			$newUl.css({
				left: '0',
				display: 'none',
				visibility: 'visible'
			});
		});
	};

})(jQuery);

/*****************************************
	filestyle : 파일업로드 폼 디자인
*****************************************/
(function($) {

	$.fn.filestyle = function(options) {

		var settings = {
			width : 250
		};

		if(options) {
			$.extend(settings, options);
		};

		return this.each(function() {

		var self = this;
		var wrapper = $("<div>")
			.css({
				"width": settings.imagewidth + 4 + "px",
				"height": settings.imageheight + "px",
				"background": "url(" + settings.image + ") 0 0 no-repeat",
				"background-position": "4px 0",
				"display": "inline",
				"position": "absolute",
				"overflow": "hidden"
			});

		var filename = $('<input class="file">')
			.addClass($(self).attr("class"))
			.css({
				"display": "inline",
				"width": settings.width + "px"
			});

		$(self).before(filename);
		$(self).wrap(wrapper);

		$(self).css({
			"position": "relative",
			"height": settings.imageheight + "px",
			"width": settings.width + "px",
			"display": "inline",
			"cursor": "pointer",
			"opacity": "0.0"
		});

		if ($.browser.mozilla) {
			if (/Win/.test(navigator.platform)) {
				$(self).css("margin-left", "-142px");
			} else {
				$(self).css("margin-left", "-168px");
			};
		} else {
			$(self).css("margin-left", settings.imagewidth - settings.width + "px");
		};

		$(self).bind("change", function() {
			filename.val($(self).val());
		});
		});
	};

})(jQuery);


/*****************************************
	mCustomScrollbar : 컨텐츠 스크롤 디자인
*****************************************/
(function ($) {

	$.fn.mCustomScrollbar = function (options){
		return this.each(function(n) {
			options = options || {};
			var $scrollEl = $(this);
			var opts = $.extend({}, $.fn.mCustomScrollbar.defaults, options || {});

			/* 2011-06-21 add : 스크롤바 디자인에 필요한 마크업 추가  및 기본 overflow 스타일 초기화 */
			var $addOld = $scrollEl.children();
			var $addBox = $("<div>").addClass("scroll-box");
			var $addBoxContainer = $("<div>").addClass("scroll-container");
			var $addBoxContent = $("<div>").addClass("scroll-content");
			var $addDraggerContainer = $("<div>").addClass("dragger-container");
			var $addDragger = $("<div>").addClass("dragger");
			var $addBtnUp = $("<a>").addClass("scroll-btn-up");
			var $addBtnDown = $("<a>").addClass("scroll-btn-down");

			$addBoxContent.append($addOld);
			$addBoxContainer.append($addBoxContent);
			$addBox.append($addBoxContainer);

			$addDraggerContainer.append($addDragger);
			$addBox.append($addDraggerContainer);

			$addBtnUp.append("상단으로이동");
			$addBtnDown.append("하단으로이동");

			$scrollEl.append($addBox);

			if(opts.scrollBtnsSupport=="yes"){
				$scrollEl.append($addBtnUp);
				$scrollEl.append($addBtnDown);
				if(opts.scrollType=="horizontal"){
					$addDraggerContainer.css({
						"width" : $scrollEl.outerWidth()-($addBtnUp.outerWidth()+$addBtnDown.outerWidth())
					});
				}else{
					$addDraggerContainer.css({
						"height" : $scrollEl.outerHeight()-($addBtnUp.outerHeight()+$addBtnDown.outerHeight())
					});
				}
			}

			$scrollEl.css("overflow","hidden");
			/* 2011-06-21 add : 스크롤바 디자인에 필요한 마크업 추가 */

			var $customScrollBox=$scrollEl.find(".scroll-box");
			var $customScrollBox_container=$scrollEl.find(".scroll-box .scroll-container");
			var $customScrollBox_content=$scrollEl.find(".scroll-box .scroll-content");
			var $dragger_container=$scrollEl.find(".dragger-container");
			var $dragger=$scrollEl.find(".dragger");
			var $scrollUpBtn=$scrollEl.find(".scroll-btn-up");
			var $scrollDownBtn=$scrollEl.find(".scroll-btn-down");

			CustomScroller();

			function CustomScroller(){
				//horizontal scrolling ------------------------------
				if(opts.scrollType=="horizontal"){
					var visibleWidth=$customScrollBox.width();
					if($customScrollBox_container.width()>visibleWidth){ //enable scrollbar if content is long
						$dragger.css("display","block");
						$dragger_container.css("display","block");
						$scrollDownBtn.css("display","inline-block");
						$scrollUpBtn.css("display","inline-block");
						var totalContent=$customScrollBox_content.width();
						var minDraggerWidth=$dragger.width();
						var draggerContainerWidth=$dragger_container.width();

						function AdjustDraggerWidth(){
							if(opts.draggerDimType=="auto"){
								var adjDraggerWidth=Math.round(totalContent-((totalContent-visibleWidth)*1.3)); //adjust dragger width analogous to content
								if(adjDraggerWidth<=minDraggerWidth){ //minimum dragger width
									$dragger.css("width",minDraggerWidth+"px");
								} else if(adjDraggerWidth>=draggerContainerWidth){
									$dragger.css("width",draggerContainerWidth-10+"px");
								} else {
									$dragger.css("width",adjDraggerWidth+"px");
								}
							}
						}
						AdjustDraggerWidth();

						var targX=0;
						var draggerWidth=$dragger.width();
						$dragger.draggable({
							axis: "x",
							containment: "parent",
							drag: function(event, ui) {
								ScrollX();
							},
							stop: function(event, ui) {
								DraggerRelease();
							}
						});

						$dragger_container.click(function(e) {
							var $this=$(this);
							var mouseCoord=(e.pageX - $this.offset().left);
							if(mouseCoord<$dragger.position().left || mouseCoord>($dragger.position().left+$dragger.outerWidth())){
								var targetPos=mouseCoord+$dragger.outerWidth();
								if(targetPos<$dragger_container.outerWidth()){
									$dragger.css("left",mouseCoord);
									ScrollX();
								} else {
									$dragger.css("left",$dragger_container.width()-$dragger.outerWidth());
									ScrollX();
								}
							}
						});

						//mousewheel
						$(function($) {
							if(opts.mouseWheelSupport=="yes"){
								$customScrollBox.bind("mousewheel", function(event, delta) {
									var vel = Math.abs(delta*10);
									$dragger.css("left", $dragger.position().left-(delta*vel));
									ScrollX();
									if($dragger.position().left<0){
										$dragger.css("left", 0);
										$customScrollBox_container.stop();
										ScrollX();
									}
									if($dragger.position().left>$dragger_container.outerWidth()-$dragger.outerWidth()){
										$dragger.css("left", $dragger_container.outerWidth()-$dragger.outerWidth());
										$customScrollBox_container.stop();
										ScrollX();
									}
									return false;
								});
							}
						});

						//scroll buttons
						if(opts.scrollBtnsSupport=="yes"){
							$scrollDownBtn.mouseup(function(){
								BtnsScrollXStop();
							}).mousedown(function(){
								BtnsScrollX("down");
							});

							$scrollUpBtn.mouseup(function(){
								BtnsScrollXStop();
							}).mousedown(function(){
								BtnsScrollX("up");
							});

							$scrollDownBtn.click(function(e) {
								e.preventDefault();
							});
							$scrollUpBtn.click(function(e) {
								e.preventDefault();
							});

							btnsScrollTimerX=0;

							function BtnsScrollX(dir){
								if(dir=="down"){
									var btnsScrollTo=$dragger_container.width()-$dragger.width();
									var scrollSpeed=Math.abs($dragger.position().left-btnsScrollTo)*(100/opts.scrollBtnsSpeed);
									$dragger.stop().animate({left: btnsScrollTo}, scrollSpeed,"linear");
								} else {
									var btnsScrollTo=0;
									var scrollSpeed=Math.abs($dragger.position().left-btnsScrollTo)*(100/opts.scrollBtnsSpeed);
									$dragger.stop().animate({left: -btnsScrollTo}, scrollSpeed,"linear");
								}
								clearInterval(btnsScrollTimerX);
								btnsScrollTimerX = setInterval( ScrollX, 20);
							}

							function BtnsScrollXStop(){
								clearInterval(btnsScrollTimerX);
								$dragger.stop();
							}
						}

						//scroll
						var scrollAmount=(totalContent-visibleWidth)/(draggerContainerWidth-draggerWidth);
						function ScrollX(){
							var draggerX=$dragger.position().left;
							var targX=-draggerX*scrollAmount;
							var thePos=$customScrollBox_container.position().left-targX;
							$customScrollBox_container.stop().animate({left: "-="+thePos}, opts.animSpeed, opts.easeType);
						}
					} else { //disable scrollbar if content is short
						$dragger.css("left",0).css("display","none"); //reset content scroll
						$customScrollBox_container.css("left",0);
						$dragger_container.css("display","none");
						$scrollDownBtn.css("display","none");
						$scrollUpBtn.css("display","none");
					}
				//vertical scrolling ------------------------------
				} else {
					var visibleHeight=$customScrollBox.height();
					if($customScrollBox_container.height()>visibleHeight){ //enable scrollbar if content is long
						$dragger.css("display","block");
						$dragger_container.css("display","block");
						$scrollDownBtn.css("display","inline-block");
						$scrollUpBtn.css("display","inline-block");
						var totalContent=$customScrollBox_content.height();
						var minDraggerHeight=$dragger.height();
						var draggerContainerHeight=$dragger_container.height();

						function AdjustDraggerHeight(){
							if(opts.draggerDimType=="auto"){
								var adjDraggerHeight=Math.round(totalContent-((totalContent-visibleHeight)*1.3)); //adjust dragger height analogous to content
								if(adjDraggerHeight<=minDraggerHeight){ //minimum dragger height
									minDraggerHeight = 20;
									$dragger.css("height",minDraggerHeight+"px").css("line-height",minDraggerHeight+"px");
								} else if(adjDraggerHeight>=draggerContainerHeight){
									$dragger.css("height",draggerContainerHeight-10+"px").css("line-height",draggerContainerHeight-10+"px");
								} else {
									$dragger.css("height",adjDraggerHeight+"px").css("line-height",adjDraggerHeight+"px");
								}
							}
						}
						AdjustDraggerHeight();

						var targY=0;
						var draggerHeight=$dragger.height();
						$dragger.draggable({
							axis: "y",
							containment: "parent",
							drag: function(event, ui) {
								Scroll();
							},
							stop: function(event, ui) {
								DraggerRelease();
							}
						});

						$dragger_container.click(function(e) {
							var $this=$(this);
							var mouseCoord=(e.pageY - $this.offset().top);
							if(mouseCoord<$dragger.position().top || mouseCoord>($dragger.position().top+$dragger.outerHeight())){
								var targetPos=mouseCoord+$dragger.outerHeight();
								if(targetPos<$dragger_container.outerHeight()){
									$dragger.css("top",mouseCoord);
									Scroll();
								} else {
									$dragger.css("top",$dragger_container.outerHeight()-$dragger.outerHeight());
									Scroll();
								}
							}
						});

						//mousewheel
						$(function($) {
							if(opts.mouseWheelSupport=="yes"){
								$customScrollBox.bind("mousewheel", function(event, delta) {
									var vel = Math.abs(delta*opts.viewArea);
									$dragger.css("top", $dragger.position().top-(delta*vel));
									Scroll();
									if($dragger.position().top<0){
										$dragger.css("top", 0);
										$customScrollBox_container.stop();
										Scroll();
									}
									if($dragger.position().top>$dragger_container.outerHeight()-$dragger.outerHeight()){
										$dragger.css("top", $dragger_container.outerHeight()-$dragger.outerHeight());
										$customScrollBox_container.stop();
										Scroll();
									}
									return false;
								});
							}
						});

						//scroll buttons
						if(opts.scrollBtnsSupport=="yes"){
							$scrollDownBtn.mouseup(function(){
								BtnsScrollStop();
							}).mousedown(function(){
								BtnsScroll("down");
							});

							$scrollUpBtn.mouseup(function(){
								BtnsScrollStop();
							}).mousedown(function(){
								BtnsScroll("up");
							});

							$scrollDownBtn.click(function(e) {
								e.preventDefault();
							});
							$scrollUpBtn.click(function(e) {
								e.preventDefault();
							});

							btnsScrollTimer=0;

							function BtnsScroll(dir){
								if(dir=="down"){
									var btnsScrollTo=$dragger_container.height()-$dragger.height();
									var scrollSpeed=Math.abs($dragger.position().top-btnsScrollTo)*(100/opts.scrollBtnsSpeed);
									$dragger.stop().animate({top: btnsScrollTo}, scrollSpeed,"linear");
								} else {
									var btnsScrollTo=0;
									var scrollSpeed=Math.abs($dragger.position().top-btnsScrollTo)*(100/opts.scrollBtnsSpeed);
									$dragger.stop().animate({top: -btnsScrollTo}, scrollSpeed,"linear");
								}
								clearInterval(btnsScrollTimer);
								btnsScrollTimer = setInterval( Scroll, 20);
							}

							function BtnsScrollStop(){
								clearInterval(btnsScrollTimer);
								$dragger.stop();
							}
						}

						//scroll
						if(opts.bottomSpace<1){
							opts.bottomSpace=1; //minimum opts.bottomSpace value is 1
						}
						var scrollAmount=(totalContent-(visibleHeight/opts.bottomSpace))/(draggerContainerHeight-draggerHeight);
						function Scroll(){
							var draggerY=$dragger.position().top;
							var targY=-draggerY*scrollAmount;
							var thePos=$customScrollBox_container.position().top-targY;
							$customScrollBox_container.stop().animate({top: "-="+thePos}, opts.animSpeed, opts.easeType);
						}
					} else { //disable scrollbar if content is short
						$dragger.css("top",0).css("display","none"); //reset content scroll
						$customScrollBox_container.css("top",0);
						$dragger_container.css("display","none");
						$scrollDownBtn.css("display","none");
						$scrollUpBtn.css("display","none");
					}
				}

				$dragger.mouseup(function(){
					DraggerRelease();
				}).mousedown(function(){
					DraggerPress();
				});

				function DraggerPress(){
					$dragger.addClass("dragger-pressed");
				}

				function DraggerRelease(){
					$dragger.removeClass("dragger-pressed");
				}
			}

			$(window).resize(function() {
				if(opts.scrollType=="horizontal"){
					if($dragger.position().left>$dragger_container.width()-$dragger.width()){
						$dragger.css("left", $dragger_container.width()-$dragger.width());
					}
				} else {
					if($dragger.position().top>$dragger_container.height()-$dragger.height()){
						$dragger.css("top", $dragger_container.height()-$dragger.height());
					}
				}
				if(opts.mouseWheelSupport=="yes"){
					$customScrollBox.unbind("mousewheel");
				}
				CustomScroller();
			});
		});
	};

	$.fn.mCustomScrollbar.defaults = {
		scrollType : "vertical",
		animSpeed : 400,
		easeType : "easeOutCirc",
		viewArea : 10,
		//bottomSpace : 1.05,
		bottomSpace : 1.25,
		draggerDimType : "auto",
		mouseWheelSupport : "yes",
		scrollBtnsSupport : "yes",
		scrollBtnsSpeed : 10
	};

})(jQuery);

function ScrollbarReload(){
	//$(window).resize();
}

/*****************************************
	formChkDisplay : 라디오버튼 디스플레이
*****************************************/
function formChkDisplay(nameValue){
	$("input[name='"+nameValue+"']").change(function(){
		$("input[name='"+nameValue+"']").each(function(){
			$("."+$(this).attr("id")).hide();
		});
		$("."+$(this).attr("id")).show();
	});
}

/*****************************************
	formChkDisplay : 체크박스 디스플레이
*****************************************/
(function($) {
	$.fn.formDisplay = function(options){
		return this.each(function() {
			options = options || {};
			var opts = $.extend({}, $.fn.formDisplay.defaults, options || {});

			if($(this).prop("checked")){
				$("."+$(this).attr("id")).show();
			}else{
				$("."+$(this).attr("id")).hide();
			}

			$(this).click(function(){
				if($(this).prop("checked")){
					$("."+$(this).attr("id")).show();
				}else{
					$("."+$(this).attr("id")).hide();
				}
			});
		});
	};

	$.fn.formDisplay.defaults = {

	};
})(jQuery);
function formInputText(){
	jQuery(".input-txt").bind("blur",function(){
		if(jQuery(this).val()==jQuery(this).attr("title") || jQuery(this).val()==""){
			jQuery(this).val(jQuery(this).attr("title"));
			jQuery(this).addClass("input-txt-off");
		}else{
			jQuery(this).removeClass("input-txt-off");
		}
	});

	jQuery(".input-txt").bind("focus",function(){
		if(jQuery(this).val()==jQuery(this).attr("title")){
			jQuery(this).val("");
			jQuery(this).removeClass("input-txt-off");
		}else{
			jQuery(this).addClass("input-txt-off");
		}
	});
}

/*****************************************
	그래프 애니메이션
*****************************************/
(function($) {
	$.fn.graphDisplay = function(options){
		return this.each(function() {
			options = options || {};
			var opts = $.extend({}, $.fn.graphDisplay.defaults, options || {});

			var $cont = $(this);
			var $conAniEl = $cont.find(opts.eventEl);

			if(opts.onClass) $cont.addClass(opts.onClass);

			if(opts.graphType=="horizontal") aniHorizontal();
			else if(opts.graphType=="vertical") aniVertical();
			else if(opts.graphType=="sidebar") aniSidebar();
			else if(opts.graphType=="averagebar") aniAveragebar();
			else aniHorizontal();

			//수평그래프 애니메이션
			function aniHorizontal(){
				$conAniEl.each(function() {
					$(this).animate({"width" : $(this).text()}, opts.aniTimer);
				});
			}

			//수직그래프 애니메이션
			function aniVertical(){
				$conAniEl.each(function() {
					$(this).animate({"height" : $(this).text()}, opts.aniTimer);
				});
			}

			//사이드 막대그래프(최소,최대,평균) 애니메이션
			function aniSidebar(){
				var $label_position = 0;
				var chkcnt = 0;

				var graphWidth = ((opts.unitEnd-opts.unitStart)/opts.unitTerm)*opts.unitTermWidth-4;
				$cont.find("graph-wrap").css("width",graphWidth+"px");

				if($cont.find("table").length){
					$cont.find("table").css("width",$cont.outerWidth()-graphWidth+"px");
				}

				$conAniEl.each(function(){
					var $dataEl = $(this).find(opts.dataEl)
					var $value_min = $dataEl.eq(opts.dataIndexMin).find(opts.dataElText).eq(0).text().replace(",","")*1;
					var $value_max = $dataEl.eq(opts.dataIndexMax).find(opts.dataElText).eq(0).text().replace(",","")*1;
					var $value_avg = $dataEl.eq(opts.dataIndexAvg).find(opts.dataElText).eq(0).text().replace(",","")*1;

					var $this_width = (($value_max-$value_min)/opts.unitTerm)*opts.unitTermWidth;
					if(($value_avg-$value_min)==0){
						var $avg_width = 0;
					}
					else{
					var $avg_width = (($value_avg-$value_min)*100)/($value_max-$value_min);
					}
					var $this_position = ((($value_min-opts.unitStart)/opts.unitTerm)*opts.unitTermWidth)-$(this).find("li").eq(0).outerWidth();

					var $barEl = $dataEl.eq(opts.dataIndexAvg);

					$barEl.css("width",$this_width);

				$label_position = $avg_width+"%";
					$barEl.find("em").eq(0).css({"right":(100-$avg_width)+"%","width":0+"px"}).animate({"width":$this_width*$avg_width/100+"px"},opts.aniTimer);
					$barEl.find("span").eq(0).css({"left":$avg_width+"%","width":0+"px"}).animate({"width":$this_width*(100-$avg_width)/100+"px"},opts.aniTimer);
					$(this).css("left",$this_position+"px");
					
					if(opts.labelPrint){
						$(this).find(opts.dataEl).eq(opts.dataIndexAvg)
							.append($('<span title="The average position">The average position</span>')
							.addClass(opts.labelClass)
							.css("left",$label_position));
					};
					chkcnt++;
				});
			}

			/* 20130716 수정 S */
			//막대그래프(내위치,평균) 애니메이션
			function aniAveragebar(){
				$conAniEl.each(function(indexN){
					var $this_value = $(this).parent().find(opts.dataElText).eq(0).text().replace(",","")*1;
					if ($this_value > opts.maxValue){
					var $this_width = (opts.unitTermWidth/opts.unitTerm)*(opts.maxValue-opts.unitStart);	
					}
					else{
					var $this_width = (opts.unitTermWidth/opts.unitTerm)*($this_value-opts.unitStart);
					}
					$(this).animate({"width":+$this_width+"px"},opts.aniTimer);
					if(opts.isAverageD){
						if(indexN==0){
							if($this_value>=6000){
								$(this).siblings(opts.eventElWrap).find(opts.eventElVir).animate({"width":+$this_width+"px"},opts.aniTimer);
							}
							else{
								if ($this_value<=4000){
									$(this).siblings(opts.eventElWrap).find(opts.eventElVir).css({"width":"115px"});
									$(this).siblings(opts.eventElWrap).find('strong').addClass("bg02");
								}
								$(this).siblings(opts.eventElWrap).find(opts.eventElVir).css("width","120px");
							}
						}
						else{
							if($this_value>=3000){
								
								$(this).siblings(opts.eventElWrap).find(opts.eventElVir).animate({"width":+$this_width+"px"},opts.aniTimer);
							}
							else{
								if ($this_value<=2500){
									$(this).siblings(opts.eventElWrap).find(opts.eventElVir).css({"width":"115px"});
									$(this).siblings(opts.eventElWrap).find('strong').addClass("bg02");
								}
								$(this).siblings(opts.eventElWrap).find(opts.eventElVir).css("width","100px");
							}
						}
					}
				});
			}
			/* //20130716 수정 E */
		});
	};
	/* 20130716 수정 S */
	$.fn.graphDisplay.defaults = {
		isAverageD : false,
		eventElVir : ".empty",
		eventElWrap : ".empty-wrap", //내위치, 나의평균 가상의 wrap
		graphType : "horizontal",		//horizontal or vertical or sidebar
		onClass : null,						//스크립트호출시 추가될 class명
		eventEl : ".bar",						//그래프 애니메이션 el
		aniTimer : 2000,					//그래프 애니메이션 속도값
		dataEl : "li",							//그래프 데이터 el
		dataElText : "em",					//그래프 데이터 텍스트 el
		dataIndexMin : 0,					//그래프 데이터 최소값 el index (sidebar 일때)
		dataIndexMax : 2,					//그래프 데이터 최대값 el index (sidebar 일때)
		dataIndexAvg : 1,					//그래프 데이터 평균값 el index (sidebar 일때)
		unitTerm : 1000,					//그래프 1칸단 단위
		unitTermWidth : 49,				//그래프 1칸단 가로값
		unitStart : 1000,						//그래프 시작단위
		unitEnd : 10000,					//그래프 종료단위
		labelPrint : true,					//평균값 출력여부 (sidebar 일때)
		labelClass : "tick", //평균값 출력element 클래스 (sidebar 일때)
		tabEventEl : ".tab-list li", //탭전환 클릭 El,
		maxValue : 2000000
	};
	/* //20130716 수정 E */
})(jQuery);

/*****************************************
	별점평가 애니메이션
*****************************************/
(function($) {
	$.fn.starRateDisplay = function(options){
		options = options || {};
		var opts = $.extend({}, $.fn.starRateDisplay.defaults, options || {});

		var $starEl = $(this);
		var $startTimer;
		
		if(opts.addClass) $starEl.addClass(opts.addClass);
		$starEl.find(opts.labelContain+':eq(0)').addClass(opts.hiddenClass);
		$starEl.find("input[name='"+opts.radioName+"']").each(function(){
			$(this).addClass(opts.hiddenClass);
		});

		$starEl.find("label").bind("mouseover",function(){
			clearTimeout($startTimer);
			$(this).parent(opts.labelContain).prevAll(opts.labelContain).addClass(opts.hoverClass);
			$(this).parent(opts.labelContain).addClass(opts.hoverClass);
			$(this).parent(opts.labelContain).nextAll(opts.labelContain).removeClass(opts.hoverClass);
		});

		$starEl.bind("mouseleave",function(){
			resetStart();
			//alert($starEl.find('input:checked').val());
		});

		function resetStart(){
			$starEl.find(opts.labelContain).removeClass(opts.hoverClass);
		}

		$starEl.find("label").bind("click",function(){
			$(this).parent(opts.labelContain).prevAll(opts.labelContain).addClass(opts.onClass);
			$(this).parent(opts.labelContain).addClass(opts.onClass);
			$(this).parent(opts.labelContain).nextAll(opts.labelContain).removeClass(opts.onClass);
		});
	};

	$.fn.starRateDisplay.defaults = {
		addClass : null,						//스크립트호출시 추가될 클래스
		radioName : null,
		labelContain : "li",
		hiddenClass : "hidden-obj2",
		hoverClass : "hover",
		onClass : "on"
	};
})(jQuery);

/*****************************************
	별점평가 고정형
*****************************************/
function starGradeFix(ele,widthValue){
	var $wrapEle = $(ele);
	
	$wrapEle.each(function(e){
		var $pointEle = $(this).find('>strong');
		var $starEle = $(this).find('>span');
		var pointValue = $pointEle.text();
		var num = (pointValue*1) * widthValue;
		$starEle.animate({"width" : num},2000);
	});
}

/*****************************************
	URL파라메터값 출
*****************************************/

function getURLParam(strParamName){

	var strReturn = "";
	var strHref = window.location.href;
	var bFound=false;

	var cmpstring = strParamName + "=";
	var cmplen = cmpstring.length;

	if(strHref.indexOf("?") > -1 ){

		var strQueryString = strHref.substr(strHref.indexOf("?")+1);
		var aQueryString = strQueryString.split("&");

		for ( var iParam = 0; iParam < aQueryString.length; iParam++ ){
			if (aQueryString[iParam].substr(0,cmplen)==cmpstring){
				var aParam = aQueryString[iParam].split("=");
				strReturn = aParam[1];
				bFound=true;
				break;
			}
		}
	}

	if (bFound==false) return null;
	return strReturn;
}

/*****************************************
	URL파라메터값 출 : 한글 2바이트로 계산
*****************************************/
function getStrSize(str)
{
	var wch, x, uch = "";
	var szLength = 0;

	for ( x = 0; x < str.length; x ++ )
	{
		wch = str.charCodeAt( x );
		if ( !( wch && 0xFF80 ) )
		{
			szLength ++;
		}
		else if ( !( wch & 0xF000 ) )
		{
			szLength ++;
		}
		else
		{
			szLength += 2;
		}
	}
	return szLength;
}

/*****************************************
	보고서관련
*****************************************/
function reportClose(){
	$("#openDialogReport").slideUp(function(){ $(this).remove();});
	$('a.btn-report').removeClass("btn-report-on");
	$(".modal-overlay3").remove();
}
/* 20131209 수정 S */
function reportOpen(){
	$('#openDialogReport').hide();
	//보고서상단 띠배너 존재시 보고서 호출함수 분기
	if($('.quick-top').length && $('.quick-top').is(":visible")){
		$('#openDialogReport').modal({
			modal : true,
			modal_class : "modal-overlay3",
			position_top : 129,
			z_index : 25
		});
	}else{
		$('#openDialogReport').modal({
			modal : true,
			modal_class : "modal-overlay3",
			position_top : 79,
			z_index : 25
		});
	}
	$('#openDialogReport').slideDown("slow",function(){
		//$("#openDialogReport #contents").mCustomScrollbar();
	});

	$("#openDialogReport .close, #openDialogReport .close-bottom").bind("click",function(){
		reportClose();
	});

	//보고서 snb는 개발 js에 따로 추가함(commonUtil.js) 퍼블리싱단에서 컨트롤하는 부분 없음.
}
/* //20131209 수정 E */

/*****************************************
	날짜함수
*****************************************/
(function ($) {
	var daysInWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
	var shortMonthsInYear = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	var longMonthsInYear = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var shortMonthsToNumber = [];
	shortMonthsToNumber["Jan"] = "01";
	shortMonthsToNumber["Feb"] = "02";
	shortMonthsToNumber["Mar"] = "03";
	shortMonthsToNumber["Apr"] = "04";
	shortMonthsToNumber["May"] = "05";
	shortMonthsToNumber["Jun"] = "06";
	shortMonthsToNumber["Jul"] = "07";
	shortMonthsToNumber["Aug"] = "08";
	shortMonthsToNumber["Sep"] = "09";
	shortMonthsToNumber["Oct"] = "10";
	shortMonthsToNumber["Nov"] = "11";
	shortMonthsToNumber["Dec"] = "12";

	$.format = (function () {
		function strDay(value) {
			return daysInWeek[parseInt(value, 10)] || value;
		}

		function strMonth(value) {
			var monthArrayIndex = parseInt(value, 10) - 1;
			return shortMonthsInYear[monthArrayIndex] || value;
		}

		function strLongMonth(value) {
			var monthArrayIndex = parseInt(value, 10) - 1;
			return longMonthsInYear[monthArrayIndex] || value;					
		}

		var parseMonth = function (value) {
			return shortMonthsToNumber[value] || value;
		};

		var parseTime = function (value) {
			var retValue = value;
			var millis = "";
			if (retValue.indexOf(".") !== -1) {
				var delimited = retValue.split('.');
				retValue = delimited[0];
				millis = delimited[1];
			}

			var values3 = retValue.split(":");

			if (values3.length === 3) {
				hour = values3[0];
				minute = values3[1];
				second = values3[2];

				return {
					time: retValue,
					hour: hour,
					minute: minute,
					second: second,
					millis: millis
				};
			} else {
				return {
					time: "",
					hour: "",
					minute: "",
					second: "",
					millis: ""
				};
			}
		};

		return {
			date: function (value, format) {
				try {
					var date = null;
					var year = null;
					var month = null;
					var dayOfMonth = null;
					var dayOfWeek = null;
					var time = null;
					if (typeof value.getFullYear === "function") {
						year = value.getFullYear();
						month = value.getMonth() + 1;
						dayOfMonth = value.getDate();
						dayOfWeek = value.getDay();
						time = parseTime(value.toTimeString());
										} else if (value.search(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.?\d{0,3}[-+]?\d{2}:\d{2}/) != -1) { /* 2009-04-19T16:11:05+02:00 */
						var values = value.split(/[T\+-]/);
						year = values[0];
						month = values[1];
						dayOfMonth = values[2];
						time = parseTime(values[3].split(".")[0]);
						date = new Date(year, month - 1, dayOfMonth);
						dayOfWeek = date.getDay();
					} else {
						var values = value.split(" ");
						switch (values.length) {
						case 6:
							/* Wed Jan 13 10:43:41 CET 2010 */
							year = values[5];
							month = parseMonth(values[1]);
							dayOfMonth = values[2];
							time = parseTime(values[3]);
							date = new Date(year, month - 1, dayOfMonth);
							dayOfWeek = date.getDay();
							break;
						case 2:
							/* 2009-12-18 10:54:50.546 */
							var values2 = values[0].split("-");
							year = values2[0];
							month = values2[1];
							dayOfMonth = values2[2];
							time = parseTime(values[1]);
							date = new Date(year, month - 1, dayOfMonth);
							dayOfWeek = date.getDay();
							break;
						case 7:
							/* Tue Mar 01 2011 12:01:42 GMT-0800 (PST) */
						case 9:
							/*added by Larry, for Fri Apr 08 2011 00:00:00 GMT+0800 (China Standard Time) */
						case 10:
							/* added by Larry, for Fri Apr 08 2011 00:00:00 GMT+0200 (W. Europe Daylight Time) */
							year = values[3];
							month = parseMonth(values[1]);
							dayOfMonth = values[2];
							time = parseTime(values[4]);
							date = new Date(year, month - 1, dayOfMonth);
							dayOfWeek = date.getDay();
							break;
						default:
							return value;
						}
					}

					var pattern = "";
					var retValue = "";
					/*
						Issue 1 - variable scope issue in format.date 
						Thanks jakemonO
					*/
					for (var i = 0; i < format.length; i++) {
						var currentPattern = format.charAt(i);
						pattern += currentPattern;
						switch (pattern) {
						case "ddd":
							retValue += strDay(dayOfWeek);
							pattern = "";
							break;
						case "dd":
							if (format.charAt(i + 1) == "d") {
								break;
							}
							if (String(dayOfMonth).length === 1) {
								dayOfMonth = '0' + dayOfMonth;
							}
							retValue += dayOfMonth;
							pattern = "";
							break;
						case "MMMM":
							retValue += strLongMonth(month);
							pattern = "";
							break;
						case "MMM":
							if (format.charAt(i + 1) === "M") {
								break;
							}
							retValue += strMonth(month);
							pattern = "";
							break;
						case "MM":
							if (format.charAt(i + 1) == "M") {
								break;
							}
							if (String(month).length === 1) {
								month = '0' + month;
							}
							retValue += month;
							pattern = "";
							break;
						case "yyyy":
							retValue += year;
							pattern = "";
							break;
						case "HH":
							retValue += time.hour;
							pattern = "";
							break;
						case "hh":
							/* time.hour is "00" as string == is used instead of === */
							retValue += (time.hour == 0 ? 12 : time.hour < 13 ? time.hour : time.hour - 12);
							pattern = "";
							break;
						case "mm":
							retValue += time.minute;
							pattern = "";
							break;
						case "ss":
							/* ensure only seconds are added to the return string */
							retValue += time.second.substring(0, 2);
							pattern = "";
							break;
						case "SSS":
							retValue += time.millis.substring(0, 3);
							pattern = "";
							break;
						case "a":
							retValue += time.hour >= 12 ? "PM" : "AM";
							pattern = "";
							break;
						case " ":
							retValue += currentPattern;
							pattern = "";
							break;
						case "/":
							retValue += currentPattern;
							pattern = "";
							break;
						case ":":
							retValue += currentPattern;
							pattern = "";
							break;
						default:
							if (pattern.length === 2 && pattern.indexOf("y") !== 0 && pattern != "SS") {
								retValue += pattern.substring(0, 1);
								pattern = pattern.substring(1, 2);
							} else if ((pattern.length === 3 && pattern.indexOf("yyy") === -1)) {
								pattern = "";
							}
						}
					}
					return retValue;
				} catch (e) {
					console.log(e);
					return value;
				}
			}
		};
	}());
}(jQuery));

/*****************************************
	테이블정렬
*****************************************/
(function($) {
	$.extend({
		tablesorter: new function() {
			
			var parsers = [], widgets = [];
			
			this.defaults = {
				cssHeader: "header",
				cssAsc: "headerSortUp",
				cssDesc: "headerSortDown",
				sortInitialOrder: "asc",
				sortMultiSortKey: "shiftKey",
				sortForce: null,
				sortAppend: null,
				textExtraction: "simple",
				parsers: {}, 
				widgets: [],		
				widgetZebra: {css: ["even","odd"]},
				headers: {},
				widthFixed: false,
				cancelSelection: true,
				sortList: [],
				headerList: [],
				dateFormat: "us",
				decimal: '.',
				debug: false
			};
			
			/* debuging utils */
			function benchmark(s,d) {
				log(s + "," + (new Date().getTime() - d.getTime()) + "ms");
			}
			
			this.benchmark = benchmark;
			
			function log(s) {
				if (typeof console != "undefined" && typeof console.debug != "undefined") {
					console.log(s);
				} else {
					alert(s);
				}
			}
						
			/* parsers utils */
			function buildParserCache(table,$headers) {
				
				if(table.config.debug) { var parsersDebug = ""; }
				
				var rows = table.tBodies[0].rows;
				
				if(table.tBodies[0].rows[0]) {

					var list = [], cells = rows[0].cells, l = cells.length;
					
					for (var i=0;i < l; i++) {
						var p = false;
						
						if($.metadata && ($($headers[i]).metadata() && $($headers[i]).metadata().sorter)  ) {
						
							p = getParserById($($headers[i]).metadata().sorter);	
						
						} else if((table.config.headers[i] && table.config.headers[i].sorter)) {
	
							p = getParserById(table.config.headers[i].sorter);
						}
						if(!p) {
							p = detectParserForColumn(table,cells[i]);
						}
	
						if(table.config.debug) { parsersDebug += "column:" + i + " parser:" +p.id + "\n"; }
	
						list.push(p);
					}
				}
				
				if(table.config.debug) { log(parsersDebug); }

				return list;
			};
			
			function detectParserForColumn(table,node) {
				var l = parsers.length;
				for(var i=1; i < l; i++) {
					if(parsers[i].is($.trim(getElementText(table.config,node)),table,node)) {
						return parsers[i];
					}
				}
				// 0 is always the generic parser (text)
				return parsers[0];
			}
			
			function getParserById(name) {
				var l = parsers.length;
				for(var i=0; i < l; i++) {
					if(parsers[i].id.toLowerCase() == name.toLowerCase()) {	
						return parsers[i];
					}
				}
				return false;
			}
			
			/* utils */
			function buildCache(table) {
				
				if(table.config.debug) { var cacheTime = new Date(); }
				
				
				var totalRows = (table.tBodies[0] && table.tBodies[0].rows.length) || 0,
					totalCells = (table.tBodies[0].rows[0] && table.tBodies[0].rows[0].cells.length) || 0,
					parsers = table.config.parsers, 
					cache = {row: [], normalized: []};
				
					for (var i=0;i < totalRows; ++i) {
					
						/** Add the table data to main data array */
						var c = table.tBodies[0].rows[i], cols = [];
					
						cache.row.push($(c));
						
						for(var j=0; j < totalCells; ++j) {
							cols.push(parsers[j].format(getElementText(table.config,c.cells[j]),table,c.cells[j]));	
						}
												
						cols.push(i); // add position for rowCache
						cache.normalized.push(cols);
						cols = null;
					};
				
				if(table.config.debug) { benchmark("Building cache for " + totalRows + " rows:", cacheTime); }
				
				return cache;
			};
			
			function getElementText(config,node) {
				
				if(!node) return "";
								
				var t = "";
				
				if(config.textExtraction == "simple") {
					if(node.childNodes[0] && node.childNodes[0].hasChildNodes()) {
						t = node.childNodes[0].innerHTML;
					} else {
						t = node.innerHTML;
					}
				} else {
					if(typeof(config.textExtraction) == "function") {
						t = config.textExtraction(node);
					} else { 
						t = $(node).text();
					}	
				}
				return t;
			}
			
			function appendToTable(table,cache) {
				
				if(table.config.debug) {var appendTime = new Date()}
				
				var c = cache, 
					r = c.row, 
					n= c.normalized, 
					totalRows = n.length, 
					checkCell = (n[0].length-1), 
					tableBody = $(table.tBodies[0]),
					rows = [];
				
				for (var i=0;i < totalRows; i++) {
					rows.push(r[n[i][checkCell]]);	
					if(!table.config.appender) {
						
						var o = r[n[i][checkCell]];
						var l = o.length;
						for(var j=0; j < l; j++) {
							
							tableBody[0].appendChild(o[j]);
						
						}
						
						//tableBody.append(r[n[i][checkCell]]);
					}
				}	
				
				if(table.config.appender) {
				
					table.config.appender(table,rows);	
				}
				
				rows = null;
				
				if(table.config.debug) { benchmark("Rebuilt table:", appendTime); }
								
				//apply table widgets
				applyWidget(table);
				
				// trigger sortend
				setTimeout(function() {
					$(table).trigger("sortEnd");	
				},0);
				
			};
			
			function buildHeaders(table) {
				
				if(table.config.debug) { var time = new Date(); }
				
				var meta = ($.metadata) ? true : false, tableHeadersRows = [];
			
				for(var i = 0; i < table.tHead.rows.length; i++) { tableHeadersRows[i]=0; };
				
				$tableHeaders = $("thead th",table);
		
				$tableHeaders.each(function(index) {
							
					this.count = 0;
					this.column = index;
					this.order = formatSortingOrder(table.config.sortInitialOrder);
					
					if(checkHeaderMetadata(this) || checkHeaderOptions(table,index)) this.sortDisabled = true;
					
					if(!this.sortDisabled) {
						$(this).addClass(table.config.cssHeader);
					}
					
					// add cell to headerList
					table.config.headerList[index]= this;
				});
				
				if(table.config.debug) { benchmark("Built headers:", time); log($tableHeaders); }
				
				return $tableHeaders;
				
			};
						
		   	function checkCellColSpan(table, rows, row) {
                var arr = [], r = table.tHead.rows, c = r[row].cells;
				
				for(var i=0; i < c.length; i++) {
					var cell = c[i];
					
					if ( cell.colSpan > 1) { 
						arr = arr.concat(checkCellColSpan(table, headerArr,row++));
					} else  {
						if(table.tHead.length == 1 || (cell.rowSpan > 1 || !r[row+1])) {
							arr.push(cell);
						}
						//headerArr[row] = (i+row);
					}
				}
				return arr;
			};
			
			function checkHeaderMetadata(cell) {
				if(($.metadata) && ($(cell).metadata().sorter === false)) { return true; };
				return false;
			}
			
			function checkHeaderOptions(table,i) {	
				if((table.config.headers[i]) && (table.config.headers[i].sorter === false)) { return true; };
				return false;
			}
			
			function applyWidget(table) {
				var c = table.config.widgets;
				var l = c.length;
				for(var i=0; i < l; i++) {
					
					getWidgetById(c[i]).format(table);
				}
				
			}
			
			function getWidgetById(name) {
				var l = widgets.length;
				for(var i=0; i < l; i++) {
					if(widgets[i].id.toLowerCase() == name.toLowerCase() ) {
						return widgets[i]; 
					}
				}
			};
			
			function formatSortingOrder(v) {
				
				if(typeof(v) != "Number") {
					i = (v.toLowerCase() == "desc") ? 1 : 0;
				} else {
					i = (v == (0 || 1)) ? v : 0;
				}
				return i;
			}
			
			function isValueInArray(v, a) {
				var l = a.length;
				for(var i=0; i < l; i++) {
					if(a[i][0] == v) {
						return true;	
					}
				}
				return false;
			}
				
			function setHeadersCss(table,$headers, list, css) {
				// remove all header information
				$headers.removeClass(css[0]).removeClass(css[1]);
				
				var h = [];
				$headers.each(function(offset) {
						if(!this.sortDisabled) {
							h[this.column] = $(this);					
						}
				});
				
				var l = list.length; 
				for(var i=0; i < l; i++) {
					h[list[i][0]].addClass(css[list[i][1]]);
				}
			}
			
			function fixColumnWidth(table,$headers) {
				var c = table.config;
				if(c.widthFixed) {
					var colgroup = $('<colgroup>');
					$("tr:first td",table.tBodies[0]).each(function() {
						colgroup.append($('<col>').css('width',$(this).width()));
					});
					$(table).prepend(colgroup);
				};
			}
			
			function updateHeaderSortCount(table,sortList) {
				var c = table.config, l = sortList.length;
				for(var i=0; i < l; i++) {
					var s = sortList[i], o = c.headerList[s[0]];
					o.count = s[1];
					o.count++;
				}
			}
			
			/* sorting methods */
			function multisort(table,sortList,cache) {
				
				if(table.config.debug) { var sortTime = new Date(); }
				
				var dynamicExp = "var sortWrapper = function(a,b) {", l = sortList.length;
					
				for(var i=0; i < l; i++) {
					
					var c = sortList[i][0];
					var order = sortList[i][1];
					var s = (getCachedSortType(table.config.parsers,c) == "text") ? ((order == 0) ? "sortText" : "sortTextDesc") : ((order == 0) ? "sortNumeric" : "sortNumericDesc");
					
					var e = "e" + i;
					
					dynamicExp += "var " + e + " = " + s + "(a[" + c + "],b[" + c + "]); ";
					dynamicExp += "if(" + e + ") { return " + e + "; } ";
					dynamicExp += "else { ";
				}
				
				// if value is the same keep orignal order	
				var orgOrderCol = cache.normalized[0].length - 1;
				dynamicExp += "return a[" + orgOrderCol + "]-b[" + orgOrderCol + "];";
						
				for(var i=0; i < l; i++) {
					dynamicExp += "}; ";
				}
				
				dynamicExp += "return 0; ";	
				dynamicExp += "}; ";	
				
				eval(dynamicExp);
				
				cache.normalized.sort(sortWrapper);
				
				if(table.config.debug) { benchmark("Sorting on " + sortList.toString() + " and dir " + order+ " time:", sortTime); }
				
				return cache;
			};
			
			function sortText(a,b) {
				return ((a < b) ? -1 : ((a > b) ? 1 : 0));
			};
			
			function sortTextDesc(a,b) {
				return ((b < a) ? -1 : ((b > a) ? 1 : 0));
			};	
			
	 		function sortNumeric(a,b) {
				return a-b;
			};
			
			function sortNumericDesc(a,b) {
				return b-a;
			};
			
			function getCachedSortType(parsers,i) {
				return parsers[i].type;
			};
			
			/* public methods */
			this.construct = function(settings) {

				return this.each(function() {
					
					//if(!this.tHead || !this.tBodies) return; //2012-06-12 아래와 같이 수정
					if(!this.tHead || !this.tBodies || this.tBodies[0].rows.length<2) return;
					
					var $this, $document,$headers, cache, config, shiftDown = 0, sortOrder;
					
					this.config = {};
					
					config = $.extend(this.config, $.tablesorter.defaults, settings);
					
					// store common expression for speed					
					$this = $(this);
					
					// build headers
					$headers = buildHeaders(this);
					
					// try to auto detect column type, and store in tables config
					this.config.parsers = buildParserCache(this,$headers);
					
					
					// build the cache for the tbody cells
					cache = buildCache(this);
					
					// get the css class names, could be done else where.
					var sortCSS = [config.cssDesc,config.cssAsc];
					
					// fixate columns if the users supplies the fixedWidth option
					fixColumnWidth(this);
					
					// apply event handling to headers
					// this is to big, perhaps break it out?

					$headers.click(function(e) {
						
						$this.trigger("sortStart");
						
						var totalRows = ($this[0].tBodies[0] && $this[0].tBodies[0].rows.length) || 0;
						
						if(!this.sortDisabled && totalRows > 0) {
							
							
							// store exp, for speed
							var $cell = $(this);
	
							// get current column index
							var i = this.column;
							
							// get current column sort order
							this.order = this.count++ % 2;
							
							// user only whants to sort on one column
							if(!e[config.sortMultiSortKey]) {
								
								// flush the sort list
								config.sortList = [];
								
								if(config.sortForce != null) {
									var a = config.sortForce; 
									for(var j=0; j < a.length; j++) {
										if(a[j][0] != i) {
											config.sortList.push(a[j]);
										}
									}
								}
								
								// add column to sort list
								config.sortList.push([i,this.order]);
							
							// multi column sorting
							} else {
								// the user has clicked on an all ready sortet column.
								if(isValueInArray(i,config.sortList)) {	 
									
									// revers the sorting direction for all tables.
									for(var j=0; j < config.sortList.length; j++) {
										var s = config.sortList[j], o = config.headerList[s[0]];
										if(s[0] == i) {
											o.count = s[1];
											o.count++;
											s[1] = o.count % 2;
										}
									}	
								} else {
									// add column to sort list array
									config.sortList.push([i,this.order]);
								}
							};
							setTimeout(function() {
								//set css for headers
								setHeadersCss($this[0],$headers,config.sortList,sortCSS);
								appendToTable($this[0],multisort($this[0],config.sortList,cache));
							},1);
							// stop normal event by returning false
							return false;
						}
					// cancel selection	
					}).mousedown(function() {
						if(config.cancelSelection) {
							this.onselectstart = function() {return false};
							return false;
						}
					});
					
					// apply easy methods that trigger binded events
					$this.bind("update",function() {
						
						// rebuild parsers.
						this.config.parsers = buildParserCache(this,$headers);
						
						// rebuild the cache map
						cache = buildCache(this);
						
					}).bind("sorton",function(e,list) {
						
						$(this).trigger("sortStart");
						
						config.sortList = list;
						
						// update and store the sortlist
						var sortList = config.sortList;
						
						// update header count index
						updateHeaderSortCount(this,sortList);
						
						//set css for headers
						setHeadersCss(this,$headers,sortList,sortCSS);
						
						
						// sort the table and append it to the dom
						appendToTable(this,multisort(this,sortList,cache));

					}).bind("appendCache",function() {
						
						appendToTable(this,cache);
					
					}).bind("applyWidgetId",function(e,id) {
						
						getWidgetById(id).format(this);
						
					}).bind("applyWidgets",function() {
						// apply widgets
						applyWidget(this);
					});
					
					if($.metadata && ($(this).metadata() && $(this).metadata().sortlist)) {
						config.sortList = $(this).metadata().sortlist;
					}
					// if user has supplied a sort list to constructor.
					if(config.sortList.length > 0) {
						$this.trigger("sorton",[config.sortList]);	
					}
					
					// apply widgets
					applyWidget(this);
				});
			};
			
			this.addParser = function(parser) {
				var l = parsers.length, a = true;
				for(var i=0; i < l; i++) {
					if(parsers[i].id.toLowerCase() == parser.id.toLowerCase()) {
						a = false;
					}
				}
				if(a) { parsers.push(parser); };
			};
			
			this.addWidget = function(widget) {
				widgets.push(widget);
			};
			
			this.formatFloat = function(s) {
				var i = parseFloat(s);
				return (isNaN(i)) ? 0 : i;
			};
			this.formatInt = function(s) {
				var i = parseInt(s);
				return (isNaN(i)) ? 0 : i;
			};
			
			this.isDigit = function(s,config) {
				var DECIMAL = '\\' + config.decimal;
				var exp = '/(^[+]?0(' + DECIMAL +'0+)?$)|(^([-+]?[1-9][0-9]*)$)|(^([-+]?((0?|[1-9][0-9]*)' + DECIMAL +'(0*[1-9][0-9]*)))$)|(^[-+]?[1-9]+[0-9]*' + DECIMAL +'0+$)/';
				return RegExp(exp).test($.trim(s));
			};
			
			this.clearTableBody = function(table) {
				if($.browser.msie) {
					function empty() {
						while ( this.firstChild ) this.removeChild( this.firstChild );
					}
					empty.apply(table.tBodies[0]);
				} else {
					table.tBodies[0].innerHTML = "";
				}
			};
		}
	});
	
	// extend plugin scope
	$.fn.extend({
		tablesorter: $.tablesorter.construct
	});
	
	var ts = $.tablesorter;
	
	// add default parsers
	ts.addParser({
		id: "text",
		is: function(s) {
			return true;
		},
		format: function(s) {
			return $.trim(s.toLowerCase());
		},
		type: "text"
	});
	
	ts.addParser({
		id: "digit",
		is: function(s,table) {
			var c = table.config;
			return $.tablesorter.isDigit(s,c);
		},
		format: function(s) {
			return $.tablesorter.formatFloat(s);
		},
		type: "numeric"
	});

	ts.addParser({
		id: "currency",
		is: function(s) {
			return /^[£$€?.]/.test(s);
		},
		format: function(s) {
			return $.tablesorter.formatFloat(s.replace(new RegExp(/[^0-9.]/g),""));
		},
		type: "numeric"
	});
	
	ts.addParser({
		id: "ipAddress",
		is: function(s) {
			return /^\d{2,3}[\.]\d{2,3}[\.]\d{2,3}[\.]\d{2,3}$/.test(s);
		},
		format: function(s) {
			var a = s.split("."), r = "", l = a.length;
			for(var i = 0; i < l; i++) {
				var item = a[i];
				if(item.length == 2) {
					r += "0" + item;
				} else {
					r += item;
				}
			}
			return $.tablesorter.formatFloat(r);
		},
		type: "numeric"
	});
	
	ts.addParser({
		id: "url",
		is: function(s) {
			return /^(https?|ftp|file):\/\/$/.test(s);
		},
		format: function(s) {
			return jQuery.trim(s.replace(new RegExp(/(https?|ftp|file):\/\//),''));
		},
		type: "text"
	});
	
	ts.addParser({
		id: "isoDate",
		is: function(s) {
			return /^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(s);
		},
		format: function(s) {
			return $.tablesorter.formatFloat((s != "") ? new Date(s.replace(new RegExp(/-/g),"/")).getTime() : "0");
		},
		type: "numeric"
	});
		
	ts.addParser({
		id: "percent",
		is: function(s) { 
			return /\%$/.test($.trim(s));
		},
		format: function(s) {
			return $.tablesorter.formatFloat(s.replace(new RegExp(/%/g),""));
		},
		type: "numeric"
	});

	ts.addParser({
		id: "usLongDate",
		is: function(s) {
			return s.match(new RegExp(/^[A-Za-z]{3,10}\.? [0-9]{1,2}, ([0-9]{4}|'?[0-9]{2}) (([0-2]?[0-9]:[0-5][0-9])|([0-1]?[0-9]:[0-5][0-9]\s(AM|PM)))$/));
		},
		format: function(s) {
			return $.tablesorter.formatFloat(new Date(s).getTime());
		},
		type: "numeric"
	});

	ts.addParser({
		id: "shortDate",
		is: function(s) {
			return /\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/.test(s);
		},
		format: function(s,table) {
			var c = table.config;
			s = s.replace(/\-/g,"/");
			if(c.dateFormat == "us") {
				// reformat the string in ISO format
				s = s.replace(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/, "$3/$1/$2");
			} else if(c.dateFormat == "uk") {
				//reformat the string in ISO format
				s = s.replace(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/, "$3/$2/$1");
			} else if(c.dateFormat == "dd/mm/yy" || c.dateFormat == "dd-mm-yy") {
				s = s.replace(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2})/, "$1/$2/$3");	
			}
			return $.tablesorter.formatFloat(new Date(s).getTime());
		},
		type: "numeric"
	});

	ts.addParser({
		id: "time",
		is: function(s) {
			return /^(([0-2]?[0-9]:[0-5][0-9])|([0-1]?[0-9]:[0-5][0-9]\s(am|pm)))$/.test(s);
		},
		format: function(s) {
			return $.tablesorter.formatFloat(new Date("2000/01/01 " + s).getTime());
		},
	  type: "numeric"
	});
	
	
	ts.addParser({
		id: "metadata",
		is: function(s) {
			return false;
		},
		format: function(s,table,cell) {
			var c = table.config, p = (!c.parserMetadataName) ? 'sortValue' : c.parserMetadataName;
			return $(cell).metadata()[p];
		},
	  type: "numeric"
	});
	
	// add default widgets
	ts.addWidget({
		id: "zebra",
		format: function(table) {
			if(table.config.debug) { var time = new Date(); }
			$("tr:visible",table.tBodies[0])
			.filter(':even')
			.removeClass(table.config.widgetZebra.css[1]).addClass(table.config.widgetZebra.css[0])
			.end().filter(':odd')
			.removeClass(table.config.widgetZebra.css[0]).addClass(table.config.widgetZebra.css[1]);
			if(table.config.debug) { $.tablesorter.benchmark("Applying Zebra widget", time); }
		}
	});	
})(jQuery);

/*****************************************
	페이징 탭인덱스 리프레쉬 고정
*****************************************/

(function($) {

	$.fn.tabFixIndex = function(options){
		options = options || {};
		var opts = $.extend({}, $.fn.tabFixIndex.defaults, options || {});

		return this.each(function() {
			var $cont = $(this);
			var $chEle = $cont.find(opts.chEle);
			
			if(opts.pagingTab){
				$(opts.mdEle).find('li').eq(opts.indexNum).find('a').trigger('click');
				
				if(opts.tabIndex==0){
					$chEle.find('li:eq(0) > a').trigger('click');
				}
				else if(opts.tabIndex==1){
					$chEle.find('li:eq(1) > a').trigger('click');
				}
				else if(opts.tabIndex==2){
					$chEle.find('li:eq(2) > a').trigger('click');
				}
				else if(opts.tabIndex==3){
					$chEle.find('li:eq(3) > a').trigger('click');
				}
				else return;
				}

			else{
				return;
			}

		});
	};

	$.fn.tabFixIndex.defaults = {
		mdEle : ".salary-tab02",// 2단탭메뉴일 경우 부모탭 엘리먼트 지정
		chEle : "> .tab-list",//페이지리프레시후 고정시킬 탭 엘리먼트 지정
		pagingTab : false,//페이지리프레시 탭고정 기능 사용여부
		tabIndex : 0,//고정시킬 탭의 인덱스 번호
		indexNum : 3
	};

})(jQuery);